import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const images = {
  zeekr: ["/cars/zeekr.jpg", "/cars/li.jpg"],
  li: ["/cars/li.jpg", "/cars/zeekr.jpg"],
  byd: ["/cars/byd.jpg", "/cars/zeekr.jpg"],
  tank: ["/cars/tank.jpg", "/cars/byd.jpg"]
};

async function main() {
  await prisma.lead.deleteMany();
  await prisma.importDraft.deleteMany();
  await prisma.car.deleteMany();

  await prisma.appSettings.upsert({
    where: { id: "default" },
    create: {
      id: "default",
      companyName: "БелАвтоЭксперт",
      phone: "+375 (44) 52-52-703",
      cnyRate: 11.8,
      defaultDeliveryRub: 280000,
      customsRate: 0.16,
      minCustomsRub: 420000,
      defaultCommissionRub: 200000
    },
    update: {}
  });

  await prisma.car.createMany({
    data: [
      {
        type: "CHINA_IMPORT",
        status: "PUBLISHED",
        source: "CHE168",
        sourceUrl: "https://m.che168.com/",
        externalId: "che168-zeekr-001-demo",
        brand: "Zeekr",
        model: "001",
        trim: "WE 100 kWh",
        year: 2024,
        mileageKm: 8200,
        city: "Владивосток",
        body: "Лифтбек",
        engineType: "Электро",
        gearbox: "Редуктор",
        drive: "Полный",
        power: "544 л.с.",
        battery: "100 кВт⋅ч",
        rangeKm: 705,
        color: "Серый",
        priceCny: 219000,
        priceRub: 3632724,
        deliveryRub: 280000,
        customsRub: 568524,
        commissionRub: 200000,
        descriptionOrig: "极氪001 2024款 WE版 100kWh",
        descriptionRu: "Zeekr 001 2024 года из Китая. Электрический лифтбек с полным приводом, батареей 100 кВт⋅ч и запасом хода до 705 км. Карточка переведена и нормализована автоматически, финальную проверку выполняет менеджер.",
        aiSummary: "AI выделил батарею, запас хода, привод и комплектацию из китайского описания.",
        imageUrls: JSON.stringify(images.zeekr),
        publishedAt: new Date()
      },
      {
        type: "IN_STOCK",
        status: "PUBLISHED",
        source: "MANUAL",
        brand: "Tank",
        model: "500",
        trim: "Urban",
        year: 2023,
        mileageKm: 21000,
        city: "Минск",
        body: "Внедорожник",
        engineType: "Бензин",
        gearbox: "Автомат",
        drive: "Полный",
        power: "354 л.с.",
        color: "Черный",
        priceRub: 4582860,
        descriptionRu: "Tank 500 в наличии. Автомобиль доступен для осмотра, цена указана под ключ с учетом текущих расходов и комиссии.",
        imageUrls: JSON.stringify(images.tank),
        publishedAt: new Date()
      },
      {
        type: "CHINA_IMPORT",
        status: "REVIEW",
        source: "CHE168",
        sourceUrl: "https://m.che168.com/",
        externalId: "che168-byd-han-demo",
        brand: "BYD",
        model: "Han EV",
        trim: "Long Range",
        year: 2024,
        mileageKm: 4300,
        city: "Шэньчжэнь",
        body: "Седан",
        engineType: "Электро",
        gearbox: "Редуктор",
        drive: "Передний",
        power: "380 л.с.",
        battery: "85 кВт⋅ч",
        rangeKm: 610,
        color: "Белый",
        priceCny: 185000,
        priceRub: 3200844,
        deliveryRub: 270000,
        customsRub: 390844,
        commissionRub: 180000,
        descriptionRu: "BYD Han EV в импортном черновике. Требуется ручная проверка комплектации и состояния перед публикацией.",
        aiSummary: "AI пометил карточку как требующую проверки из-за неполного описания состояния.",
        imageUrls: JSON.stringify(images.byd)
      },
      {
        type: "NEW_CAR",
        status: "PUBLISHED",
        source: "MANUAL",
        brand: "Li Auto",
        model: "L9 Ultra",
        trim: "Max",
        year: 2025,
        mileageKm: 0,
        city: "Под заказ",
        body: "Кроссовер",
        engineType: "Гибрид",
        gearbox: "Автомат",
        drive: "Полный",
        power: "449 л.с.",
        battery: "44.5 кВт⋅ч",
        rangeKm: 1315,
        color: "Любой",
        priceRub: 5216284,
        descriptionRu: "Новый Li Auto L9 Ultra под заказ. Можно выбрать цвет, комплектацию и параметры поставки.",
        imageUrls: JSON.stringify(images.li),
        publishedAt: new Date()
      },
      {
        type: "CUSTOM_ORDER",
        status: "PUBLISHED",
        source: "MANUAL",
        brand: "Подбор",
        model: "Авто под бюджет",
        year: 2026,
        mileageKm: 0,
        city: "Китай",
        body: "Любой",
        engineType: "Любой",
        gearbox: "Любая",
        drive: "Любой",
        power: "по запросу",
        color: "по запросу",
        priceRub: 2500000,
        descriptionRu: "Индивидуальный подбор автомобиля из Китая под бюджет, тип кузова, запас хода и сроки поставки.",
        imageUrls: JSON.stringify(images.byd),
        publishedAt: new Date()
      },
      {
        type: "CHINA_IMPORT",
        status: "PUBLISHED",
        source: "CHE168",
        sourceUrl: "https://www.che168.com/dealer/335626/59038334.html?userpid=320000&usercid=320500#pvareaid=110519",
        externalId: "59038334-demo",
        brand: "BMW",
        model: "iX3",
        trim: "Leading",
        year: 2024,
        mileageKm: 9600,
        city: "Сучжоу",
        body: "Кроссовер",
        engineType: "Электро",
        gearbox: "Редуктор",
        drive: "Задний",
        power: "286 л.с.",
        battery: "80 кВт⋅ч",
        rangeKm: 550,
        color: "Синий",
        priceCny: 238000,
        priceRub: 3703840,
        deliveryRub: 280000,
        customsRub: 449440,
        commissionRub: 200000,
        descriptionOrig: "宝马 iX3 2024款 领先型",
        descriptionRu: "BMW iX3 из Китая с понятной историей, электрическим приводом и расчетом под ключ. Карточка демонстрирует публикацию по прямому URL оригинального объявления.",
        aiSummary: "AI-нормализация: источник che168, цена в CNY, базовые характеристики и город продажи.",
        imageUrls: JSON.stringify(images.zeekr),
        publishedAt: new Date()
      },
      {
        type: "IN_STOCK",
        status: "PUBLISHED",
        source: "MANUAL",
        brand: "Lexus",
        model: "RX 350",
        trim: "Premium",
        year: 2022,
        mileageKm: 34000,
        city: "Минск",
        body: "Кроссовер",
        engineType: "Бензин",
        gearbox: "Автомат",
        drive: "Полный",
        power: "279 л.с.",
        color: "Белый",
        priceRub: 6100000,
        deliveryRub: 0,
        customsRub: 0,
        commissionRub: 0,
        descriptionRu: "Lexus RX 350 в наличии. Подходит для демонстрации раздела склада: машина уже локально, без ожидания поставки из Китая.",
        imageUrls: JSON.stringify(images.tank),
        publishedAt: new Date()
      },
      {
        type: "NEW_CAR",
        status: "PUBLISHED",
        source: "MANUAL",
        brand: "BYD",
        model: "Song Plus DM-i",
        trim: "Flagship",
        year: 2025,
        mileageKm: 0,
        city: "Под заказ",
        body: "Кроссовер",
        engineType: "Гибрид",
        gearbox: "Автомат",
        drive: "Передний",
        power: "197 л.с.",
        battery: "26.6 кВт⋅ч",
        rangeKm: 1100,
        color: "Любой",
        priceCny: 159800,
        priceRub: 2783662,
        deliveryRub: 280000,
        customsRub: 420000,
        commissionRub: 200000,
        descriptionRu: "Новый BYD Song Plus DM-i под заказ. Хороший демо-пример для клиентов, которые сравнивают гибриды с электромобилями.",
        imageUrls: JSON.stringify(images.byd),
        publishedAt: new Date()
      }
    ]
  });

  await prisma.importDraft.createMany({
    data: [
      {
        source: "CHE168",
        sourceUrl: "https://m.che168.com/",
        externalId: "che168-demo-raw-001",
        rawTitle: "极氪 001 2024款 ME版",
        rawPayload: JSON.stringify({
          city: "杭州",
          mileage: "0.8万公里",
          fuel: "纯电",
          battery: "100kWh"
        }),
        translatedTitle: "Zeekr 001 2024 ME",
        normalizedJson: JSON.stringify({
          brand: "Zeekr",
          model: "001",
          engineType: "Электро",
          battery: "100 кВт⋅ч"
        }),
        imageUrls: JSON.stringify(images.zeekr),
        priceCny: 229000,
        reviewNote: "Проверить комплектацию ME и доступность экспорта."
      },
      {
        source: "DONGCHEDI",
        sourceUrl: "https://m.dcdapp.com/motor/feoffline/usedcar_channel/",
        externalId: "dcd-demo-raw-001",
        rawTitle: "理想 L9 Ultra 2025款",
        rawPayload: JSON.stringify({
          city: "上海",
          mileage: "新车",
          fuel: "增程式"
        }),
        translatedTitle: "Li Auto L9 Ultra 2025",
        normalizedJson: JSON.stringify({
          brand: "Li Auto",
          model: "L9 Ultra",
          engineType: "Гибрид"
        }),
        imageUrls: JSON.stringify(images.li),
        priceCny: 419800,
        reviewNote: "Источник требует отдельной технической проверки API."
      }
    ]
  });

  const leadCar = await prisma.car.findFirst({
    where: { brand: "Zeekr", model: "001" }
  });

  await prisma.lead.create({
    data: {
      carId: leadCar?.id ?? null,
      name: "Демо-клиент",
      phone: "+7 (999) 123-45-67",
      preferredContact: "WHATSAPP",
      comment: "Интересует расчет по Zeekr 001, срок доставки и возможные цвета.",
      status: "NEW"
    }
  });
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (error) => {
    console.error(error);
    await prisma.$disconnect();
    process.exit(1);
  });
