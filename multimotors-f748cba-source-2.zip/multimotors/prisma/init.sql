PRAGMA foreign_keys = ON;

CREATE TABLE "Car" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "type" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'DRAFT',
  "source" TEXT NOT NULL DEFAULT 'MANUAL',
  "sourceUrl" TEXT,
  "externalId" TEXT,
  "brand" TEXT NOT NULL,
  "model" TEXT NOT NULL,
  "trim" TEXT,
  "year" INTEGER NOT NULL,
  "mileageKm" INTEGER NOT NULL DEFAULT 0,
  "city" TEXT,
  "body" TEXT,
  "engineType" TEXT NOT NULL,
  "gearbox" TEXT,
  "drive" TEXT,
  "power" TEXT,
  "battery" TEXT,
  "rangeKm" INTEGER,
  "color" TEXT,
  "vin" TEXT,
  "priceCny" INTEGER,
  "priceRub" INTEGER NOT NULL,
  "deliveryRub" INTEGER NOT NULL DEFAULT 0,
  "customsRub" INTEGER NOT NULL DEFAULT 0,
  "commissionRub" INTEGER NOT NULL DEFAULT 0,
  "descriptionRu" TEXT NOT NULL,
  "descriptionOrig" TEXT,
  "aiSummary" TEXT,
  "specificationsJson" TEXT,
  "imageUrls" TEXT NOT NULL,
  "publishedAt" DATETIME,
  "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX "Car_status_type_idx" ON "Car"("status", "type");
CREATE INDEX "Car_brand_model_idx" ON "Car"("brand", "model");

CREATE TABLE "ImportDraft" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "source" TEXT NOT NULL,
  "sourceUrl" TEXT NOT NULL,
  "externalId" TEXT,
  "rawTitle" TEXT NOT NULL,
  "rawPayload" TEXT NOT NULL,
  "translatedTitle" TEXT,
  "normalizedJson" TEXT,
  "imageUrls" TEXT NOT NULL,
  "priceCny" INTEGER,
  "reviewNote" TEXT,
  "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE "Lead" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "carId" TEXT,
  "name" TEXT NOT NULL,
  "phone" TEXT NOT NULL,
  "preferredContact" TEXT NOT NULL DEFAULT 'PHONE',
  "comment" TEXT,
  "status" TEXT NOT NULL DEFAULT 'NEW',
  "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Lead_carId_fkey" FOREIGN KEY ("carId") REFERENCES "Car" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE INDEX "Lead_carId_idx" ON "Lead"("carId");

CREATE TABLE "AppSettings" (
  "id" TEXT NOT NULL PRIMARY KEY DEFAULT 'default',
  "companyName" TEXT NOT NULL DEFAULT 'БелАвтоЭксперт',
  "phone" TEXT NOT NULL DEFAULT '+375 (44) 52-52-703',
  "whatsapp" TEXT DEFAULT '375445252703',
  "telegram" TEXT DEFAULT '+375445252703',
  "instagram" TEXT DEFAULT 'https://www.instagram.com/belavtoexpert/',
  "usdRate" REAL NOT NULL DEFAULT 84.1975,
  "cnyRate" REAL NOT NULL DEFAULT 11.8,
  "defaultDeliveryRub" INTEGER NOT NULL DEFAULT 280000,
  "customsRate" REAL NOT NULL DEFAULT 0.16,
  "minCustomsRub" INTEGER NOT NULL DEFAULT 420000,
  "defaultCommissionRub" INTEGER NOT NULL DEFAULT 200000,
  "updatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

INSERT OR IGNORE INTO "AppSettings" (
  "id",
  "companyName",
  "phone",
  "cnyRate",
  "defaultDeliveryRub",
  "customsRate",
  "minCustomsRub",
  "defaultCommissionRub",
  "updatedAt"
) VALUES (
  'default',
  'БелАвтоЭксперт',
  '+375 (44) 52-52-703',
  11.8,
  280000,
  0.16,
  420000,
  200000,
  CURRENT_TIMESTAMP
);
