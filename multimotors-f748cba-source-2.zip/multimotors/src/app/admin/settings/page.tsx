import { AdminShell } from "@/app/admin/_components/AdminShell";
import { toAdminSettingsData } from "@/app/admin/_components/AdminSections";
import { SettingsForm } from "@/components/AdminClient";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const settings = await getSettings();
  return (
    <AdminShell active="settings">
      <section className="admin-card">
        <h1>Настройки сайта</h1>
        <p className="muted">Контакты компании и курсы для расчёта стоимости автомобилей.</p>
        <SettingsForm settings={toAdminSettingsData(settings)} />
      </section>
    </AdminShell>
  );
}
