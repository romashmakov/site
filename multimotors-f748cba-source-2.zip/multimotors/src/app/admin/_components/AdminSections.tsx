import type { AppSettings, Car, ImportDraft, Lead } from "@prisma/client";
import {
  AdminCreateCar,
  type AdminCarRowData,
  CarAdminRows,
  ImportListDraftForm,
  ImportUrlDraftForm,
  LeadStatusSelect,
  type AdminSettingsData,
  BulkDeleteDraftsForm,
  DeleteDraftButton,
  PublishDraftButton,
  RetryDraftButton
} from "@/components/AdminClient";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { formatCny, sourceLabel } from "@/lib/format";

export type LeadWithCar = Lead & { car: Car | null };

export function toAdminSettingsData(settings: AppSettings): AdminSettingsData {
  return {
    id: settings.id,
    companyName: settings.companyName,
    phone: settings.phone,
    whatsapp: settings.whatsapp,
    telegram: settings.telegram,
    instagram: settings.instagram,
    usdRate: settings.usdRate,
    cnyRate: settings.cnyRate,
    defaultDeliveryRub: settings.defaultDeliveryRub,
    customsRate: settings.customsRate,
    minCustomsRub: settings.minCustomsRub,
    defaultCommissionRub: settings.defaultCommissionRub
  };
}

export function toAdminCarRows(cars: Car[]): AdminCarRowData[] {
  return cars.map((car) => ({
    id: car.id,
    type: car.type,
    status: car.status,
    brand: car.brand,
    model: car.model,
    trim: car.trim ?? "",
    year: car.year,
    mileageKm: car.mileageKm,
    city: car.city ?? "",
    body: car.body ?? "",
    engineType: car.engineType,
    gearbox: car.gearbox ?? "",
    drive: car.drive ?? "",
    power: car.power ?? "",
    battery: car.battery ?? "",
    rangeKm: car.rangeKm ?? "",
    color: car.color ?? "",
    priceCny: car.priceCny ?? "",
    priceRub: car.priceRub,
    deliveryRub: car.deliveryRub,
    customsRub: car.customsRub,
    commissionRub: car.commissionRub,
    descriptionRu: car.descriptionRu,
    aiSummary: car.aiSummary ?? "",
    imageUrls: (JSON.parse(car.imageUrls) as string[]).join("\n"),
    sourceUrl: car.sourceUrl ?? "",
    sourceLastSeenAt: car.sourceLastSeenAt?.toISOString() ?? "",
    sourceMissingSince: car.sourceMissingSince?.toISOString() ?? "",
    sourceMissingCount: car.sourceMissingCount
  }));
}

export function DraftsPanel({ drafts, draftSources }: { drafts: ImportDraft[]; draftSources: Record<string, number> }) {
  return (
    <Card className="admin-card">
      <CardContent className="p-0">
        <h1 className="title-font">Импорт объявлений</h1>
        <p className="muted">
          Добавляйте объявления по ссылке или загружайте несколько вариантов сразу. После импорта проверьте данные и перенесите подходящие авто в каталог.
        </p>
        <div className="admin-source-strip" aria-label="Источники черновиков">
          {Object.keys(sourceLabel)
            .filter((source) => draftSources[source])
            .map((source) => (
              <span key={source}>
                {sourceLabel[source]}: <strong>{draftSources[source]}</strong>
              </span>
            ))}
          {!drafts.length ? <span>Пока нет загруженных объявлений</span> : null}
        </div>
        <div className="admin-import-grid">
          <div className="admin-mini-panel">
            <strong>Добавить по ссылке</strong>
            <p className="muted">Вставьте ссылку на конкретный автомобиль, чтобы создать карточку для проверки.</p>
            <ImportUrlDraftForm />
          </div>
          <div className="admin-mini-panel">
            <strong>Загрузить подборку</strong>
            <p className="muted">Вставьте ссылку на страницу с объявлениями, чтобы добавить несколько вариантов в очередь проверки.</p>
            <ImportListDraftForm />
          </div>
        </div>
        <BulkDeleteDraftsForm>
        <div className="admin-table-wrap">
          <Table className="table admin-data-table">
            <TableHeader>
              <TableRow>
                <TableHead>Выбор</TableHead>
                <TableHead>Источник</TableHead>
                <TableHead>Оригинал</TableHead>
                <TableHead>Описание</TableHead>
                <TableHead>Цена</TableHead>
                <TableHead />
              </TableRow>
            </TableHeader>
            <TableBody>
              {drafts.length ? (
                drafts.map((draft) => (
                  <TableRow key={draft.id}>
                    <TableCell>
                      <input className="draft-checkbox" type="checkbox" name="draftId" value={draft.id} aria-label={`Выбрать черновик ${draft.rawTitle}`} />
                    </TableCell>
                    <TableCell>
                      <span className="admin-pill">{sourceLabel[draft.source]}</span>
                      {draft.externalId ? (
                        <>
                          <br />
                          <span className="muted">ID {draft.externalId}</span>
                        </>
                      ) : null}
                    </TableCell>
                    <TableCell>
                      <strong>{draft.rawTitle}</strong>
                      <br />
                      <a className="muted" href={draft.sourceUrl} target="_blank">
                        источник
                      </a>
                    </TableCell>
                    <TableCell>
                      {draft.translatedTitle || "нет перевода"}
                      <br />
                      <span className="muted">{draft.reviewNote}</span>
                    </TableCell>
                    <TableCell>{formatCny(draft.priceCny)}</TableCell>
                    <TableCell>
                      <div className="row-actions">
                        <RetryDraftButton draftId={draft.id} />
                        <PublishDraftButton draftId={draft.id} />
                        <DeleteDraftButton draftId={draft.id} title={draft.rawTitle} />
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6}>
                    <div className="empty-inline">Очередь проверки пустая. Добавьте объявление по ссылке или загрузите подборку выше.</div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
        </BulkDeleteDraftsForm>
      </CardContent>
    </Card>
  );
}

export function CarsPanel({ cars, settings }: { cars: AdminCarRowData[]; settings: AdminSettingsData }) {
  return (
    <Card className="admin-card">
      <CardContent className="p-0">
        <div className="admin-page-head">
          <div>
            <h1 className="title-font">Объявления</h1>
            <p className="muted">Редактирование опубликованных, черновых и архивных карточек каталога.</p>
          </div>
          <AdminCreateCar settings={settings} />
        </div>
        <div className="admin-table-wrap">
          <Table className="table admin-data-table">
            <TableHeader>
              <TableRow>
                <TableHead>Авто</TableHead>
                <TableHead>Тип</TableHead>
                <TableHead>Статус</TableHead>
                <TableHead>Цена</TableHead>
                <TableHead>Управление</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {cars.length ? (
                <CarAdminRows cars={cars} settings={settings} />
              ) : (
                <TableRow>
                  <TableCell colSpan={5}>
                    <div className="empty-inline">Объявлений пока нет. Создайте ручную карточку или перенесите черновик.</div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}

export function LeadsPanel({ leads }: { leads: LeadWithCar[] }) {
  return (
    <Card className="admin-card">
      <CardContent className="p-0">
        <h1 className="title-font">Заявки</h1>
        <p className="muted">Клиентские обращения с витрины и карточек авто.</p>
        <div className="admin-table-wrap">
          <Table className="table admin-data-table">
            <TableHeader>
              <TableRow>
                <TableHead>Клиент</TableHead>
                <TableHead>Авто</TableHead>
                <TableHead>Связь</TableHead>
                <TableHead>Комментарий</TableHead>
                <TableHead>Статус</TableHead>
                <TableHead>Дата</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {leads.length ? (
                leads.map((lead) => (
                  <TableRow key={lead.id}>
                    <TableCell>
                      <strong>{lead.name}</strong>
                      <br />
                      <span className="muted">{lead.phone}</span>
                    </TableCell>
                    <TableCell>
                      {lead.car ? `${lead.car.brand} ${lead.car.model}` : "Подбор"}
                      {lead.car ? (
                        <>
                          <br />
                          <span className="muted">{lead.car.year} · {lead.car.priceRub.toLocaleString("ru-RU")} ₽</span>
                        </>
                      ) : null}
                    </TableCell>
                    <TableCell>
                      <span className="admin-pill">
                        {lead.preferredContact === "WHATSAPP" ? "WhatsApp" : lead.preferredContact === "TELEGRAM" ? "Telegram" : "Звонок"}
                      </span>
                    </TableCell>
                    <TableCell>{lead.comment || "без комментария"}</TableCell>
                    <TableCell>
                      <LeadStatusSelect id={lead.id} status={lead.status} />
                    </TableCell>
                    <TableCell>{lead.createdAt.toLocaleDateString("ru-RU")}</TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6}>
                    <div className="empty-inline">Заявок пока нет. После отправки формы с витрины они появятся здесь.</div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
