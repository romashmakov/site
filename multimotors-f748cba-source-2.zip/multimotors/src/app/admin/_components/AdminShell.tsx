import type { ReactNode } from "react";
import { AdminLogoutButton } from "@/components/AdminClient";
import { Footer } from "@/components/Footer";
import { SiteHeader } from "@/components/SiteHeader";

const navItems = [
  { href: "/admin/cars", label: "Объявления", key: "cars" },
  { href: "/admin/drafts", label: "Импорт-черновики", key: "drafts" },
  { href: "/admin/leads", label: "Заявки", key: "leads" },
  { href: "/admin/settings", label: "Настройки", key: "settings" }
];

export function AdminShell({ active, children }: { active: string; children: ReactNode }) {
  return (
    <div className="shell admin-shell">
      <SiteHeader />
      <main className="admin-layout container">
        <aside className="admin-sidebar">
          <strong>Админка MVP</strong>
          {navItems.map((item) => (
            <a key={item.key} href={item.href} aria-current={active === item.key ? "page" : undefined}>
              {item.label}
            </a>
          ))}
          <div className="sidebar-footer">
            <AdminLogoutButton />
          </div>
        </aside>
        <div className="admin-grid">{children}</div>
      </main>
      <Footer />
    </div>
  );
}
