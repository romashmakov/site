import { AdminLoginForm } from "@/components/AdminClient";
import { SiteHeader } from "@/components/SiteHeader";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";

export const dynamic = "force-dynamic";

type LoginPageProps = {
  searchParams?: Promise<{
    next?: string;
  }>;
};

export default async function AdminLoginPage({ searchParams }: LoginPageProps) {
  const params = (await searchParams) ?? {};
  const nextPath = params.next?.startsWith("/") ? params.next : "/admin";

  return (
    <div className="shell admin-shell">
      <SiteHeader />
      <main className="login-layout container">
        <Card className="admin-card login-card">
          <CardContent className="p-0">
          <Badge className="badge">Защищённая зона</Badge>
          <h1 className="title-font">Вход в админку</h1>
          <p className="muted">Введите пароль менеджера, чтобы управлять карточками, фото, импортом и заявками.</p>
          <AdminLoginForm nextPath={nextPath} />
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
