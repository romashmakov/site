import { DraftsPanel } from "@/app/admin/_components/AdminSections";
import { AdminShell } from "@/app/admin/_components/AdminShell";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function AdminDraftsPage() {
  const [drafts, draftSourceCounts] = await Promise.all([
    prisma.importDraft.findMany({ orderBy: { createdAt: "desc" }, take: 300 }),
    prisma.importDraft.groupBy({ by: ["source"], _count: { _all: true } })
  ]);
  const draftSources = draftSourceCounts.reduce<Record<string, number>>((acc, item) => {
    acc[item.source] = item._count._all;
    return acc;
  }, {});

  return (
    <AdminShell active="drafts">
      <DraftsPanel drafts={drafts} draftSources={draftSources} />
    </AdminShell>
  );
}
