import { LeadsPanel } from "@/app/admin/_components/AdminSections";
import { AdminShell } from "@/app/admin/_components/AdminShell";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function AdminLeadsPage() {
  const leads = await prisma.lead.findMany({ include: { car: true }, orderBy: { createdAt: "desc" }, take: 50 });

  return (
    <AdminShell active="leads">
      <LeadsPanel leads={leads} />
    </AdminShell>
  );
}
