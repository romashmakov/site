import { CarsPanel, toAdminCarRows, toAdminSettingsData } from "@/app/admin/_components/AdminSections";
import { AdminShell } from "@/app/admin/_components/AdminShell";
import { prisma } from "@/lib/prisma";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export default async function AdminCarsPage() {
  const [cars, settings] = await Promise.all([
    prisma.car.findMany({ orderBy: { updatedAt: "desc" }, take: 50 }),
    getSettings()
  ]);
  const settingsData = toAdminSettingsData(settings);

  return (
    <AdminShell active="cars">
      <CarsPanel cars={toAdminCarRows(cars)} settings={settingsData} />
    </AdminShell>
  );
}
