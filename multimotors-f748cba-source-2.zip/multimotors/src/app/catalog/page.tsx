import Link from "next/link";
import type { Prisma } from "@prisma/client";
import { Footer } from "@/components/Footer";
import { CarCard } from "@/components/CarCard";
import { CatalogFilters } from "@/components/CatalogFilters";
import { redirect } from "next/navigation";
import { getSettings } from "@/lib/settings";
import { catalogYear, nonNegativeInteger, rubPriceBounds } from "@/lib/catalog";
import { SiteHeader } from "@/components/SiteHeader";
import { Button } from "@/components/ui/button";
import { typeFromSlug, typeLabel } from "@/lib/format";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

type CatalogPageProps = {
  searchParams?: Promise<{
    type?: string;
    category?: string;
    q?: string;
    brand?: string;
    model?: string;
    minPrice?: string;
    maxPrice?: string;
    yearFrom?: string;
    yearTo?: string;
    engine?: string;
    sort?: string;
  }>;
};

const catalogCategories = ["used", "used-electric", "used-hybrid"] as const;
type CatalogCategory = (typeof catalogCategories)[number];

const categoryLabels: Record<CatalogCategory, string> = {
  used: "Автомобили Б/У",
  "used-electric": "Электромобили Б/У",
  "used-hybrid": "Гибриды Б/У"
};

function catalogCategory(value: string | undefined): CatalogCategory | undefined {
  return catalogCategories.find((category) => category === value);
}

export default async function CatalogPage({ searchParams }: CatalogPageProps) {
  const params = (await searchParams) ?? {};
  if (params.type === "order") redirect("/selection");
  const settings = await getSettings();
  const selectedCategory = catalogCategory(params.category);
  const selectedType = selectedCategory ? undefined : typeFromSlug(params.type ?? null);
  const query = params.q?.trim();
  const selectedBrand = params.brand?.trim();
  const selectedModel = params.model?.trim();
  const minPrice = nonNegativeInteger(params.minPrice);
  const maxPrice = nonNegativeInteger(params.maxPrice);
  const yearFrom = catalogYear(params.yearFrom);
  const yearTo = catalogYear(params.yearTo);
  const selectedEngine = params.engine?.trim();
  const selectedSort = ["new", "price_asc", "price_desc", "year_desc"].includes(params.sort ?? "") ? params.sort! : "new";
  const catalogBaseHref = selectedCategory
    ? `/catalog?category=${selectedCategory}`
    : selectedType
      ? `/catalog?type=${params.type}`
      : "/catalog";
  const categoryWhere: Prisma.CarWhereInput =
    selectedCategory === "used-electric"
      ? { mileageKm: { gt: 0 }, engineType: { contains: "Электро" } }
      : selectedCategory === "used-hybrid"
        ? { mileageKm: { gt: 0 }, engineType: { contains: "Гибрид" } }
        : selectedCategory === "used"
          ? { mileageKm: { gt: 0 } }
          : {};

  const where: Prisma.CarWhereInput = {
    status: "PUBLISHED",
    AND: [categoryWhere],
    ...(selectedType ? { type: selectedType } : {}),
    ...(selectedBrand ? { brand: selectedBrand } : {}),
    ...(selectedModel ? { model: selectedModel } : {}),
    ...(selectedEngine ? { engineType: selectedEngine } : {}),
    ...(Number.isFinite(yearFrom) || Number.isFinite(yearTo)
      ? {
          year: {
            ...(Number.isFinite(yearFrom) ? { gte: yearFrom as number } : {}),
            ...(Number.isFinite(yearTo) ? { lte: yearTo as number } : {})
          }
        }
      : {}),
    ...(Number.isFinite(minPrice) || Number.isFinite(maxPrice)
      ? {
          priceRub: rubPriceBounds(minPrice, maxPrice, settings.usdRate)
        }
      : {}),
    ...(query
      ? {
          OR: [
            { brand: { contains: query } },
            { model: { contains: query } },
            { trim: { contains: query } }
          ]
        }
      : {})
  };

  const orderBy: Prisma.CarOrderByWithRelationInput[] =
    selectedSort === "price_asc"
      ? [{ priceRub: "asc" }]
      : selectedSort === "price_desc"
        ? [{ priceRub: "desc" }]
        : selectedSort === "year_desc"
          ? [{ year: "desc" }, { publishedAt: "desc" }]
          : [{ publishedAt: "desc" }, { createdAt: "desc" }];

  const [cars, brands, engines, models] = await Promise.all([
    prisma.car.findMany({
      where,
      orderBy
    }),
    prisma.car.findMany({
      where: { status: "PUBLISHED" },
      select: { brand: true },
      distinct: ["brand"],
      orderBy: { brand: "asc" }
    }),
    prisma.car.findMany({
      where: { status: "PUBLISHED" },
      select: { engineType: true },
      distinct: ["engineType"],
      orderBy: { engineType: "asc" }
    }),
    prisma.car.findMany({
      where: { status: "PUBLISHED" },
      select: { brand: true, model: true },
      distinct: ["brand", "model"],
      orderBy: { model: "asc" }
    })
  ]);

  return (
    <div className="shell">
      <SiteHeader />
      <main className="main">
        <section className="section catalog-page" id="catalog">
          <div className="container">
            <div className="toolbar">
              <div>
                <h1 className="title-font">
                  {selectedCategory ? categoryLabels[selectedCategory] : selectedType ? typeLabel[selectedType] : "Каталог авто"}
                </h1>
                <p className="muted" aria-live="polite">Найдено: {cars.length}</p>
              </div>

            </div>

            <div className="tabs" style={{ marginBottom: 18 }}>
              <a className={`tab ${!selectedType && !selectedCategory ? "active" : ""}`} href="/catalog">
                Все
              </a>
              <a className={`tab ${selectedType === "NEW_CAR" ? "active" : ""}`} href="/catalog?type=new">
                Новые авто
              </a>
              <a className={`tab ${selectedCategory === "used" ? "active" : ""}`} href="/catalog?category=used">
                Автомобили Б/У
              </a>
              <a className={`tab ${selectedCategory === "used-electric" ? "active" : ""}`} href="/catalog?category=used-electric">
                Электромобили Б/У
              </a>
              <a className={`tab ${selectedCategory === "used-hybrid" ? "active" : ""}`} href="/catalog?category=used-hybrid">
                Гибриды Б/У
              </a>
              <a className={`tab ${selectedType === "IN_STOCK" ? "active" : ""}`} href="/catalog?type=stock">
                В наличии
              </a>
            </div>

            <p className="catalog-currency-note">Цены указаны в долларах США. Окончательную стоимость уточнит менеджер.</p>
            <div className="catalog-layout">
              <CatalogFilters
                initial={{
                  sort: selectedSort,
                  brand: selectedBrand ?? "",
                  model: selectedModel ?? "",
                  engine: selectedEngine ?? "",
                  yearFrom: yearFrom?.toString() ?? "",
                  yearTo: yearTo?.toString() ?? "",
                  minPrice: minPrice?.toString() ?? "",
                  maxPrice: maxPrice?.toString() ?? ""
                }}
                baseHref={catalogBaseHref}
                query={query}
                brands={brands.map((item) => item.brand)}
                models={models}
                engines={engines.map((item) => item.engineType)}
              />

              <div className="car-list">
                {cars.length ? cars.map((car) => (
                  <CarCard car={car} usdRate={settings.usdRate} key={car.id} />
                )) : (
                  <div className="empty-state">
                    <h3>По этим параметрам ничего не найдено</h3>
                    <p className="muted">Попробуйте изменить фильтры или оставьте заявку: мы подберем подходящие варианты вручную.</p>
                    <div className="empty-actions">
                      <Button asChild className="font-extrabold"><Link href="/selection">Оставить заявку</Link></Button>
                      <Button asChild variant="secondary" className="font-extrabold"><a href={catalogBaseHref}>Сбросить фильтры</a></Button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
