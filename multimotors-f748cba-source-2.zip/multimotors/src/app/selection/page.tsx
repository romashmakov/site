import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, Check } from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { Footer } from "@/components/Footer";
import { LeadForm } from "@/components/LeadForm";
import { ContactActions } from "@/components/ContactActions";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Подбор авто | БелАвтоЭксперт" };

export default function SelectionPage() {
  return (
    <div className="shell">
      <SiteHeader />
      <main className="main section selection-page">
        <div className="container">
          <Link className="back-link" href="/"><ArrowLeft size={16} aria-hidden="true" /> На главную</Link>
          <div className="selection-grid">
            <div className="selection-intro">
              <p className="eyebrow">Индивидуальный подбор</p>
              <h1 className="title-font">Найдём автомобиль<br />под ваши пожелания</h1>
              <p className="muted">Расскажите, какой автомобиль ищете. Мы подберём варианты и подготовим расчёт стоимости с доставкой.</p>
              <ul className="selection-points">
                {["Учтём бюджет и комплектацию", "Проверим состояние и документы", "Рассчитаем итоговую стоимость"].map((text) => <li key={text}><Check size={18} aria-hidden="true" />{text}</li>)}
              </ul>
              <div className="selection-contact"><p className="muted">Удобнее обсудить лично?</p><ContactActions /></div>
            </div>
            <section className="panel selection-form" aria-labelledby="selection-title">
              <h2 id="selection-title">Оставить заявку</h2>
              <p className="muted">Оставьте контакт — свяжемся с вами и уточним детали.</p>
              <LeadForm />
            </section>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
