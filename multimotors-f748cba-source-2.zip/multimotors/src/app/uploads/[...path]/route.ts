import { readFile } from "node:fs/promises";
import path from "node:path";
import { NextResponse } from "next/server";

type RouteProps = {
  params: Promise<{ path: string[] }>;
};

const contentTypes: Record<string, string> = {
  ".avif": "image/avif",
  ".gif": "image/gif",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".webp": "image/webp"
};

export async function GET(_request: Request, { params }: RouteProps) {
  const { path: filePathParts } = await params;
  const uploadRoot = path.join(process.cwd(), "public", "uploads");
  const filePath = path.join(uploadRoot, ...filePathParts);

  if (!filePath.startsWith(uploadRoot + path.sep)) {
    return NextResponse.json({ error: "Файл не найден" }, { status: 404 });
  }

  try {
    const file = await readFile(filePath);
    const extension = path.extname(filePath).toLowerCase();
    return new NextResponse(file, {
      headers: {
        "Cache-Control": "public, max-age=31536000, immutable",
        "Content-Type": contentTypes[extension] || "application/octet-stream"
      }
    });
  } catch {
    return NextResponse.json({ error: "Файл не найден" }, { status: 404 });
  }
}
