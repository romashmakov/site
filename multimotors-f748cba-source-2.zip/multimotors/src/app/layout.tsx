import type { Metadata } from "next";
import { Oswald, PT_Sans } from "next/font/google";
import "./globals.css";

const oswald = Oswald({
  subsets: ["cyrillic", "latin"],
  weight: ["500", "600", "700"],
  variable: "--font-display"
});

const ptSans = PT_Sans({
  subsets: ["cyrillic", "latin"],
  weight: ["400", "700"],
  variable: "--font-body"
});

export const metadata: Metadata = {
  title: "БелАвтоЭксперт | Авто из Китая",
  description: "Каталог автомобилей из Китая, авто в наличии, новые авто и подбор под заказ."
};

export default function RootLayout({
  children
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru">
      <body className={`${ptSans.variable} ${oswald.variable}`}>{children}</body>
    </html>
  );
}
