import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { createImportDraftFromUrl } from "@/lib/import-drafts";

type RouteProps = {
  params: Promise<{ id: string }>;
};

export async function POST(_request: Request, { params }: RouteProps) {
  const { id } = await params;
  const draft = await prisma.importDraft.findUnique({ where: { id } });

  if (!draft) {
    return NextResponse.json({ error: "Черновик не найден" }, { status: 404 });
  }

  const refreshedDraft = await createImportDraftFromUrl(draft.sourceUrl);
  return NextResponse.json({ item: refreshedDraft });
}
