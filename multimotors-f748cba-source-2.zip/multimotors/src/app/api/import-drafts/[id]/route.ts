import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

type RouteProps = {
  params: Promise<{ id: string }>;
};

export async function DELETE(_request: Request, { params }: RouteProps) {
  const { id } = await params;
  const draft = await prisma.importDraft.findUnique({ where: { id } });

  if (!draft) {
    return NextResponse.json({ error: "Черновик не найден" }, { status: 404 });
  }

  await prisma.importDraft.delete({ where: { id } });
  return NextResponse.json({ item: draft });
}
