import { NextResponse } from "next/server";
import { cacheExternalImages } from "@/lib/image-cache";
import { prisma } from "@/lib/prisma";
import { calculateCarCosts, getSettings } from "@/lib/settings";
import { stripChineseText } from "@/lib/text";

type RouteProps = {
  params: Promise<{ id: string }>;
};

function hasTechnicalDescription(value: string) {
  return /черновик|Dongchedi|DCDApp|провер(к|и)|источник/i.test(value);
}

function publicCity(value: string | null | undefined) {
  const cleaned = stripChineseText(value, "");
  return cleaned && cleaned !== "Китай" ? cleaned : "Китай";
}

function buildPublicDescription(input: { title: string; year: number; mileageKm: number; city: string; engineType: string }) {
  const mileage = input.mileageKm ? `Пробег ${input.mileageKm.toLocaleString("ru-RU")} км.` : "";
  const city = publicCity(input.city);
  const cityText = city !== "Китай" ? `Автомобиль находится в городе ${city}.` : "Автомобиль доступен к заказу из Китая.";
  const engine = input.engineType && input.engineType !== "не указан" ? `Двигатель: ${input.engineType}.` : "";

  return [input.title, `${input.year} год.`, mileage, cityText, engine, "Цена рассчитана под ключ с учетом логистики, таможенных расходов и комиссии сервиса."]
    .filter(Boolean)
    .join(" ");
}

export async function POST(_request: Request, { params }: RouteProps) {
  const { id } = await params;
  const [draft, settings] = await Promise.all([
    prisma.importDraft.findUnique({ where: { id } }),
    getSettings()
  ]);

  if (!draft) {
    return NextResponse.json({ error: "Черновик не найден" }, { status: 404 });
  }

  let normalized: Record<string, unknown> = {};
  try {
    normalized = draft.normalizedJson ? JSON.parse(draft.normalizedJson) : {};
  } catch {
    normalized = {};
  }

  const brand = stripChineseText(String(normalized.brand || draft.translatedTitle?.split(" ")[0] || ""), "China");
  const model = stripChineseText(String(normalized.model || draft.translatedTitle?.split(" ").slice(1).join(" ") || draft.rawTitle), "объявление");
  const cleanTrim = stripChineseText(normalized.trim ? String(normalized.trim) : draft.translatedTitle || "");
  const trim = cleanTrim || null;
  const year = Number(normalized.year || 2026);
  const mileageKm = Number(normalized.mileageKm || 0);
  const city = publicCity(normalized.city ? String(normalized.city) : "Китай");
  const body = normalized.body ? String(normalized.body) : null;
  const engineType = String(normalized.engineType || "не указан");
  const gearbox = normalized.gearbox ? String(normalized.gearbox) : null;
  const drive = normalized.drive ? String(normalized.drive) : null;
  const power = normalized.power ? String(normalized.power) : null;
  const battery = normalized.battery ? String(normalized.battery) : null;
  const rangeKm = normalized.rangeKm ? Number(normalized.rangeKm) : null;
  const color = normalized.color ? String(normalized.color) : null;
  const specificationsJson = normalized.specifications ? JSON.stringify(normalized.specifications) : null;
  const fallbackCosts = calculateCarCosts(draft.priceCny, settings);
  const deliveryRub = Number(normalized.deliveryRub || fallbackCosts.deliveryRub);
  const customsRub = Number(normalized.customsRub || fallbackCosts.customsRub);
  const commissionRub = Number(normalized.commissionRub || fallbackCosts.commissionRub);
  const calculatedCosts = calculateCarCosts(draft.priceCny, settings, { deliveryRub, customsRub, commissionRub });
  const priceRub = Number(normalized.priceRub || Math.max(calculatedCosts.priceRub, 950000));
  const fallbackDescription = buildPublicDescription({
    title: `${brand} ${model}${trim ? ` ${trim}` : ""}`,
    year,
    mileageKm,
    city,
    engineType
  });
  const normalizedDescription = normalized.descriptionRu ? stripChineseText(String(normalized.descriptionRu), fallbackDescription) : "";
  const descriptionRu = normalizedDescription && !hasTechnicalDescription(normalizedDescription) ? normalizedDescription : fallbackDescription;
  const imageUrls = await cacheExternalImages(JSON.parse(draft.imageUrls) as string[]);

  const car = await prisma.car.create({
    data: {
      type: "CHINA_IMPORT",
      status: "PUBLISHED",
      source: draft.source,
      sourceUrl: draft.sourceUrl,
      externalId: draft.externalId,
      brand,
      model,
      trim,
      year,
      mileageKm,
      city,
      body,
      engineType,
      gearbox,
      drive,
      power,
      battery,
      rangeKm,
      color,
      priceCny: draft.priceCny,
      priceRub,
      deliveryRub,
      customsRub,
      commissionRub,
      descriptionRu,
      descriptionOrig: draft.rawTitle,
      aiSummary: draft.reviewNote,
      specificationsJson,
      imageUrls: JSON.stringify(imageUrls),
      publishedAt: new Date()
    }
  });

  await prisma.importDraft.delete({ where: { id } });

  return NextResponse.json({ item: car }, { status: 201 });
}
