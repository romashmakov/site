import { NextResponse } from "next/server";
import { z } from "zod";
import { createImportDraftsFromList } from "@/lib/import-drafts";

export const runtime = "nodejs";
export const maxDuration = 300;

const optionalNumber = z.preprocess((value) => {
  if (value === "" || value === null || value === undefined) return undefined;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : value;
}, z.number().optional());

const importListSchema = z.object({
  sourceUrl: z.string().url("Укажите корректную ссылку на список"),
  limit: z.coerce.number().int().min(1).max(300).default(10),
  brand: z.string().trim().optional(),
  model: z.string().trim().optional(),
  city: z.string().trim().optional(),
  engineType: z.enum(["ANY", "GAS", "HYBRID", "ELECTRIC"]).default("ANY"),
  gearbox: z.enum(["ANY", "Автомат", "Робот", "Вариатор", "Механика"]).default("ANY"),
  drive: z.enum(["ANY", "Передний", "Задний", "Полный"]).default("ANY"),
  yearFrom: optionalNumber,
  yearTo: optionalNumber,
  mileageMax: optionalNumber,
  priceCnyFrom: optionalNumber,
  priceCnyTo: optionalNumber
});

export async function POST(request: Request) {
  const json = await request.json();
  const parsed = importListSchema.safeParse(json);

  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Некорректные данные" }, { status: 400 });
  }

  const result = await createImportDraftsFromList(parsed.data.sourceUrl, parsed.data.limit, {
    brand: parsed.data.brand,
    model: parsed.data.model,
    city: parsed.data.city,
    engineType: parsed.data.engineType,
    gearbox: parsed.data.gearbox,
    drive: parsed.data.drive,
    yearFrom: parsed.data.yearFrom,
    yearTo: parsed.data.yearTo,
    mileageMax: parsed.data.mileageMax,
    priceCnyFrom: parsed.data.priceCnyFrom,
    priceCnyTo: parsed.data.priceCnyTo
  });

  const updatedCars = "updatedCars" in result && Array.isArray(result.updatedCars) ? result.updatedCars : [];

  if (!result.imported.length && !updatedCars.length) {
    return NextResponse.json(
      {
        error: result.blocked
          ? "Источник отдал anti-bot challenge, ссылки объявлений не найдены"
          : "Подходящие объявления не найдены. Попробуйте убрать фильтр или увеличить лимит.",
        ...result
      },
      { status: 422 }
    );
  }

  return NextResponse.json(
    {
      ...result,
      importedIds: result.imported.map((draft) => draft.id),
      updatedCarIds: updatedCars.map((car) => car.id)
    },
    { status: 201 }
  );
}
