import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const drafts = await prisma.importDraft.findMany({
    orderBy: { createdAt: "desc" }
  });
  return NextResponse.json({ items: drafts });
}

export async function DELETE(request: Request) {
  const json = await request.json().catch(() => ({}));
  const ids: string[] = Array.isArray(json.ids)
    ? json.ids.filter((id: unknown): id is string => typeof id === "string" && id.length > 0)
    : [];
  const uniqueIds: string[] = [...new Set(ids)];

  if (!uniqueIds.length) {
    return NextResponse.json({ error: "Выберите черновики для удаления" }, { status: 400 });
  }

  const result = await prisma.importDraft.deleteMany({
    where: {
      id: {
        in: uniqueIds
      }
    }
  });

  return NextResponse.json({ deletedCount: result.count });
}
