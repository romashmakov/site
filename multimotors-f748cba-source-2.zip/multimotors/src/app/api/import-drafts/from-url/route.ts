import { NextResponse } from "next/server";
import { z } from "zod";
import { createImportDraftFromUrl } from "@/lib/import-drafts";

export const runtime = "nodejs";
export const maxDuration = 120;

const importUrlSchema = z.object({
  sourceUrl: z.string().url("Укажите корректную ссылку")
});

export async function POST(request: Request) {
  const json = await request.json();
  const parsed = importUrlSchema.safeParse(json);

  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Некорректная ссылка" }, { status: 400 });
  }

  const draft = await createImportDraftFromUrl(parsed.data.sourceUrl);
  return NextResponse.json({ item: draft }, { status: 201 });
}
