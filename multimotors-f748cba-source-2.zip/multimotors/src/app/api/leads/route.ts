import { NextResponse } from "next/server";
import { leadInputSchema } from "@/lib/validation";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const leads = await prisma.lead.findMany({
    include: { car: true },
    orderBy: { createdAt: "desc" }
  });
  return NextResponse.json({ items: leads });
}

export async function POST(request: Request) {
  const json = await request.json();
  const parsed = leadInputSchema.safeParse(json);

  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Некорректные данные" }, { status: 400 });
  }

  const lead = await prisma.lead.create({
    data: {
      carId: parsed.data.carId || null,
      name: parsed.data.name,
      phone: parsed.data.phone,
      preferredContact: parsed.data.preferredContact,
      comment: parsed.data.comment || null
    }
  });

  return NextResponse.json({ item: lead }, { status: 201 });
}
