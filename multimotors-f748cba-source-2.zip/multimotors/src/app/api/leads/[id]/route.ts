import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { leadUpdateSchema } from "@/lib/validation";

type RouteProps = {
  params: Promise<{ id: string }>;
};

export async function PATCH(request: Request, { params }: RouteProps) {
  const { id } = await params;
  const json = await request.json();
  const parsed = leadUpdateSchema.safeParse(json);

  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Некорректные данные" }, { status: 400 });
  }

  const lead = await prisma.lead.update({
    where: { id },
    data: {
      status: parsed.data.status
    }
  });

  return NextResponse.json({ item: lead });
}
