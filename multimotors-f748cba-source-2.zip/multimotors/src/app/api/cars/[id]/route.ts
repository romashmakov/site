import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { carUpdateSchema } from "@/lib/validation";

type RouteProps = {
  params: Promise<{ id: string }>;
};

export async function GET(_request: Request, { params }: RouteProps) {
  const { id } = await params;
  const car = await prisma.car.findUnique({ where: { id } });

  if (!car) {
    return NextResponse.json({ error: "Карточка не найдена" }, { status: 404 });
  }

  return NextResponse.json({ item: car });
}

export async function PATCH(request: Request, { params }: RouteProps) {
  const { id } = await params;
  const json = await request.json();
  const parsed = carUpdateSchema.safeParse(json);

  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Некорректные данные" }, { status: 400 });
  }

  const input = parsed.data;
  const data = {
    ...input,
    sourceUrl: input.sourceUrl === "" ? null : input.sourceUrl,
    externalId: input.externalId === "" ? null : input.externalId,
    trim: input.trim === "" ? null : input.trim,
    city: input.city === "" ? null : input.city,
    body: input.body === "" ? null : input.body,
    gearbox: input.gearbox === "" ? null : input.gearbox,
    drive: input.drive === "" ? null : input.drive,
    power: input.power === "" ? null : input.power,
    battery: input.battery === "" ? null : input.battery,
    color: input.color === "" ? null : input.color,
    vin: input.vin === "" ? null : input.vin,
    descriptionOrig: input.descriptionOrig === "" ? null : input.descriptionOrig,
    aiSummary: input.aiSummary === "" ? null : input.aiSummary,
    rangeKm: input.rangeKm === "" ? null : input.rangeKm,
    priceCny: input.priceCny === "" ? null : input.priceCny,
    imageUrls: input.imageUrls ? JSON.stringify(input.imageUrls) : undefined,
    publishedAt: input.status === "PUBLISHED" ? new Date() : input.status ? null : undefined
  };

  const car = await prisma.car.update({
    where: { id },
    data
  });

  return NextResponse.json({ item: car });
}

export async function DELETE(request: Request, { params }: RouteProps) {
  const { id } = await params;
  const permanent = new URL(request.url).searchParams.get("permanent") === "1";

  if (permanent) {
    const car = await prisma.car.delete({ where: { id } });
    return NextResponse.json({ item: car });
  }

  const car = await prisma.car.update({
    where: { id },
    data: {
      status: "ARCHIVED",
      publishedAt: null
    }
  });

  return NextResponse.json({ item: car });
}
