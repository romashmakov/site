import { NextResponse } from "next/server";
import { carInputSchema } from "@/lib/validation";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const cars = await prisma.car.findMany({
    orderBy: [{ publishedAt: "desc" }, { createdAt: "desc" }]
  });
  return NextResponse.json({ items: cars });
}

export async function POST(request: Request) {
  const json = await request.json();
  const parsed = carInputSchema.safeParse(json);

  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Некорректные данные" }, { status: 400 });
  }

  const input = parsed.data;
  const car = await prisma.car.create({
    data: {
      type: input.type,
      status: input.status,
      source: input.source ?? "MANUAL",
      sourceUrl: input.sourceUrl || null,
      externalId: input.externalId || null,
      brand: input.brand,
      model: input.model,
      trim: input.trim || null,
      year: input.year,
      mileageKm: input.mileageKm,
      city: input.city || null,
      body: input.body || null,
      engineType: input.engineType,
      gearbox: input.gearbox || null,
      drive: input.drive || null,
      power: input.power || null,
      battery: input.battery || null,
      rangeKm: input.rangeKm === "" ? null : input.rangeKm || null,
      color: input.color || null,
      vin: input.vin || null,
      priceCny: input.priceCny === "" ? null : input.priceCny || null,
      priceRub: input.priceRub,
      deliveryRub: input.deliveryRub,
      customsRub: input.customsRub,
      commissionRub: input.commissionRub,
      descriptionRu: input.descriptionRu,
      descriptionOrig: input.descriptionOrig || null,
      aiSummary: input.aiSummary || null,
      imageUrls: JSON.stringify(input.imageUrls),
      publishedAt: input.status === "PUBLISHED" ? new Date() : null
    }
  });

  return NextResponse.json({ item: car }, { status: 201 });
}
