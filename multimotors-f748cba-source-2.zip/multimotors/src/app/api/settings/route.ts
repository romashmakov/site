import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getSettings, SETTINGS_ID } from "@/lib/settings";

const settingsSchema = z.object({
  companyName: z.string().min(2, "Укажите название компании"),
  phone: z.string().min(7, "Укажите телефон"),
  whatsapp: z.string().optional().or(z.literal("")),
  telegram: z.string().optional().or(z.literal("")),
  instagram: z.string().regex(/^https:\/\/(www\.)?instagram\.com\//, "Укажите ссылку на Instagram").optional().or(z.literal("")),
  usdRate: z.coerce.number().positive("Курс USD → RUB должен быть больше 0"),
  cnyRate: z.coerce.number().positive("Курс должен быть больше 0"),
  defaultDeliveryRub: z.coerce.number().int().min(0),
  customsRate: z.coerce.number().min(0).max(1),
  minCustomsRub: z.coerce.number().int().min(0),
  defaultCommissionRub: z.coerce.number().int().min(0)
});

export async function GET() {
  const settings = await getSettings();
  return NextResponse.json({ item: settings });
}

export async function PATCH(request: Request) {
  const json = await request.json();
  const parsed = settingsSchema.safeParse(json);

  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Некорректные настройки" }, { status: 400 });
  }

  const input = parsed.data;
  const settings = await prisma.appSettings.upsert({
    where: { id: SETTINGS_ID },
    create: {
      id: SETTINGS_ID,
      companyName: input.companyName,
      phone: input.phone,
      whatsapp: input.whatsapp || null,
      telegram: input.telegram || null,
      instagram: input.instagram || null,
      usdRate: input.usdRate,
      cnyRate: input.cnyRate,
      defaultDeliveryRub: input.defaultDeliveryRub,
      customsRate: input.customsRate,
      minCustomsRub: input.minCustomsRub,
      defaultCommissionRub: input.defaultCommissionRub
    },
    update: {
      companyName: input.companyName,
      phone: input.phone,
      whatsapp: input.whatsapp || null,
      telegram: input.telegram || null,
      instagram: input.instagram || null,
      usdRate: input.usdRate,
      cnyRate: input.cnyRate,
      defaultDeliveryRub: input.defaultDeliveryRub,
      customsRate: input.customsRate,
      minCustomsRub: input.minCustomsRub,
      defaultCommissionRub: input.defaultCommissionRub
    }
  });

  return NextResponse.json({ item: settings });
}
