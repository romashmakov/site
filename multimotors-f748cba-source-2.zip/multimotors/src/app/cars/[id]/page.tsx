import { notFound } from "next/navigation";
import { CarGallery } from "@/components/CarGallery";
import { ContactActions } from "@/components/ContactActions";
import { Footer } from "@/components/Footer";
import { LeadForm } from "@/components/LeadForm";
import { SiteHeader } from "@/components/SiteHeader";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { formatCny, formatUsdFromRub, parseImages, sourceLabel, statusLabel, typeLabel } from "@/lib/format";
import { prisma } from "@/lib/prisma";
import { calculateCarCosts, getSettings } from "@/lib/settings";
import { stripChineseText } from "@/lib/text";

export const dynamic = "force-dynamic";

type CarPageProps = {
  params: Promise<{ id: string }>;
};

function hasTechnicalDescription(value: string) {
  return /черновик|Dongchedi|DCDApp|провер(к|и)|источник/i.test(value);
}

function publicCity(value: string | null | undefined) {
  const cleaned = stripChineseText(value, "");
  return cleaned && cleaned !== "Китай" ? cleaned : "Китай";
}

export default async function CarPage({ params }: CarPageProps) {
  const { id } = await params;
  const [car, settings] = await Promise.all([
    prisma.car.findUnique({ where: { id } }),
    getSettings()
  ]);
  if (!car) notFound();

  const images = parseImages(car.imageUrls);
  const brand = stripChineseText(car.brand, "Авто");
  const model = stripChineseText(car.model, "из Китая");
  const city = publicCity(car.city);
  const fallbackDescription = `${brand} ${model}${car.trim ? ` ${stripChineseText(car.trim, "")}` : ""}. ${car.year} год. ${
    car.mileageKm ? `Пробег ${car.mileageKm.toLocaleString("ru-RU")} км. ` : ""
  }Цена рассчитана под ключ с учетом логистики, таможенных расходов и комиссии сервиса.`;
  const rawDescriptionRu = stripChineseText(car.descriptionRu, fallbackDescription);
  const descriptionRu = hasTechnicalDescription(rawDescriptionRu) ? fallbackDescription : rawDescriptionRu;
  let sourceSpecifications: Record<string, string> = {};
  try {
    sourceSpecifications = car.specificationsJson ? JSON.parse(car.specificationsJson) : {};
  } catch {
    sourceSpecifications = {};
  }
  const additionalSpecifications = [
    ["Первая регистрация", sourceSpecifications["Дата первой рег."]],
    ["Двигатель полностью", sourceSpecifications["Двигатель (сc)"]],
    ["Руль", sourceSpecifications.Руль],
    ["Количество мест", sourceSpecifications.Мест],
    ["Количество дверей", sourceSpecifications.Дверей],
    ["Снаряженная масса", sourceSpecifications["Снаряженная масса (кg)"] ? `${sourceSpecifications["Снаряженная масса (кg)"]} кг` : ""],
    ["Габариты", sourceSpecifications["Габариты (mm)"] ? `${sourceSpecifications["Габариты (mm)"]} мм` : ""]
  ].filter(([, value]) => value && value !== "-");
  const costs = calculateCarCosts(car.priceCny, settings, {
    deliveryRub: car.deliveryRub,
    customsRub: car.customsRub,
    commissionRub: car.commissionRub
  });
  const breakdown = [
    ["Автомобиль в Китае", costs.baseRub || car.priceRub - car.deliveryRub - car.customsRub - car.commissionRub],
    ["Доставка и логистика", car.deliveryRub],
    ["Таможня и утильсбор", car.customsRub],
    ["Комиссия и услуги", car.commissionRub],
    ["Итого под ключ", car.priceRub]
  ];

  return (
    <div className="shell">
      <SiteHeader />
      <main className="main section">
        <div className="container">
          <div className="detail-grid">
            <div>
              <CarGallery images={images} title={`${brand} ${model}`} type={car.type} />

              <section className="section">
                <h2>Характеристики</h2>
                <Card className="panel">
                  <CardContent className="spec-grid p-0">
                  {[
                    ["Год", car.year],
                    ["Пробег", car.mileageKm ? `${car.mileageKm.toLocaleString("ru-RU")} км` : "Новый"],
                    ["Двигатель", car.engineType],
                    ["Мощность", car.power || "по запросу"],
                    ["Коробка", car.gearbox || "не указана"],
                    ["Привод", car.drive || "не указан"],
                    ["Кузов", car.body || "не указан"],
                    ["Цвет", car.color || "не указан"],
                    ["Батарея", car.battery || "не указана"],
                    ["Запас хода", car.rangeKm ? `${car.rangeKm} км` : "не указан"],
                    ...additionalSpecifications
                  ].map(([key, value]) => (
                    <div className="spec" key={key}>
                      <small>{key}</small>
                      <strong>{value}</strong>
                    </div>
                  ))}
                  </CardContent>
                </Card>
              </section>

              <section className="section" style={{ paddingTop: 0 }}>
                <h2>Описание</h2>
                <p style={{ lineHeight: 1.7 }}>{descriptionRu}</p>
              </section>
            </div>

            <Card className="panel price-box">
              <CardContent className="p-0">
              <span className="muted">
                {brand} · {car.year} · {city}
              </span>
              <h1 className="title-font" style={{ fontSize: 38, margin: "8px 0" }}>
                {brand} {model}
              </h1>
              <div className="price">{formatUsdFromRub(car.priceRub, settings.usdRate)}</div>
              <p className="muted">Цена в Китае: {formatCny(car.priceCny)}</p>
              <p className="muted">
                Источник: {sourceLabel[car.source]} · статус: {statusLabel[car.status]}
              </p>
              <div className="price-note">
                <strong>Что входит в цену</strong>
                <span>Автомобиль, логистика, таможенные расходы и комиссия сервиса. Стоимость указана в долларах США. Актуальный расчёт подготовит менеджер.</span>
              </div>
              <div className="breakdown">
                {breakdown.map(([label, value]) => (
                  <div key={label}>
                    <span>{label}</span>
                    <strong>{formatUsdFromRub(Number(value), settings.usdRate)}</strong>
                  </div>
                ))}
              </div>
              <ContactActions carTitle={`${brand} ${model}`} />
              <LeadForm carId={car.id} carTitle={`${brand} ${model}`} />
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
