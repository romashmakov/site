import { redirect } from "next/navigation";
import { Footer } from "@/components/Footer";
import { SiteHeader } from "@/components/SiteHeader";
import { Button } from "@/components/ui/button";
import { prisma } from "@/lib/prisma";
import { type ListingTypeValue, typeSlug } from "@/lib/format";

export const dynamic = "force-dynamic";

const sections: Array<{ type: ListingTypeValue; title: string; text: string }> = [
  {
    type: "CHINA_IMPORT",
    title: "Авто из Китая",
    text: "Проверенные предложения с расчетом доставки, таможни и итоговой цены под ключ."
  },
  {
    type: "NEW_CAR",
    title: "Новые авто",
    text: "Свежие модели и комплектации, доступные для заказа с индивидуальным расчетом."
  },
  {
    type: "IN_STOCK",
    title: "В наличии",
    text: "Автомобили, которые уже можно посмотреть, забронировать и быстро оформить."
  },
  {
    type: "CUSTOM_ORDER",
    title: "Подбор авто",
    text: "Подберем автомобиль под бюджет, сроки, комплектацию и пожелания по поставке."
  }
];

const stats = [
  { num: "45", label: "дней — ориентир поставки" },
  { num: "100%", label: "расчет цены под ключ" },
  { num: "24/7", label: "подбор по заявке" },
  { num: "0", label: "скрытых платежей" }
];

const advantages = [
  {
    num: "01",
    title: "Подбираем под задачу",
    desc: "Учитываем бюджет, сроки, тип кузова, двигатель, комплектацию и пожелания по цвету."
  },
  {
    num: "02",
    title: "Считаем цену под ключ",
    desc: "В расчет входят автомобиль, доставка, таможенные расходы и комиссия сервиса."
  },
  {
    num: "03",
    title: "Проверяем предложение",
    desc: "Перед сделкой уточняем состояние, документы, комплектацию и доступность автомобиля."
  },
  {
    num: "04",
    title: "Ведем сделку до выдачи",
    desc: "Помогаем с оплатой, логистикой, таможней и передачей автомобиля клиенту."
  },
  {
    num: "05",
    title: "Работаем прозрачно",
    desc: "Показываем ключевые расходы заранее и объясняем, из чего складывается итоговая цена."
  },
  {
    num: "06",
    title: "Всегда на связи",
    desc: "Ответим на вопросы по конкретному авто, предложим альтернативы и подготовим расчет."
  }
];

const faq = [
  {
    q: "Цена на сайте окончательная?",
    a: "Цена указана как расчет под ключ на текущий курс и условия поставки. Перед сделкой менеджер перепроверит актуальность цены и комплектации."
  },
  {
    q: "Можно заказать авто, которого нет в каталоге?",
    a: "Да. Оставьте заявку в разделе «Подбор авто», и мы подберем варианты под ваш бюджет, сроки и требования."
  },
  {
    q: "Что входит в сопровождение?",
    a: "Подбор автомобиля, расчет стоимости, проверка предложения, сопровождение оплаты, логистика, таможенное оформление и передача авто."
  },
  {
    q: "Сколько занимает доставка?",
    a: "Срок зависит от города покупки, маршрута и оформления. В среднем ориентируемся на 45 дней после согласования автомобиля и условий поставки."
  }
];

type PageProps = {
  searchParams?: Promise<Record<string, string | undefined>>;
};

function catalogHref(type: ListingTypeValue) {
  if (type === "CUSTOM_ORDER") return "/selection";
  return `/catalog?type=${typeSlug(type)}`;
}

export default async function Home({ searchParams }: PageProps) {
  const params = (await searchParams) ?? {};
  const query = new URLSearchParams();

  for (const [key, value] of Object.entries(params)) {
    if (value) query.set(key, value);
  }

  if ([...query.keys()].length) {
    redirect(`/catalog?${query.toString()}`);
  }

  const counts = await prisma.car.groupBy({
    by: ["type"],
    where: { status: "PUBLISHED" },
    _count: { _all: true }
  });
  const countByType = new Map(counts.map((item) => [item.type, item._count._all]));

  return (
    <div className="shell">
      <SiteHeader />
      <main className="main">
        <section className="hero">
          <div className="hero-inner">
            <h1>
              Автомобили, электромобили и гибриды <span>из Китая</span>
            </h1>
            <p>
              Подберем и привезем автомобиль под ваш бюджет с понятной ценой под ключ:
              стоимость авто, доставка, таможня и сопровождение сделки уже учтены в расчете.
            </p>
            <div className="hero-visual" aria-label="Автомобиль из каталога">
              <img src="/cars/zeekr.jpg" alt="Электромобиль из Китая" />
            </div>
            <div className="hero-tools">
              {sections.map((section) => (
                <a className="pill" key={section.type} href={catalogHref(section.type)}>
                  {section.title} {section.type !== "CUSTOM_ORDER" ? <strong>{countByType.get(section.type) ?? 0}</strong> : null}
                </a>
              ))}
            </div>
          </div>
        </section>

        <section className="section">
          <div className="container">
            <div className="section-title">
              <div>
                <h2>Выберите раздел</h2>
                <p className="muted">Выберите готовое предложение, автомобиль в наличии, новую модель или оставьте заявку на индивидуальный подбор.</p>
              </div>
            </div>
            <div className="section-grid">
              {sections.map((section, index) => (
                <a className="section-card" key={section.type} href={catalogHref(section.type)}>
                  <span className="section-card-num">{String(index + 1).padStart(2, "0")}</span>
                  <span className="section-card-body">
                    <span className="section-card-title-row">
                      <h3>{section.title}</h3>
                      {section.type !== "CUSTOM_ORDER" ? <span className="section-card-chip">{countByType.get(section.type) ?? 0}</span> : null}
                    </span>
                    <p className="muted">{section.text}</p>
                    <strong>{section.type === "CUSTOM_ORDER" ? "Оставить заявку →" : "Открыть каталог →"}</strong>
                  </span>
                </a>
              ))}
            </div>
          </div>
        </section>

        <section className="home-proof">
          <div className="container home-proof-inner">
            <div className="proof-visual">
              <img src="/cars/tank.jpg" alt="Автомобиль в шоуруме" />
            </div>
            <div>
              <div className="stats-grid">
                {stats.map((item) => (
                  <div className="stat-item" key={item.label}>
                    <strong>{item.num}</strong>
                    <span>{item.label}</span>
                  </div>
                ))}
              </div>
              <p>Берем на себя подбор, проверку, расчет, логистику и сопровождение сделки до передачи автомобиля.</p>
              <Button asChild className="font-extrabold">
                <a href={catalogHref("CUSTOM_ORDER")}>Отправить заявку</a>
              </Button>
            </div>
          </div>
        </section>

        <section className="section">
          <div className="container">
            <div className="section-title">
              <h2>Почему мы</h2>
            </div>
            <div className="advantages-grid">
              {advantages.map((item) => (
                <div className="advantage" key={item.num}>
                  <strong>{item.num}</strong>
                  <h3>{item.title}</h3>
                  <p>{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="section faq-section">
          <div className="container">
            <h2>Ответы на вопросы</h2>
            <div className="faq-list">
              {faq.map((item, index) => (
                <details className="faq-item" key={item.q} open={index === 0}>
                  <summary>{item.q}</summary>
                  <p>{item.a}</p>
                </details>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
