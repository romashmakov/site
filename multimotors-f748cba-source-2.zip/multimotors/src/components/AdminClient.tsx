"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { NativeSelect } from "@/components/ui/native-select";
import { TableCell, TableRow } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";

const typeOptions = [
  ["CHINA_IMPORT", "Авто из Китая"],
  ["IN_STOCK", "В наличии"],
  ["NEW_CAR", "Новый автомобиль"],
  ["CUSTOM_ORDER", "Под заказ"]
];

const sourceOptions = [
  ["MANUAL", "Добавлено вручную"],
  ["CHE168", "CHE168 Global"],
  ["DONGCHEDI", "Китайская площадка"],
  ["OTHER", "Другой источник"]
];

const statusOptions = [
  ["DRAFT", "Черновик"],
  ["REVIEW", "На проверке"],
  ["PUBLISHED", "Опубликовано"],
  ["SOLD", "Продано"],
  ["ARCHIVED", "Архив"]
];

const leadStatusOptions = [
  ["NEW", "Новая"],
  ["IN_PROGRESS", "В работе"],
  ["CLOSED", "Закрыта"]
];

const defaultImportSourceUrl =
  "https://m.dcdapp.com/motor/feoffline/usedcar_channel/car-source.html?city_name=%E5%8C%97%E4%BA%AC&used_car_entry=wap_page_main-bottom_channel_tag";

export type AdminSettingsData = {
  id: string;
  companyName: string;
  phone: string;
  whatsapp: string | null;
  telegram: string | null;
  instagram: string | null;
  usdRate: number;
  cnyRate: number;
  defaultDeliveryRub: number;
  customsRate: number;
  minCustomsRub: number;
  defaultCommissionRub: number;
};

function formatRubLocal(value: number) {
  return new Intl.NumberFormat("ru-RU").format(value) + " ₽";
}

function calculateAdminCosts(priceCny: number, settings: AdminSettingsData, deliveryRub?: number, commissionRub?: number) {
  const baseRub = Math.round(priceCny * settings.cnyRate);
  const customsRub = Math.max(Math.round(baseRub * settings.customsRate), settings.minCustomsRub);
  const safeDeliveryRub = deliveryRub ?? settings.defaultDeliveryRub;
  const safeCommissionRub = commissionRub ?? settings.defaultCommissionRub;

  return {
    baseRub,
    deliveryRub: safeDeliveryRub,
    customsRub,
    commissionRub: safeCommissionRub,
    priceRub: baseRub + safeDeliveryRub + customsRub + safeCommissionRub
  };
}

export function AdminLoginForm({ nextPath }: { nextPath: string }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError("");
    const formData = new FormData(event.currentTarget);
    const response = await fetch("/api/admin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password: String(formData.get("password") || "") })
    });
    setBusy(false);

    if (!response.ok) {
      const body = await response.json().catch(() => ({}));
      setError(body.error || "Не удалось войти");
      return;
    }

    window.location.href = nextPath || "/admin";
  }

  return (
    <form className="admin-form login-form" onSubmit={onSubmit}>
      <Input name="password" type="password" placeholder="Пароль админки" autoFocus required />
      <Button type="submit" disabled={busy} className="font-extrabold">
        {busy ? "Проверяем..." : "Войти"}
      </Button>
      {error ? <Badge variant="destructive">{error}</Badge> : null}
    </form>
  );
}

export function AdminLogoutButton() {
  async function logout() {
    await fetch("/api/admin/logout", { method: "POST" });
    window.location.href = "/admin/login";
  }

  return (
    <Button variant="secondary" type="button" onClick={logout} className="font-extrabold">
      Выйти
    </Button>
  );
}

export function SettingsForm({ settings }: { settings: AdminSettingsData }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setMessage("");
    const payload = Object.fromEntries(new FormData(event.currentTarget).entries());
    try {
      const response = await fetch("/api/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) {
        setMessage(body.error || "Не удалось сохранить настройки");
        return;
      }
      setMessage("Настройки сохранены");
      router.refresh();
    } catch {
      setMessage("Не удалось сохранить настройки. Проверьте соединение и повторите попытку.");
    } finally {
      setBusy(false);
    }
  }

  const example = calculateAdminCosts(200_000, settings);

  return (
    <form className="admin-form" onSubmit={onSubmit}>
      <div className="settings-field">
        <Label htmlFor="settings-companyName">Название компании</Label>
        <Input id="settings-companyName" name="companyName" type="text" defaultValue={settings.companyName} required />
      </div>
      <div className="settings-field">
        <Label htmlFor="settings-phone">Телефон на сайте</Label>
        <Input id="settings-phone" name="phone" type="tel" defaultValue={settings.phone} required />
      </div>
      <div className="settings-field">
        <Label htmlFor="settings-whatsapp">WhatsApp: номер или ссылка</Label>
        <Input id="settings-whatsapp" name="whatsapp" type="text" defaultValue={settings.whatsapp ?? ""} />
      </div>
      <div className="settings-field">
        <Label htmlFor="settings-telegram">Telegram: username или ссылка</Label>
        <Input id="settings-telegram" name="telegram" type="text" defaultValue={settings.telegram ?? ""} />
      </div>
      <div className="settings-field">
        <Label htmlFor="settings-instagram">Instagram: ссылка на профиль</Label>
        <Input id="settings-instagram" name="instagram" type="url" defaultValue={settings.instagram ?? ""} />
      </div>
      <div className="settings-field">
        <Label htmlFor="settings-usdRate">Курс USD → RUB (рублей за 1 $)</Label>
        <Input id="settings-usdRate" name="usdRate" type="number" step="0.0001" min="0.0001" defaultValue={settings.usdRate} required />
      </div>
      <div className="settings-field">
        <Label htmlFor="settings-cnyRate">Курс CNY → RUB</Label>
        <Input id="settings-cnyRate" name="cnyRate" type="number" step="0.0001" min="0.0001" defaultValue={settings.cnyRate} required />
      </div>
      <div className="settings-field">
        <Label htmlFor="settings-defaultDeliveryRub">Доставка по умолчанию, ₽</Label>
        <Input id="settings-defaultDeliveryRub" name="defaultDeliveryRub" type="number" step="1" min="0" defaultValue={settings.defaultDeliveryRub} required />
      </div>
      <div className="settings-field">
        <Label htmlFor="settings-customsRate">Таможня, доля: 0.16</Label>
        <Input id="settings-customsRate" name="customsRate" type="number" step="0.01" min="0" defaultValue={settings.customsRate} required />
      </div>
      <div className="settings-field">
        <Label htmlFor="settings-minCustomsRub">Минимум таможни, ₽</Label>
        <Input id="settings-minCustomsRub" name="minCustomsRub" type="number" step="1" min="0" defaultValue={settings.minCustomsRub} required />
      </div>
      <div className="settings-field">
        <Label htmlFor="settings-defaultCommissionRub">Комиссия, ₽</Label>
        <Input id="settings-defaultCommissionRub" name="defaultCommissionRub" type="number" step="1" min="0" defaultValue={settings.defaultCommissionRub} required />
      </div>
      <p className="muted wide">Долларовый курс используется в каталоге, карточках и фильтрах. Он задаётся вручную; исходные суммы в базе остаются в RUB.</p>
      <p className="muted wide">
        Формула: цена в Китае × курс + доставка + max(цена × таможенный %, минимум) + комиссия. Пример для ¥200 000:
        {" "}
        {formatRubLocal(example.priceRub)}.
      </p>
      <Button type="submit" disabled={busy} className="font-extrabold">
        {busy ? "Сохраняем..." : "Сохранить настройки"}
      </Button>
      {message ? <Badge>{message}</Badge> : null}
    </form>
  );
}

export type AdminCarRowData = {
  id: string;
  type: string;
  status: string;
  brand: string;
  model: string;
  trim: string;
  year: number;
  mileageKm: number;
  city: string;
  body: string;
  engineType: string;
  gearbox: string;
  drive: string;
  power: string;
  battery: string;
  rangeKm: number | "";
  color: string;
  priceCny: number | "";
  priceRub: number;
  deliveryRub: number;
  customsRub: number;
  commissionRub: number;
  descriptionRu: string;
  aiSummary: string;
  imageUrls: string;
  sourceUrl: string;
  sourceLastSeenAt: string;
  sourceMissingSince: string;
  sourceMissingCount: number;
};

function ImageUrlsField({ defaultValue = "" }: { defaultValue?: string }) {
  const [value, setValue] = useState(defaultValue);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  const images = value
    .split("\n")
    .map((url) => url.trim())
    .filter(Boolean);

  async function upload(event: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(event.target.files || []);
    if (!files.length) return;

    setBusy(true);
    setMessage("");
    const formData = new FormData();
    files.forEach((file) => formData.append("files", file));
    const response = await fetch("/api/uploads", { method: "POST", body: formData });
    const body = await response.json().catch(() => ({}));
    setBusy(false);
    event.target.value = "";

    if (!response.ok) {
      setMessage(body.error || "Не удалось загрузить фото");
      return;
    }

    setValue([...images, ...(body.urls || [])].join("\n"));
    setMessage(`Загружено: ${body.urls?.length ?? 0}`);
  }

  return (
    <div className="wide image-field">
      <label className="upload-control">
        <Input type="file" accept="image/*" multiple onChange={upload} disabled={busy} />
        <Button asChild variant="secondary" className="font-extrabold">
          <span>{busy ? "Загружаем..." : "Загрузить фото"}</span>
        </Button>
        <span className="muted">Первое фото будет главным. Порядок можно менять строками.</span>
      </label>
      {images.length ? (
        <div className="image-preview-grid">
          {images.slice(0, 8).map((image, index) => (
            <figure key={`${image}-${index}`}>
              <img src={image} alt={`Фото ${index + 1}`} />
              <figcaption>{index === 0 ? "Главное" : `Фото ${index + 1}`}</figcaption>
            </figure>
          ))}
        </div>
      ) : (
        <div className="empty-inline">Фото пока нет. Загрузите файлы или вставьте ссылки ниже.</div>
      )}
      <Textarea name="imageUrls" value={value} onChange={(event) => setValue(event.target.value)} placeholder="Фото, по одному URL на строку" rows={3} />
      {message ? <Badge>{message}</Badge> : null}
    </div>
  );
}

export function AdminCreateCar({ settings }: { settings: AdminSettingsData }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [photoFieldKey, setPhotoFieldKey] = useState(0);
  const [priceFields, setPriceFields] = useState({
    priceCny: "",
    priceRub: "",
    deliveryRub: String(settings.defaultDeliveryRub),
    customsRub: "",
    commissionRub: String(settings.defaultCommissionRub)
  });

  function updatePriceField(name: keyof typeof priceFields, value: string) {
    setPriceFields((current) => ({ ...current, [name]: value }));
  }

  function recalculatePrice() {
    const priceCny = Number(priceFields.priceCny);
    if (!Number.isFinite(priceCny) || priceCny <= 0) {
      setMessage("Укажите цену в CNY, чтобы рассчитать цену под ключ");
      return;
    }

    const deliveryRub = Number(priceFields.deliveryRub || settings.defaultDeliveryRub);
    const commissionRub = Number(priceFields.commissionRub || settings.defaultCommissionRub);
    const costs = calculateAdminCosts(priceCny, settings, deliveryRub, commissionRub);
    setPriceFields({
      priceCny: String(priceCny),
      priceRub: String(costs.priceRub),
      deliveryRub: String(costs.deliveryRub),
      customsRub: String(costs.customsRub),
      commissionRub: String(costs.commissionRub)
    });
    setMessage(`Рассчитано: база ${formatRubLocal(costs.baseRub)}, итог ${formatRubLocal(costs.priceRub)}`);
  }

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setMessage("");
    const form = event.currentTarget;
    const data = new FormData(form);
    const imageUrls = String(data.get("imageUrls") || "")
      .split("\n")
      .map((url) => url.trim())
      .filter(Boolean);
    const payload = Object.fromEntries(data.entries());
    const response = await fetch("/api/cars", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...payload, imageUrls })
    });
    if (!response.ok) {
      const body = await response.json().catch(() => ({}));
      setMessage(body.error || "Ошибка сохранения");
      return;
    }
    form.reset();
    setPriceFields({
      priceCny: "",
      priceRub: "",
      deliveryRub: String(settings.defaultDeliveryRub),
      customsRub: "",
      commissionRub: String(settings.defaultCommissionRub)
    });
    setPhotoFieldKey((value) => value + 1);
    setMessage("Карточка создана");
    setOpen(false);
    router.refresh();
  }

  useEffect(() => {
    if (!open) return;

    function onKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") setOpen(false);
    }

    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [open]);

  return (
    <>
      <Button type="button" onClick={() => setOpen(true)} className="admin-action-button font-extrabold">
        Добавить авто вручную
      </Button>
      {message && !open ? <Badge className="admin-action-message">{message}</Badge> : null}
      {open ? (
        <div className="admin-modal-backdrop" role="presentation" onMouseDown={() => setOpen(false)}>
          <section className="admin-modal" role="dialog" aria-modal="true" aria-labelledby="manual-car-title" onMouseDown={(event) => event.stopPropagation()}>
            <div className="admin-modal-header">
              <div>
                <h2 id="manual-car-title">Ручная публикация авто</h2>
                <p className="muted">Добавьте авто в наличии, новый автомобиль, предложение под заказ или карточку из Китая.</p>
              </div>
              <Button variant="ghost" type="button" onClick={() => setOpen(false)} className="font-extrabold">
                Закрыть
              </Button>
            </div>
            <form className="admin-form admin-modal-form" onSubmit={onSubmit}>
              <div className="form-section-title wide">
                <strong>Публикация</strong>
                <span>Тип, статус и источник карточки</span>
              </div>
              <NativeSelect name="type" defaultValue="IN_STOCK" className="w-full">
                {typeOptions.map(([value, label]) => (
                  <option key={value} value={value}>
                    {label}
                  </option>
                ))}
              </NativeSelect>
              <NativeSelect name="status" defaultValue="PUBLISHED" className="w-full">
                <option value="PUBLISHED">Опубликовать</option>
                <option value="DRAFT">Черновик</option>
                <option value="REVIEW">На проверку</option>
              </NativeSelect>
              <NativeSelect name="source" defaultValue="MANUAL" className="w-full">
                {sourceOptions.map(([value, label]) => (
                  <option key={value} value={value}>
                    {label}
                  </option>
                ))}
              </NativeSelect>
              <div className="form-section-title wide">
                <strong>Автомобиль</strong>
                <span>Основные данные, которые увидит клиент в каталоге</span>
              </div>
              <Input name="brand" placeholder="Марка" required />
              <Input name="model" placeholder="Модель" required />
              <Input name="trim" placeholder="Комплектация" />
              <Input name="year" type="number" placeholder="Год" defaultValue={2026} required />
              <Input name="mileageKm" type="number" placeholder="Пробег, км" defaultValue={0} />
              <Input name="city" placeholder="Город / локация" />
              <Input name="body" placeholder="Кузов" />
              <Input name="engineType" placeholder="Тип двигателя" required />
              <Input name="gearbox" placeholder="Коробка" />
              <Input name="drive" placeholder="Привод" />
              <Input name="power" placeholder="Мощность" />
              <Input name="battery" placeholder="Батарея" />
              <Input name="rangeKm" type="number" placeholder="Запас хода, км" />
              <Input name="color" placeholder="Цвет" />
              <div className="form-section-title wide">
                <strong>Цена</strong>
                <span>Можно указать вручную или рассчитать по текущим настройкам проекта</span>
              </div>
              <Input name="priceCny" type="number" placeholder="Цена в Китае, CNY" value={priceFields.priceCny} onChange={(event) => updatePriceField("priceCny", event.target.value)} />
              <Input name="priceRub" type="number" placeholder="Цена под ключ, ₽" value={priceFields.priceRub} onChange={(event) => updatePriceField("priceRub", event.target.value)} required />
              <Input name="deliveryRub" type="number" placeholder="Доставка, ₽" value={priceFields.deliveryRub} onChange={(event) => updatePriceField("deliveryRub", event.target.value)} />
              <Input name="customsRub" type="number" placeholder="Таможня, ₽" value={priceFields.customsRub} onChange={(event) => updatePriceField("customsRub", event.target.value)} />
              <Input name="commissionRub" type="number" placeholder="Комиссия, ₽" value={priceFields.commissionRub} onChange={(event) => updatePriceField("commissionRub", event.target.value)} />
              <Button variant="secondary" type="button" onClick={recalculatePrice} className="font-extrabold">
                Рассчитать цену
              </Button>
              <div className="form-section-title wide">
                <strong>Описание и фото</strong>
                <span>Первое фото станет главным на витрине</span>
              </div>
              <Input className="wide" name="sourceUrl" type="url" placeholder="URL оригинального объявления" />
              <Textarea className="wide" name="descriptionRu" placeholder="Описание на русском" rows={4} required />
              <Textarea className="wide" name="aiSummary" placeholder="AI-комментарий / нормализация" rows={2} />
              <ImageUrlsField key={photoFieldKey} />
              <Button type="submit" className="font-extrabold">
                Создать карточку
              </Button>
              {message ? <Badge>{message}</Badge> : null}
            </form>
          </section>
        </div>
      ) : null}
    </>
  );
}

export function ImportUrlDraftForm() {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setMessage("");
    const form = event.currentTarget;
    const data = new FormData(form);
    const response = await fetch("/api/import-drafts/from-url", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sourceUrl: String(data.get("sourceUrl") || "") })
    });
    setBusy(false);

    if (!response.ok) {
      const body = await response.json().catch(() => ({}));
      setMessage(body.error || "Не удалось создать черновик");
      return;
    }

    form.reset();
    setMessage("Объявление добавлено в очередь проверки");
    router.refresh();
  }

  return (
    <form className="admin-form import-url-form" onSubmit={onSubmit}>
      <Input className="wide" name="sourceUrl" type="url" placeholder="Ссылка на объявление" required />
      <Button type="submit" disabled={busy} className="font-extrabold">
        {busy ? "Добавляем..." : "Добавить объявление"}
      </Button>
      {message ? <Badge>{message}</Badge> : null}
    </form>
  );
}

export function ImportListDraftForm() {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setMessage("");
    const form = event.currentTarget;
    const data = new FormData(form);
    const response = await fetch("/api/import-drafts/from-list", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        sourceUrl: String(data.get("sourceUrl") || ""),
        limit: Number(data.get("limit") || 10),
        brand: String(data.get("brand") || ""),
        model: String(data.get("model") || ""),
        city: String(data.get("city") || ""),
        engineType: String(data.get("engineType") || "ANY"),
        gearbox: String(data.get("gearbox") || "ANY"),
        drive: String(data.get("drive") || "ANY"),
        yearFrom: String(data.get("yearFrom") || ""),
        yearTo: String(data.get("yearTo") || ""),
        mileageMax: String(data.get("mileageMax") || ""),
        priceCnyFrom: String(data.get("priceCnyFrom") || ""),
        priceCnyTo: String(data.get("priceCnyTo") || "")
      })
    });
    const body = await response.json().catch(() => ({}));
    setBusy(false);

    if (!response.ok) {
      setMessage(body.error || "Не удалось импортировать список");
      return;
    }

    form.reset();
    const importedCount = body.importedIds?.length ?? 0;
    const updatedCount = body.updatedCarIds?.length ?? 0;
    const uniqueText =
      typeof body.uniqueFound === "number" && typeof body.requestedLimit === "number"
        ? ` Собрано уникальных: ${body.uniqueFound} из запрошенных ${body.requestedLimit}.`
        : "";
    const totalText = typeof body.sourceTotal === "number" ? ` Всего в выдаче источника: ${body.sourceTotal}.` : "";
    const scannedText = body.scanned ? ` Просмотрено у источника: ${body.scanned}.` : "";
    const missingText = body.missing?.checked ? ` Не найдено при проверке: ${body.missing.count}.` : "";
    setMessage(`Новых черновиков: ${importedCount}. Обновлено карточек: ${updatedCount}.${uniqueText}${totalText}${scannedText}${missingText}`);
    router.refresh();
  }

  return (
    <form className="import-filter-form" onSubmit={onSubmit}>
      <div className="import-filter-head">
        <div>
          <span className="admin-kicker">Фильтры импорта</span>
          <strong>Подборка из китайской базы</strong>
        </div>
        <Badge>до 300 авто за запуск</Badge>
      </div>

      <div className="import-field import-field-wide">
        <Label htmlFor="import-source-url">Ссылка на источник</Label>
        <Input
          id="import-source-url"
          name="sourceUrl"
          type="url"
          defaultValue={defaultImportSourceUrl}
          placeholder="URL списка CHE168 Global или Dongchedi / DCDApp"
          required
        />
      </div>

      <div className="import-filter-section">
        <span>Автомобиль</span>
        <div className="import-field">
          <Label htmlFor="import-brand">Бренд</Label>
          <Input id="import-brand" name="brand" placeholder="Geely / 吉利 / Geely Xingyue L" />
        </div>
        <div className="import-field">
          <Label htmlFor="import-model">Модель</Label>
          <Input id="import-model" name="model" placeholder="Xingyue L / Xing Yue L / 星越L" />
        </div>
        <div className="import-field">
          <Label htmlFor="import-city">Город</Label>
          <Input id="import-city" name="city" placeholder="Пекин / 北京" />
        </div>
      </div>

      <div className="import-filter-section">
        <span>Год и бюджет</span>
        <div className="import-field">
          <Label htmlFor="import-year-from">Год от</Label>
          <Input id="import-year-from" name="yearFrom" type="number" min={1990} max={2030} placeholder="2022" />
        </div>
        <div className="import-field">
          <Label htmlFor="import-year-to">Год до</Label>
          <Input id="import-year-to" name="yearTo" type="number" min={1990} max={2030} placeholder="2026" />
        </div>
        <div className="import-field">
          <Label htmlFor="import-mileage">Пробег до, км</Label>
          <Input id="import-mileage" name="mileageMax" type="number" min={0} placeholder="50000" />
        </div>
        <div className="import-field">
          <Label htmlFor="import-price-from">Цена CNY от</Label>
          <Input id="import-price-from" name="priceCnyFrom" type="number" min={0} placeholder="50000" />
        </div>
        <div className="import-field">
          <Label htmlFor="import-price-to">Цена CNY до</Label>
          <Input id="import-price-to" name="priceCnyTo" type="number" min={0} placeholder="150000" />
        </div>
      </div>

      <div className="import-filter-section">
        <span>Характеристики</span>
        <div className="import-field">
          <Label htmlFor="import-engine">Двигатель</Label>
          <NativeSelect id="import-engine" name="engineType" defaultValue="ANY">
            <option value="ANY">Любой</option>
            <option value="GAS">Бензин</option>
            <option value="HYBRID">Гибрид</option>
            <option value="ELECTRIC">Электро</option>
          </NativeSelect>
        </div>
        <div className="import-field">
          <Label htmlFor="import-gearbox">Коробка</Label>
          <NativeSelect id="import-gearbox" name="gearbox" defaultValue="ANY">
            <option value="ANY">Любая</option>
            <option value="Автомат">Автомат</option>
            <option value="Робот">Робот</option>
            <option value="Вариатор">Вариатор</option>
            <option value="Механика">Механика</option>
          </NativeSelect>
        </div>
        <div className="import-field">
          <Label htmlFor="import-drive">Привод</Label>
          <NativeSelect id="import-drive" name="drive" defaultValue="ANY">
            <option value="ANY">Любой</option>
            <option value="Передний">Передний</option>
            <option value="Задний">Задний</option>
            <option value="Полный">Полный</option>
          </NativeSelect>
        </div>
      </div>

      <div className="import-filter-footer">
        <div className="import-field import-limit-field">
          <Label htmlFor="import-limit">Сколько загрузить</Label>
          <Input id="import-limit" name="limit" type="number" min={1} max={300} defaultValue={10} />
        </div>
        <Button type="submit" disabled={busy} className="font-extrabold">
          {busy ? "Ищем авто..." : "Загрузить подборку"}
        </Button>
      </div>
      {message ? <Badge>{message}</Badge> : null}
    </form>
  );
}

export function PublishDraftButton({ draftId }: { draftId: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function publish() {
    setBusy(true);
    await fetch(`/api/import-drafts/${draftId}/publish`, { method: "POST" });
    setBusy(false);
    router.refresh();
  }

  return (
    <Button variant="ghost" type="button" onClick={publish} disabled={busy} className="font-extrabold">
      {busy ? "Публикуем..." : "В карточку"}
    </Button>
  );
}

export function RetryDraftButton({ draftId }: { draftId: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function retry() {
    setBusy(true);
    await fetch(`/api/import-drafts/${draftId}/retry`, { method: "POST" });
    setBusy(false);
    router.refresh();
  }

  return (
    <Button variant="ghost" type="button" onClick={retry} disabled={busy} className="font-extrabold">
      {busy ? "Обновляем..." : "Обновить данные"}
    </Button>
  );
}

export function DeleteDraftButton({ draftId, title }: { draftId: string; title: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function remove() {
    if (!confirm(`Удалить черновик "${title}"?`)) return;
    setBusy(true);
    const response = await fetch(`/api/import-drafts/${draftId}`, { method: "DELETE" });
    setBusy(false);

    if (!response.ok) {
      const body = await response.json().catch(() => ({}));
      alert(body.error || "Не удалось удалить черновик");
      return;
    }

    router.refresh();
  }

  return (
    <Button variant="ghost" type="button" onClick={remove} disabled={busy} className="font-extrabold text-red-700">
      {busy ? "Удаляем..." : "Удалить"}
    </Button>
  );
}

export function BulkDeleteDraftsForm({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  function setAllChecked(form: HTMLFormElement, checked: boolean) {
    form.querySelectorAll<HTMLInputElement>('input[name="draftId"]').forEach((input) => {
      input.checked = checked;
    });
  }

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const ids = new FormData(form).getAll("draftId").map(String).filter(Boolean);

    if (!ids.length) {
      alert("Выберите хотя бы один черновик");
      return;
    }

    if (!confirm(`Удалить выбранные черновики: ${ids.length}?`)) return;

    setBusy(true);
    const response = await fetch("/api/import-drafts", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ids })
    });
    setBusy(false);

    if (!response.ok) {
      const body = await response.json().catch(() => ({}));
      alert(body.error || "Не удалось удалить выбранные черновики");
      return;
    }

    router.refresh();
  }

  return (
    <form className="bulk-delete-form" onSubmit={onSubmit}>
      <div className="bulk-actions">
        <Button type="button" variant="secondary" onClick={(event) => setAllChecked(event.currentTarget.form!, true)} className="font-extrabold">
          Выбрать все
        </Button>
        <Button type="button" variant="secondary" onClick={(event) => setAllChecked(event.currentTarget.form!, false)} className="font-extrabold">
          Снять выбор
        </Button>
        <Button type="submit" variant="destructive" disabled={busy} className="font-extrabold">
          {busy ? "Удаляем..." : "Удалить выбранные"}
        </Button>
      </div>
      {children}
    </form>
  );
}

export function CarAdminRows({ cars, settings }: { cars: AdminCarRowData[]; settings: AdminSettingsData }) {
  return (
    <>
      {cars.map((car) => (
        <CarAdminRow key={car.id} car={car} settings={settings} />
      ))}
    </>
  );
}

function CarAdminRow({ car, settings }: { car: AdminCarRowData; settings: AdminSettingsData }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [editPriceFields, setEditPriceFields] = useState({
    priceCny: String(car.priceCny || ""),
    priceRub: String(car.priceRub || ""),
    deliveryRub: String(car.deliveryRub || settings.defaultDeliveryRub),
    customsRub: String(car.customsRub || ""),
    commissionRub: String(car.commissionRub || settings.defaultCommissionRub)
  });

  function updateEditPriceField(name: keyof typeof editPriceFields, value: string) {
    setEditPriceFields((current) => ({ ...current, [name]: value }));
  }

  function recalculateEditPrice() {
    const priceCny = Number(editPriceFields.priceCny);
    if (!Number.isFinite(priceCny) || priceCny <= 0) {
      setMessage("Укажите цену в CNY для пересчета");
      return;
    }

    const deliveryRub = Number(editPriceFields.deliveryRub || settings.defaultDeliveryRub);
    const commissionRub = Number(editPriceFields.commissionRub || settings.defaultCommissionRub);
    const costs = calculateAdminCosts(priceCny, settings, deliveryRub, commissionRub);
    setEditPriceFields({
      priceCny: String(priceCny),
      priceRub: String(costs.priceRub),
      deliveryRub: String(costs.deliveryRub),
      customsRub: String(costs.customsRub),
      commissionRub: String(costs.commissionRub)
    });
    setMessage(`Пересчитано: ${formatRubLocal(costs.priceRub)}`);
  }

  async function patch(payload: Record<string, unknown>) {
    setBusy(true);
    setMessage("");
    const response = await fetch(`/api/cars/${car.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    setBusy(false);
    if (!response.ok) {
      const body = await response.json().catch(() => ({}));
      setMessage(body.error || "Ошибка обновления");
      return false;
    }
    setMessage("Сохранено");
    router.refresh();
    return true;
  }

  async function archive() {
    if (!confirm(`Архивировать ${car.brand} ${car.model}?`)) return;
    setBusy(true);
    await fetch(`/api/cars/${car.id}`, { method: "DELETE" });
    setBusy(false);
    router.refresh();
  }

  async function remove() {
    if (!confirm(`Удалить объявление ${car.brand} ${car.model} без возможности восстановления?`)) return;
    setBusy(true);
    const response = await fetch(`/api/cars/${car.id}?permanent=1`, { method: "DELETE" });
    setBusy(false);

    if (!response.ok) {
      const body = await response.json().catch(() => ({}));
      setMessage(body.error || "Не удалось удалить объявление");
      return;
    }

    router.refresh();
  }

  const sourceSyncText = car.sourceMissingSince
    ? `Не найдено в источнике с ${new Date(car.sourceMissingSince).toLocaleDateString("ru-RU")} · проверок: ${car.sourceMissingCount}`
    : car.sourceLastSeenAt
      ? `В источнике: ${new Date(car.sourceLastSeenAt).toLocaleDateString("ru-RU")}`
      : "";

  async function onEdit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    const imageUrls = String(data.get("imageUrls") || "")
      .split("\n")
      .map((url) => url.trim())
      .filter(Boolean);
    const payload = Object.fromEntries(data.entries());
    const ok = await patch({ ...payload, imageUrls });
    if (ok) setOpen(false);
  }

  return (
    <>
      <TableRow>
        <TableCell>
          <strong>
            {car.brand} {car.model}
          </strong>
          <br />
          <span className="muted">
            {car.year} · {car.city || "локация не указана"}
          </span>
          {car.sourceUrl ? (
            <>
              <br />
              <a className="muted" href={car.sourceUrl} target="_blank">
                оригинал
              </a>
            </>
          ) : null}
          {sourceSyncText ? (
            <>
              <br />
              <span className={car.sourceMissingSince ? "text-red-700" : "muted"}>{sourceSyncText}</span>
            </>
          ) : null}
        </TableCell>
        <TableCell>
          <NativeSelect defaultValue={car.type} onChange={(event) => patch({ type: event.target.value })} disabled={busy} className="w-full">
            {typeOptions.map(([value, label]) => (
              <option key={value} value={value}>
                {label}
              </option>
            ))}
          </NativeSelect>
        </TableCell>
        <TableCell>
          <NativeSelect defaultValue={car.status} onChange={(event) => patch({ status: event.target.value })} disabled={busy} className="w-full">
            {statusOptions.map(([value, label]) => (
              <option key={value} value={value}>
                {label}
              </option>
            ))}
          </NativeSelect>
        </TableCell>
        <TableCell>
          <Input
            aria-label="Цена"
            defaultValue={car.priceRub}
            inputMode="numeric"
            onBlur={(event) => {
              const value = Number(event.target.value);
              if (Number.isFinite(value) && value > 0 && value !== car.priceRub) {
                patch({ priceRub: value });
              }
            }}
          />
        </TableCell>
        <TableCell>
          <div className="row-actions">
            <Button variant="ghost" type="button" onClick={() => setOpen((value) => !value)} className="font-extrabold">
              {open ? "Скрыть" : "Редактировать"}
            </Button>
            <Button variant="secondary" type="button" onClick={archive} disabled={busy} className="font-extrabold">
              Архив
            </Button>
            <Button variant="ghost" type="button" onClick={remove} disabled={busy} className="font-extrabold text-red-700">
              Удалить
            </Button>
            {message ? <span className="muted">{message}</span> : null}
          </div>
        </TableCell>
      </TableRow>
      {open ? (
        <TableRow>
          <TableCell colSpan={5}>
            <form className="admin-form compact" onSubmit={onEdit}>
              <NativeSelect name="type" defaultValue={car.type} className="w-full">
                {typeOptions.map(([value, label]) => (
                  <option key={value} value={value}>
                    {label}
                  </option>
                ))}
              </NativeSelect>
              <NativeSelect name="status" defaultValue={car.status} className="w-full">
                {statusOptions.map(([value, label]) => (
                  <option key={value} value={value}>
                    {label}
                  </option>
                ))}
              </NativeSelect>
              <Input name="brand" defaultValue={car.brand} placeholder="Марка" required />
              <Input name="model" defaultValue={car.model} placeholder="Модель" required />
              <Input name="trim" defaultValue={car.trim} placeholder="Комплектация" />
              <Input name="year" type="number" defaultValue={car.year} placeholder="Год" required />
              <Input name="mileageKm" type="number" defaultValue={car.mileageKm} placeholder="Пробег" />
              <Input name="city" defaultValue={car.city} placeholder="Город" />
              <Input name="body" defaultValue={car.body} placeholder="Кузов" />
              <Input name="engineType" defaultValue={car.engineType} placeholder="Тип двигателя" required />
              <Input name="gearbox" defaultValue={car.gearbox} placeholder="Коробка" />
              <Input name="drive" defaultValue={car.drive} placeholder="Привод" />
              <Input name="power" defaultValue={car.power} placeholder="Мощность" />
              <Input name="battery" defaultValue={car.battery} placeholder="Батарея" />
              <Input name="rangeKm" type="number" defaultValue={car.rangeKm} placeholder="Запас хода" />
              <Input name="color" defaultValue={car.color} placeholder="Цвет" />
              <Input name="priceCny" type="number" value={editPriceFields.priceCny} onChange={(event) => updateEditPriceField("priceCny", event.target.value)} placeholder="Цена CNY" />
              <Input name="priceRub" type="number" value={editPriceFields.priceRub} onChange={(event) => updateEditPriceField("priceRub", event.target.value)} placeholder="Цена ₽" required />
              <Input name="deliveryRub" type="number" value={editPriceFields.deliveryRub} onChange={(event) => updateEditPriceField("deliveryRub", event.target.value)} placeholder="Доставка" />
              <Input name="customsRub" type="number" value={editPriceFields.customsRub} onChange={(event) => updateEditPriceField("customsRub", event.target.value)} placeholder="Таможня" />
              <Input name="commissionRub" type="number" value={editPriceFields.commissionRub} onChange={(event) => updateEditPriceField("commissionRub", event.target.value)} placeholder="Комиссия" />
              <Button variant="secondary" type="button" onClick={recalculateEditPrice} className="font-extrabold">
                Пересчитать цену
              </Button>
              <Input className="wide" name="sourceUrl" type="url" defaultValue={car.sourceUrl} placeholder="URL оригинального объявления" />
              <Textarea className="wide" name="descriptionRu" defaultValue={car.descriptionRu} rows={4} />
              <Textarea className="wide" name="aiSummary" defaultValue={car.aiSummary} rows={2} />
              <ImageUrlsField defaultValue={car.imageUrls} />
              <Button type="submit" disabled={busy} className="font-extrabold">
                Сохранить изменения
              </Button>
            </form>
          </TableCell>
        </TableRow>
      ) : null}
    </>
  );
}

export function LeadStatusSelect({ id, status }: { id: string; status: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function update(nextStatus: string) {
    setBusy(true);
    await fetch(`/api/leads/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: nextStatus })
    });
    setBusy(false);
    router.refresh();
  }

  return (
    <NativeSelect defaultValue={status} onChange={(event) => update(event.target.value)} disabled={busy} className="w-full">
      {leadStatusOptions.map(([value, label]) => (
        <option key={value} value={value}>
          {label}
        </option>
      ))}
    </NativeSelect>
  );
}
