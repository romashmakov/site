import { MessageCircle, Phone, Send } from "lucide-react";
import { getSettings, messengerHref, phoneHref } from "@/lib/settings";
import { Button } from "@/components/ui/button";

function withText(href: string, text: string) {
  if (!href) return "";
  const separator = href.includes("?") ? "&" : "?";
  if (href.includes("wa.me")) return `${href}${separator}text=${encodeURIComponent(text)}`;
  return href;
}

export async function ContactActions({ carTitle }: { carTitle?: string }) {
  const settings = await getSettings();
  const text = carTitle
    ? `Здравствуйте! Интересует ${carTitle}. Хочу получить расчет и условия.`
    : "Здравствуйте! Хочу получить консультацию по подбору авто.";
  const whatsapp = withText(messengerHref(settings.whatsapp, "whatsapp"), text);
  const telegram = messengerHref(settings.telegram, "telegram");

  return (
    <div className="contact-actions">
      <Button asChild className="w-full font-extrabold">
        <a href={phoneHref(settings.phone)}>
          <Phone aria-hidden="true" />
          Позвонить
        </a>
      </Button>
      {whatsapp ? (
        <Button asChild variant="secondary" className="w-full font-extrabold">
          <a href={whatsapp} target="_blank" rel="noopener noreferrer">
            <MessageCircle aria-hidden="true" />
            Написать в WhatsApp
          </a>
        </Button>
      ) : null}
      {telegram ? (
        <Button asChild variant="secondary" className="w-full font-extrabold">
          <a href={telegram} target="_blank" rel="noopener noreferrer">
            <Send aria-hidden="true" />
            Telegram
          </a>
        </Button>
      ) : null}
    </div>
  );
}
