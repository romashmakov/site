"use client";

import { useState } from "react";

type SafeCarImageProps = {
  src?: string | null;
  alt: string;
  title: string;
  variant: "card" | "detail";
  fallbackText?: string;
  eager?: boolean;
};

export function SafeCarImage({ src, alt, title, variant, fallbackText = "Фото будет добавлено менеджером", eager }: SafeCarImageProps) {
  const [failed, setFailed] = useState(false);

  if (!src || failed) {
    if (variant === "detail") {
      return (
        <div className="detail-placeholder">
          <strong>{title}</strong>
          <span>{fallbackText}</span>
        </div>
      );
    }

    return <span className="media-placeholder">{title.slice(0, 2)}</span>;
  }

  return <img src={src} alt={alt} loading={eager ? "eager" : "lazy"} onError={() => setFailed(true)} />;
}
