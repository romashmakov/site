"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { NativeSelect } from "@/components/ui/native-select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";

export function LeadForm({ carId, carTitle }: { carId?: string; carTitle?: string }) {
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setBusy(true);
    const form = event.currentTarget;
    const formData = new FormData(form);
    const payload = {
      carId,
      name: String(formData.get("name") || ""),
      phone: String(formData.get("phone") || ""),
      preferredContact: String(formData.get("preferredContact") || "PHONE"),
      comment: String(formData.get("comment") || "")
    };
    try {
      const response = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        setError(data.error || "Не удалось отправить заявку");
        return;
      }
      form.reset();
      setSent(true);
    } catch {
      setError("Не удалось отправить заявку. Проверьте соединение и попробуйте ещё раз.");
    } finally {
      setBusy(false);
    }
  }

  if (sent) {
    return (
      <div className="success-state" role="status">
        <strong>Заявка отправлена</strong>
        <span>Менеджер свяжется с вами и уточнит детали.</span>
      </div>
    );
  }

  return (
    <form className="lead-form" onSubmit={onSubmit}>
      {carTitle ? <p className="lead-context">Заявка по авто: <strong>{carTitle}</strong></p> : null}
      <Label htmlFor="lead-name">Ваше имя</Label>
      <Input id="lead-name" name="name" autoComplete="name" placeholder="Как к вам обращаться" required disabled={busy} />
      <Label htmlFor="lead-phone">Телефон</Label>
      <Input id="lead-phone" name="phone" type="tel" autoComplete="tel" placeholder="+375 (__) ___-__-__" minLength={7} required disabled={busy} />
      <Label htmlFor="lead-contact">Как с вами связаться</Label>
      <NativeSelect id="lead-contact" name="preferredContact" defaultValue="PHONE" className="w-full" disabled={busy}>
        <option value="PHONE">Позвонить</option>
        <option value="WHATSAPP">WhatsApp</option>
        <option value="TELEGRAM">Telegram</option>
      </NativeSelect>
      <Label htmlFor="lead-comment">Пожелания <span className="muted">(необязательно)</span></Label>
      <Textarea id="lead-comment" name="comment" placeholder="Марка, модель, бюджет в $, год и комплектация" rows={4} disabled={busy} />
      {error ? <Badge variant="destructive" role="alert">{error}</Badge> : null}
      <Button type="submit" disabled={busy} className="font-extrabold">
        {busy ? "Отправляем..." : "Оставить заявку"}
      </Button>
    </form>
  );
}
