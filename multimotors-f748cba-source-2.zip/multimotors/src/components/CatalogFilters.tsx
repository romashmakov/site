"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { LoaderCircle, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { NativeSelect } from "@/components/ui/native-select";
import { catalogYears, type CatalogFilterValues } from "@/lib/catalog";

type Props = {
  initial: CatalogFilterValues;
  baseHref: string;
  query?: string;
  brands: string[];
  models: { brand: string; model: string }[];
  engines: string[];
};

export function CatalogFilters({ initial, baseHref, query, brands, models, engines }: Props) {
  const router = useRouter();
  const [values, setValues] = useState(initial);
  const [isPending, startTransition] = useTransition();
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const serialized = JSON.stringify(initial);

  useEffect(() => {
    // Do not replace an in-progress edit when a previous request finishes.
    if (!isPending && !timer.current) setValues(JSON.parse(serialized));
  }, [serialized, isPending]);

  useEffect(() => () => { if (timer.current) clearTimeout(timer.current); }, []);

  function rangeError(next: CatalogFilterValues) {
    if (next.yearFrom && next.yearTo && Number(next.yearFrom) > Number(next.yearTo)) return "Год «от» не должен быть больше года «до».";
    if (next.minPrice && next.maxPrice && Number(next.minPrice) > Number(next.maxPrice)) return "Цена «от» не должна быть больше цены «до».";
    return "";
  }

  function navigate(next: CatalogFilterValues, reset = false) {
    if (rangeError(next)) return;
    const params = new URLSearchParams(baseHref.split("?")[1]);
    if (query && !reset) params.set("q", query);
    for (const [name, value] of Object.entries(next)) {
      if (value && !(name === "sort" && value === "new")) params.set(name, value);
    }
    const href = `/catalog${params.size ? `?${params.toString()}` : ""}`;
    startTransition(() => router.replace(href, { scroll: false }));
  }

  function change(name: keyof CatalogFilterValues, value: string, delayed = false) {
    const next = { ...values, [name]: value, ...(name === "brand" ? { model: "" } : {}) };
    setValues(next);
    if (timer.current) clearTimeout(timer.current);
    timer.current = null;
    if (delayed) {
      timer.current = setTimeout(() => { timer.current = null; navigate(next); }, 450);
    } else {
      navigate(next);
    }
  }

  function reset() {
    if (timer.current) clearTimeout(timer.current);
    timer.current = null;
    const next = { sort: "new", brand: "", model: "", engine: "", yearFrom: "", yearTo: "", minPrice: "", maxPrice: "" };
    setValues(next);
    navigate(next, true);
  }

  const availableModels = models.filter((item) => !values.brand || item.brand === values.brand);
  const uniqueModels = [...new Set(availableModels.map((item) => item.model))];
  const error = rangeError(values);

  return (
    <form className="filters" aria-label="Фильтры каталога" aria-busy={isPending} onSubmit={(event) => { event.preventDefault(); if (timer.current) clearTimeout(timer.current); timer.current = null; navigate(values); }}>
      <h3>Фильтры</h3>
      <div className="filter-group">
        <Label htmlFor="filter-sort">Сортировка</Label>
        <NativeSelect id="filter-sort" name="sort" value={values.sort} onChange={(event) => change("sort", event.target.value)}>
          <option value="new">Сначала новые публикации</option>
          <option value="price_asc">Цена по возрастанию</option>
          <option value="price_desc">Цена по убыванию</option>
          <option value="year_desc">Сначала свежий год</option>
        </NativeSelect>
      </div>
      <div className="filter-group">
        <Label htmlFor="filter-brand">Марка</Label>
        <NativeSelect id="filter-brand" name="brand" value={values.brand} onChange={(event) => change("brand", event.target.value)}>
          <option value="">Все марки</option>
          {brands.map((brand) => <option key={brand} value={brand}>{brand}</option>)}
        </NativeSelect>
      </div>
      <div className="filter-group">
        <Label htmlFor="filter-model">Модель</Label>
        <NativeSelect id="filter-model" name="model" value={values.model} onChange={(event) => change("model", event.target.value)}>
          <option value="">Все модели</option>
          {uniqueModels.map((model) => <option key={model} value={model}>{model}</option>)}
        </NativeSelect>
      </div>
      <div className="filter-group">
        <Label htmlFor="filter-engine">Двигатель</Label>
        <NativeSelect id="filter-engine" name="engine" value={values.engine} onChange={(event) => change("engine", event.target.value)}>
          <option value="">Любой</option>
          {engines.map((engine) => <option key={engine} value={engine}>{engine}</option>)}
        </NativeSelect>
      </div>
      <div className="filter-row">
        {([ ["yearFrom", "Год от"], ["yearTo", "Год до"] ] as const).map(([name, label]) => (
          <div className="filter-group" key={name}>
            <Label htmlFor={`filter-${name}`}>{label}</Label>
            <NativeSelect id={`filter-${name}`} name={name} value={values[name]} onChange={(event) => change(name, event.target.value)}>
              <option value="">Любой</option>
              {catalogYears.map((year) => <option key={year} value={year}>{year}</option>)}
            </NativeSelect>
          </div>
        ))}
      </div>
      {([ ["minPrice", "Цена от, $", "Например, 15 000"], ["maxPrice", "Цена до, $", "Например, 50 000"] ] as const).map(([name, label, placeholder]) => (
        <div className="filter-group" key={name}>
          <Label htmlFor={`filter-${name}`}>{label}</Label>
          <Input id={`filter-${name}`} name={name} type="number" inputMode="numeric" min={0} max={1_000_000_000} step={1} placeholder={placeholder} value={values[name]} onChange={(event) => change(name, event.target.value, true)} aria-invalid={!!error} aria-describedby={error ? "filter-error" : undefined} />
        </div>
      ))}
      {error ? <p id="filter-error" className="filter-error" role="alert">{error}</p> : null}
      <p className="filter-status" role="status" aria-live="polite">
        {isPending ? <><LoaderCircle size={14} className="filter-spinner" aria-hidden="true" />Обновляем список…</> : "Фильтры применяются автоматически"}
      </p>
      <Button type="button" variant="secondary" className="w-full font-extrabold" onClick={reset}><RotateCcw size={15} aria-hidden="true" />Сбросить фильтры</Button>
    </form>
  );
}
