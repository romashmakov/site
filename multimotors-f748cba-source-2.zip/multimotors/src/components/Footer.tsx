import { Clock3, Mail, MapPin, Phone } from "lucide-react";
import { getSettings, messengerHref, phoneHref } from "@/lib/settings";
import { company } from "@/lib/company";

export async function Footer() {
  const settings = await getSettings();
  const whatsapp = messengerHref(settings.whatsapp, "whatsapp");
  const telegram = messengerHref(settings.telegram, "telegram");
  const viber = `viber://chat?number=%2B${settings.phone.replace(/\D/g, "")}`;

  return (
    <footer className="footer" id="contacts">
      <div className="container contacts-grid">
        <div className="company-details">
          <h2>{company.legalName}</h2>
          <p className="muted">УНП {company.unp}</p>
          <address>{company.postalAddress}<br />{company.address}</address>
        </div>
        <div className="footer-contact">
          <h3>Контактная информация</h3>
          <a className="footer-phone" href={phoneHref(settings.phone)}><Phone size={19} aria-hidden="true" />{settings.phone}</a>
          <a href={`mailto:${company.email}`}><Mail size={17} aria-hidden="true" />{company.email}</a>
          <p><Clock3 size={17} aria-hidden="true" />{company.hours}</p>
          <p><MapPin size={17} aria-hidden="true" />{company.address}</p>
        </div>
        <div className="footer-social">
          <h3>Мессенджеры</h3>
          <div className="messenger-links">
            {telegram ? <a href={telegram} target="_blank" rel="noopener noreferrer">Telegram</a> : null}
            <a href={viber}>Viber</a>
            {whatsapp ? <a href={whatsapp} target="_blank" rel="noopener noreferrer">WhatsApp</a> : null}
          </div>
          {settings.instagram ? <><h3>Социальные сети</h3><a href={settings.instagram} target="_blank" rel="noopener noreferrer">Instagram ↗</a></> : null}
        </div>
      </div>
      <div className="footer-bar">
        <div className="container">
          <strong className="brand">{settings.companyName}</strong>
          <span>Новые автомобили, авто с пробегом и предложения в наличии</span>
        </div>
      </div>
    </footer>
  );
}
