"use client";

import { useEffect, useState } from "react";
import { ChevronLeft, ChevronRight, Maximize2, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { SafeCarImage } from "@/components/SafeCarImage";
import { typeLabel } from "@/lib/format";

type CarGalleryProps = {
  images: string[];
  title: string;
  type: string;
};

export function CarGallery({ images, title, type }: CarGalleryProps) {
  const [activeIndex, setActiveIndex] = useState(0);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const activeImage = images[activeIndex];
  const hasImages = images.length > 0;
  const canSlide = images.length > 1;

  function showPrevious() {
    if (!canSlide) return;
    setActiveIndex((index) => (index - 1 + images.length) % images.length);
  }

  function showNext() {
    if (!canSlide) return;
    setActiveIndex((index) => (index + 1) % images.length);
  }

  useEffect(() => {
    if (!lightboxOpen) return;

    function onKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") setLightboxOpen(false);
      if (event.key === "ArrowLeft") showPrevious();
      if (event.key === "ArrowRight") showNext();
    }

    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [lightboxOpen, images.length]);

  return (
    <div className="car-gallery">
      <button className="detail-media gallery-main" type="button" onClick={() => hasImages && setLightboxOpen(true)}>
        <SafeCarImage src={activeImage} alt={title} title={title} variant="detail" eager />
        <Badge className="badge" style={{ position: "absolute", top: 16, left: 16 }}>
          {typeLabel[type]}
        </Badge>
        {hasImages ? (
          <span className="gallery-open-hint">
            <Maximize2 size={16} />
            Открыть галерею
          </span>
        ) : null}
      </button>

      {canSlide ? (
        <div className="thumbs" aria-label="Фотографии автомобиля">
          {images.map((image, index) => (
            <button
              key={`${image}-${index}`}
              className={index === activeIndex ? "active" : ""}
              type="button"
              onClick={() => setActiveIndex(index)}
              aria-label={`Показать фото ${index + 1}`}
            >
              <img src={image} alt={`${title}, фото ${index + 1}`} loading="lazy" />
            </button>
          ))}
        </div>
      ) : null}

      {lightboxOpen ? (
        <div className="gallery-lightbox" role="dialog" aria-modal="true" aria-label={`Галерея ${title}`}>
          <button className="gallery-lightbox-backdrop" type="button" onClick={() => setLightboxOpen(false)} aria-label="Закрыть галерею" />
          <div className="gallery-lightbox-panel">
            <div className="gallery-lightbox-top">
              <span>
                Фото {activeIndex + 1} из {images.length}
              </span>
              <Button variant="secondary" type="button" onClick={() => setLightboxOpen(false)} className="font-extrabold">
                <X size={16} />
                Закрыть
              </Button>
            </div>
            <div className="gallery-lightbox-image">
              <img src={activeImage} alt={`${title}, фото ${activeIndex + 1}`} />
            </div>
            {canSlide ? (
              <>
                <Button className="gallery-arrow prev" type="button" onClick={showPrevious} aria-label="Предыдущее фото">
                  <ChevronLeft size={22} />
                </Button>
                <Button className="gallery-arrow next" type="button" onClick={showNext} aria-label="Следующее фото">
                  <ChevronRight size={22} />
                </Button>
              </>
            ) : null}
          </div>
        </div>
      ) : null}
    </div>
  );
}
