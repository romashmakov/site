import Link from "next/link";
import { CarFront, Phone, Search } from "lucide-react";
import { getSettings, phoneHref } from "@/lib/settings";
import { Button } from "@/components/ui/button";

const nav = [
  ["Новые авто", "/catalog?type=new"],
  ["Автомобили Б/У", "/catalog?category=used"],
  ["Электромобили Б/У", "/catalog?category=used-electric"],
  ["Гибриды Б/У", "/catalog?category=used-hybrid"],
  ["В наличии", "/catalog?type=stock"]
];

export async function SiteHeader() {
  const settings = await getSettings();

  return (
    <header className="header">
      <div className="header-inner">
        <Link className="brand" href="/">
          <span className="brand-mark">
            <CarFront aria-hidden="true" size={23} strokeWidth={2.4} />
          </span>
          <span className="brand-name">{settings.companyName}</span>
        </Link>
        <nav className="nav" aria-label="Основная навигация">
          {nav.map(([label, href]) => (
            <Link key={href} href={href}>
              {label}
            </Link>
          ))}
        </nav>
        <div className="header-actions">
          <a className="phone" href={phoneHref(settings.phone)}>
            <Phone aria-hidden="true" size={16} />
            {settings.phone}
          </a>
          <Button asChild className="header-cta font-extrabold">
            <Link href="/catalog">
              <Search aria-hidden="true" size={16} />
              Смотреть авто
            </Link>
          </Button>
        </div>
      </div>
    </header>
  );
}
