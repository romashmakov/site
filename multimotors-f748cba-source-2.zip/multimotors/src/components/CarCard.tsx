import type { Car } from "@prisma/client";
import Link from "next/link";
import { formatCny, formatUsdFromRub, parseImages, statusLabel, typeLabel } from "@/lib/format";
import { stripChineseText } from "@/lib/text";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { SafeCarImage } from "@/components/SafeCarImage";

export function CarCard({ car, usdRate }: { car: Car; usdRate: number }) {
  const images = parseImages(car.imageUrls);
  const badgeClass = car.status === "REVIEW" ? "badge review" : car.status === "SOLD" ? "badge sold" : "badge";
  const brand = stripChineseText(car.brand, "Авто");
  const model = stripChineseText(car.model, "из Китая");
  const trim = stripChineseText(car.trim);

  return (
    <article className="car-card">
      <Link className="car-media" href={`/cars/${car.id}`}>
        <SafeCarImage src={images[0]} alt={`${brand} ${model}`} title={brand} variant="card" />
        <Badge className={badgeClass}>{car.status === "PUBLISHED" ? typeLabel[car.type] : statusLabel[car.status]}</Badge>
      </Link>
      <div className="car-main">
        <Link href={`/cars/${car.id}`}>
          <h3>
            {brand} {model}
          </h3>
        </Link>
        <div className="muted">
          {car.city || "Китай"} · {car.year}
        </div>
        {trim ? <p className="car-trim">{trim}</p> : null}
        <div className="spec-grid">
          <div className="spec">
            <small>Пробег</small>
            <strong>{car.mileageKm ? `${car.mileageKm.toLocaleString("ru-RU")} км` : "Новый"}</strong>
          </div>
          <div className="spec">
            <small>Двигатель</small>
            <strong>{car.engineType}</strong>
          </div>
          <div className="spec">
            <small>Привод</small>
            <strong>{car.drive || "не указан"}</strong>
          </div>
          <div className="spec">
            <small>Мощность</small>
            <strong>{car.power || "по запросу"}</strong>
          </div>
        </div>
      </div>
      <div className="car-price">
        <div>
          <div className="price">{formatUsdFromRub(car.priceRub, usdRate)}</div>
          <div className="muted">цена под ключ</div>
          <div className="card-costs">
            {car.priceCny ? <span>{formatCny(car.priceCny)}</span> : null}
            {car.deliveryRub ? <span>Доставка {formatUsdFromRub(car.deliveryRub, usdRate)}</span> : null}
          </div>
        </div>
        <Button asChild className="font-extrabold">
          <Link href={`/cars/${car.id}`}>Подробнее</Link>
        </Button>
      </div>
    </article>
  );
}
