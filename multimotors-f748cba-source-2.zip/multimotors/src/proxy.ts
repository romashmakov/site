import { NextResponse, type NextRequest } from "next/server";

const ADMIN_COOKIE = "mm_admin";

function needsAdmin(request: NextRequest) {
  const { pathname } = request.nextUrl;
  if (pathname.startsWith("/admin") && pathname !== "/admin/login") return true;
  if (pathname.startsWith("/api/import-drafts")) return true;
  if (pathname.startsWith("/api/uploads")) return true;
  if (pathname.startsWith("/api/settings") && request.method !== "GET") return true;
  if (pathname.startsWith("/api/cars") && request.method !== "GET") return true;
  if (pathname.startsWith("/api/leads") && request.method !== "POST") return true;
  return false;
}

export function proxy(request: NextRequest) {
  if (!needsAdmin(request)) return NextResponse.next();
  if (request.cookies.get(ADMIN_COOKIE)?.value === "1") return NextResponse.next();

  if (request.nextUrl.pathname.startsWith("/api/")) {
    return NextResponse.json({ error: "Нужен вход в админку" }, { status: 401 });
  }

  const loginUrl = request.nextUrl.clone();
  loginUrl.pathname = "/admin/login";
  loginUrl.searchParams.set("next", request.nextUrl.pathname + request.nextUrl.search);
  return NextResponse.redirect(loginUrl);
}

export const config = {
  matcher: [
    "/admin/:path*",
    "/api/cars/:path*",
    "/api/import-drafts/:path*",
    "/api/leads/:path*",
    "/api/settings",
    "/api/settings/:path*",
    "/api/uploads/:path*"
  ]
};
