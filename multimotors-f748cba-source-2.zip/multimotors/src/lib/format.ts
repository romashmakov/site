export const listingTypes = ["CHINA_IMPORT", "IN_STOCK", "NEW_CAR", "CUSTOM_ORDER"] as const;
export const listingStatuses = ["DRAFT", "REVIEW", "PUBLISHED", "SOLD", "ARCHIVED"] as const;
export const sourceKinds = ["MANUAL", "CHE168", "DONGCHEDI", "OTHER"] as const;

export type ListingTypeValue = (typeof listingTypes)[number];
export type ListingStatusValue = (typeof listingStatuses)[number];
export type SourceKindValue = (typeof sourceKinds)[number];

export function formatRub(value: number | null | undefined) {
  return new Intl.NumberFormat("ru-RU").format(value ?? 0) + " ₽";
}

export function formatUsdFromRub(value: number, usdRate: number) {
  return new Intl.NumberFormat("ru-RU").format(Math.round(value / usdRate)) + " $";
}

export function formatCny(value: number | null | undefined) {
  if (!value) return "не указана";
  return "¥ " + new Intl.NumberFormat("ru-RU").format(value);
}

export function parseImages(value: string | null | undefined): string[] {
  if (!value) return [];
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.filter((item) => typeof item === "string") : [];
  } catch {
    return [];
  }
}

export const typeLabel: Record<string, string> = {
  CHINA_IMPORT: "Из Китая",
  IN_STOCK: "В наличии",
  NEW_CAR: "Новые авто",
  CUSTOM_ORDER: "Под заказ"
};

export const statusLabel: Record<string, string> = {
  DRAFT: "Черновик",
  REVIEW: "Проверка",
  PUBLISHED: "Опубликовано",
  SOLD: "Продано",
  ARCHIVED: "Архив"
};

export const sourceLabel: Record<string, string> = {
  MANUAL: "Добавлено вручную",
  CHE168: "CHE168 Global",
  DONGCHEDI: "Китайская площадка",
  OTHER: "Другой источник"
};

export function typeSlug(type: ListingTypeValue) {
  return {
    CHINA_IMPORT: "china",
    IN_STOCK: "stock",
    NEW_CAR: "new",
    CUSTOM_ORDER: "order"
  }[type];
}

export function typeFromSlug(slug: string | null) {
  return {
    china: "CHINA_IMPORT",
    stock: "IN_STOCK",
    new: "NEW_CAR",
    order: "CUSTOM_ORDER"
  }[slug ?? ""] as ListingTypeValue | undefined;
}
