import { prisma } from "@/lib/prisma";
import { cache } from "react";
import { company, initialUsdRate } from "@/lib/company";

export const SETTINGS_ID = "default";

export type SettingsData = {
  id: string;
  companyName: string;
  phone: string;
  whatsapp: string | null;
  telegram: string | null;
  instagram: string | null;
  usdRate: number;
  cnyRate: number;
  defaultDeliveryRub: number;
  customsRate: number;
  minCustomsRub: number;
  defaultCommissionRub: number;
};

export const defaultSettings: SettingsData = {
  id: SETTINGS_ID,
  companyName: company.name,
  phone: company.phone,
  whatsapp: company.phoneDigits,
  telegram: `+${company.phoneDigits}`,
  instagram: company.instagram,
  usdRate: initialUsdRate,
  cnyRate: 11.8,
  defaultDeliveryRub: 280_000,
  customsRate: 0.16,
  minCustomsRub: 420_000,
  defaultCommissionRub: 200_000
};

export const getSettings = cache(async () => {
  const settings = await prisma.appSettings.upsert({
    where: { id: SETTINGS_ID },
    update: {},
    create: defaultSettings
  });
  // Keep the requested branding when installing over the original demo database.
  // Actual custom settings remain editable and are not overwritten on page reads.
  return {
    ...settings,
    companyName: settings.companyName === "Мультимоторс" ? company.name : settings.companyName,
    phone: settings.phone === "+7 (000) 000-00-00" ? company.phone : settings.phone
  };
});

export function calculateCarCosts(
  priceCny: number | null | undefined,
  settings: SettingsData,
  overrides: Partial<Pick<SettingsData, "defaultDeliveryRub" | "defaultCommissionRub">> & {
    deliveryRub?: number;
    customsRub?: number;
    commissionRub?: number;
  } = {}
) {
  const baseRub = priceCny ? Math.round(priceCny * settings.cnyRate) : 0;
  const deliveryRub = overrides.deliveryRub ?? overrides.defaultDeliveryRub ?? settings.defaultDeliveryRub;
  const customsRub =
    overrides.customsRub ?? (baseRub ? Math.max(Math.round(baseRub * settings.customsRate), settings.minCustomsRub) : settings.minCustomsRub);
  const commissionRub = overrides.commissionRub ?? overrides.defaultCommissionRub ?? settings.defaultCommissionRub;
  const priceRub = baseRub + deliveryRub + customsRub + commissionRub;

  return {
    baseRub,
    deliveryRub,
    customsRub,
    commissionRub,
    priceRub
  };
}

export function phoneHref(phone: string) {
  const cleaned = phone.replace(/[^\d+]/g, "");
  return cleaned ? `tel:${cleaned}` : "#";
}

export function messengerHref(value: string | null | undefined, kind: "whatsapp" | "telegram") {
  if (!value) return "";
  if (/^https?:\/\//i.test(value)) return value;
  const clean = value.trim().replace(/^@/, "");
  if (kind === "telegram") return `https://t.me/${clean}`;
  return `https://wa.me/${clean.replace(/[^\d]/g, "")}`;
}
