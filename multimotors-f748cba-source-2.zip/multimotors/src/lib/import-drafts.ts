import type { Car, ImportDraft } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { cacheExternalImages } from "@/lib/image-cache";
import { calculateCarCosts, getSettings, type SettingsData } from "@/lib/settings";
import { stripChineseText } from "@/lib/text";
import {
  isChe168GlobalDetailUrl,
  isChe168GlobalUrl,
  scrapeChe168GlobalDetail,
  scrapeChe168GlobalList,
  type Che168GlobalCar
} from "@/lib/che168-global";

const cityRu: Record<string, string> = {
  苏州: "Сучжоу",
  上海: "Шанхай",
  北京: "Пекин",
  广州: "Гуанчжоу",
  深圳: "Шэньчжэнь",
  杭州: "Ханчжоу"
};

const brandRu: Record<string, string> = {
  宝马: "BMW",
  奔驰: "Mercedes-Benz",
  奥迪: "Audi",
  捷豹: "Jaguar",
  讴歌: "Acura",
  凯迪拉克: "Cadillac",
  雷克萨斯: "Lexus",
  大众: "Volkswagen",
  丰田: "Toyota",
  本田: "Honda",
  日产: "Nissan",
  理想: "Li Auto",
  比亚迪: "BYD",
  极氪: "Zeekr",
  坦克: "Tank",
  蔚来: "NIO",
  小鹏: "XPeng",
  吉利: "Geely",
  吉利汽车: "Geely",
  吉利银河: "Geely Galaxy",
  林肯: "Lincoln",
  英菲尼迪: "Infiniti",
  马自达: "Mazda"
};

const seriesRu: Record<string, string> = {
  星瑞: "Xingrui",
  星越: "Xingyue",
  星越L: "Xingyue L",
  博越: "Boyue",
  博越L: "Boyue L",
  帝豪: "Emgrand",
  帝豪GL: "Emgrand GL",
  帝豪S: "Emgrand S",
  豪越L: "Haoyue L",
  缤瑞: "Binrui",
  远景X6: "Vision X6",
  远景S1: "Vision S1",
  吉利ICON: "Geely ICON"
};

const brandAliases: Record<string, string[]> = {
  吉利: ["Geely", "Джили", "吉利汽车"],
  吉利汽车: ["Geely", "Джили", "吉利"],
  吉利银河: ["Geely Galaxy", "Geely", "Джили"]
};

const seriesAliases: Record<string, string[]> = {
  星越L: ["Xingyue L", "Xing Yue L", "Geely Xingyue L", "Geely Xing Yue L", "Джили Xingyue L", "Джили Синъюэ L"],
  星越: ["Xingyue", "Xing Yue", "Geely Xingyue", "Geely Xing Yue", "Джили Xingyue", "Джили Синъюэ"],
  星瑞: ["Xingrui", "Xing Rui", "Geely Xingrui", "Geely Xing Rui"],
  博越L: ["Boyue L", "Bo Yue L", "Geely Boyue L"],
  博越: ["Boyue", "Bo Yue", "Geely Boyue"],
  帝豪: ["Emgrand", "Geely Emgrand"],
  豪越L: ["Haoyue L", "Hao Yue L", "Geely Haoyue L"]
};

const MAX_IMPORT_LIST_LIMIT = 300;
const DCDAPP_PAGE_SIZE = 15;
const DCDAPP_MAX_SCAN_ITEMS = 900;

export type ImportListFilters = {
  brand?: string;
  model?: string;
  engineType?: string;
  city?: string;
  yearFrom?: number;
  yearTo?: number;
  mileageMax?: number;
  priceCnyFrom?: number;
  priceCnyTo?: number;
  gearbox?: string;
  drive?: string;
  brandId?: number;
  seriesId?: number;
};

type DcdappSelection = {
  brandId?: number;
  brandName?: string;
  seriesId?: number;
  seriesName?: string;
  searchQuery?: string;
  catalogStatus?: number;
};

export function sourceFromUrl(sourceUrl: string) {
  const hostname = new URL(sourceUrl).hostname;
  if (/che168\.com$/i.test(hostname)) return "CHE168";
  if (/dcdapp\.com$/i.test(hostname) || /dcarapi\.com$/i.test(hostname) || /dongchedi\.com$/i.test(hostname)) return "DONGCHEDI";
  return "OTHER";
}

export function externalIdFromUrl(sourceUrl: string) {
  const url = new URL(sourceUrl);
  const htmlId = url.pathname.match(/\/(\d+)\.html/i)?.[1];
  if (htmlId) return htmlId;
  const pathId = url.pathname.split("/").filter(Boolean).at(-1);
  return pathId || url.hostname;
}

function stripTags(value: string) {
  return value.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
}

function extractMeta(html: string, name: string) {
  const patterns = [
    new RegExp(`<meta[^>]+property=["']${name}["'][^>]+content=["']([^"']+)["'][^>]*>`, "i"),
    new RegExp(`<meta[^>]+name=["']${name}["'][^>]+content=["']([^"']+)["'][^>]*>`, "i")
  ];
  for (const pattern of patterns) {
    const value = html.match(pattern)?.[1];
    if (value) return stripTags(value);
  }
  return "";
}

function extractTitle(html: string, fallback: string) {
  return extractMeta(html, "og:title") || stripTags(html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1] || "") || fallback;
}

function extractImages(html: string) {
  const image = extractMeta(html, "og:image");
  return image ? [image] : [];
}

function extractPriceCny(html: string, title: string) {
  const titlePriceMatch = title.match(/_(\d+(?:\.\d+)?)_/);
  if (titlePriceMatch) return Math.round(Number(titlePriceMatch[1]) * 10_000);

  const text = `${title} ${stripTags(html)}`;
  const wanMatch = text.match(/(\d+(?:\.\d+)?)\s*万/);
  return wanMatch ? Math.round(Number(wanMatch[1]) * 10_000) : null;
}

function cleanChe168Title(title: string) {
  return title
    .replace(/_二手车之家$/i, "")
    .replace(/_che168.*$/i, "")
    .trim();
}

function parseChe168Title(title: string) {
  const cleanTitle = cleanChe168Title(title);
  const city = cleanTitle.match(/^【([^】]+)】/)?.[1] || "";
  const withoutCity = cleanTitle.replace(/^【[^】]+】/, "").trim();
  const titlePrice = withoutCity.match(/_(\d+(?:\.\d+)?)_?/)?.[1];
  const carText = withoutCity.replace(/_(\d+(?:\.\d+)?)_?.*$/, "").trim();
  const year = Number(carText.match(/(20\d{2})款/)?.[1] || new Date().getFullYear());

  let brand = "";
  let modelAndTrim = carText;
  for (const brandCn of Object.keys(brandRu)) {
    if (carText.startsWith(brandCn)) {
      brand = brandRu[brandCn];
      modelAndTrim = carText.slice(brandCn.length).trim();
      break;
    }
  }

  const beforeYear = modelAndTrim.split(/\s+20\d{2}款\s*/)[0]?.trim() || modelAndTrim.split(/\s+/)[0] || "объявление";
  const afterYear = modelAndTrim.match(/20\d{2}款\s*(.+)$/)?.[1]?.trim() || "";
  const trim = afterYear || modelAndTrim.replace(beforeYear, "").trim();

  return {
    cleanTitle,
    city: city ? cityRu[city] || city : "Китай",
    brand: brand || carText.split(/\s+/)[0] || "China",
    model: beforeYear,
    trim,
    year,
    priceCny: titlePrice ? Math.round(Number(titlePrice) * 10_000) : null
  };
}

function translatedChe168Title(parsed: ReturnType<typeof parseChe168Title>) {
  const trim = parsed.trim ? ` ${parsed.trim}` : "";
  return `${parsed.brand} ${parsed.model} ${parsed.year}${trim}`.replace(/\s+/g, " ").trim();
}

function charsetFromHtml(bytes: Uint8Array) {
  const head = new TextDecoder("latin1").decode(bytes.slice(0, 4096));
  return head.match(/charset=["']?([a-z0-9-]+)/i)?.[1]?.toLowerCase() || "";
}

function normalizeCharset(charset: string) {
  if (["gb2312", "gbk", "gb18030"].includes(charset)) return "gb18030";
  return charset || "utf-8";
}

function decodeHtml(bytes: Uint8Array, contentType: string) {
  const headerCharset = contentType.match(/charset=([^;]+)/i)?.[1]?.trim().toLowerCase() || "";
  const charset = normalizeCharset(headerCharset || charsetFromHtml(bytes));
  try {
    return new TextDecoder(charset).decode(bytes);
  } catch {
    return new TextDecoder("utf-8").decode(bytes);
  }
}

export async function fetchSourceHtml(sourceUrl: string) {
  const response = await fetch(sourceUrl, {
    redirect: "follow",
    headers: {
      "accept-language": "zh-CN,zh;q=0.9,ru;q=0.8,en;q=0.7",
      "user-agent":
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"
    },
    signal: AbortSignal.timeout(18_000)
  });

  const bytes = new Uint8Array(await response.arrayBuffer());

  return {
    status: response.status,
    finalUrl: response.url,
    html: decodeHtml(bytes, response.headers.get("content-type") || "")
  };
}

function buildNormalized(input: {
  title: string;
  source: string;
  priceCny: number | null;
  blocked: boolean;
  settings: SettingsData;
}) {
  const che168 = input.source === "CHE168" ? parseChe168Title(input.title) : null;
  const titleParts = input.title.split(/\s+/).filter(Boolean);
  const brand = stripChineseText(che168?.brand || titleParts[0], input.source === "CHE168" ? "Che168" : "China");
  const model = stripChineseText(che168?.model || titleParts.slice(1).join(" "), "объявление");
  const costs = calculateCarCosts(input.priceCny, input.settings);
  const translatedTitle = stripChineseText(che168 ? translatedChe168Title(che168) : input.title, `${brand} ${model}`);

  return {
    brand,
    model,
    trim: stripChineseText(che168?.trim || input.title, translatedTitle),
    year: che168?.year || new Date().getFullYear(),
    mileageKm: 0,
    city: che168?.city || "Китай",
    engineType: "не указан",
    deliveryRub: costs.deliveryRub,
    customsRub: costs.customsRub,
    commissionRub: costs.commissionRub,
    priceRub: costs.priceRub || undefined,
    descriptionRu: `${translatedTitle}. Черновик создан по прямой ссылке на оригинальное объявление. ${
      input.blocked
        ? "Источник вернул anti-bot challenge, поэтому характеристики нужно перенести вручную после проверки оригинала."
        : "Данные извлечены автоматически частично и требуют проверки менеджером."
    }`
  };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function asString(value: unknown) {
  return typeof value === "string" ? value : "";
}

function asNumber(value: unknown) {
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  if (typeof value === "string" && value.trim()) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}

function decodeDcdappWebviewUrl(openUrl: string) {
  if (!openUrl) return "";
  try {
    const parsed = new URL(openUrl);
    const nestedUrl = parsed.searchParams.get("url");
    return nestedUrl ? decodeURIComponent(nestedUrl) : openUrl;
  } catch {
    return openUrl;
  }
}

function cityFromDcdappUrl(sourceUrl: string) {
  try {
    const url = new URL(sourceUrl);
    return url.searchParams.get("city_name") || url.searchParams.get("selected_city_name") || "北京";
  } catch {
    return "北京";
  }
}

function numberParamFromUrl(sourceUrl: string, name: string) {
  try {
    const value = new URL(sourceUrl).searchParams.get(name);
    return value ? Number(value) || undefined : undefined;
  } catch {
    return undefined;
  }
}

function numberParamFromDcdappUrl(sourceUrl: string, name: string) {
  const urls = [sourceUrl, decodeDcdappWebviewUrl(sourceUrl)].filter(Boolean);
  for (const url of [...new Set(urls)]) {
    const value = numberParamFromUrl(url, name);
    if (value) return value;
  }
  return undefined;
}

function skuIdFromDcdappUrl(sourceUrl: string) {
  const directParamNames = ["sku_id", "skuId", "product_id", "productId", "car_id", "carId"];
  for (const name of directParamNames) {
    const value = numberParamFromDcdappUrl(sourceUrl, name);
    if (value) return value;
  }
  return undefined;
}

function textParamFromUrl(sourceUrl: string, name: string) {
  try {
    return new URL(sourceUrl).searchParams.get(name) || "";
  } catch {
    return "";
  }
}

function buildDcdappFeedUrl(sourceUrl: string) {
  const cityName = cityFromDcdappUrl(sourceUrl);
  const params = new URLSearchParams({
    motor_feed_extra_params: JSON.stringify({
      feed_type: 1,
      new_feed: true,
      link_source: "",
      used_car_entry: "wap_page_main-bottom_channel_tag",
      show_column: "buy_car",
      request_source_type: 1
    }),
    loc_time: String(Math.floor(Date.now() / 1000)),
    max_behot_time: "0",
    selected_city_name: cityName,
    city_name: cityName,
    gps_city_name: cityName,
    category: "sku_second_hand_motor_car",
    impression_info: JSON.stringify({ page_id: "page_sh_car_home", sub_tab: "sh_car" })
  });

  return `https://m.dcdapp.com/motor/stream_entrance/get_feed/v47/?${params.toString()}`;
}

async function fetchDcdappFeed(sourceUrl: string) {
  const feedUrl = buildDcdappFeedUrl(sourceUrl);
  const response = await fetch(feedUrl, {
    redirect: "follow",
    headers: {
      "accept-language": "zh-CN,zh;q=0.9,ru;q=0.8,en;q=0.7",
      referer: sourceUrl,
      "user-agent":
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"
    },
    signal: AbortSignal.timeout(18_000)
  });
  const json: unknown = await response.json();

  return {
    status: response.status,
    feedUrl,
    json
  };
}

function dcdappHeaders(sourceUrl: string) {
  const safeReferer = sourceUrl.includes("dcdapp.com")
    ? sourceUrl
    : "https://m.dcdapp.com/motor/feoffline/usedcar_channel/car-source.html";

  return {
    "accept-language": "zh-CN,zh;q=0.9,ru;q=0.8,en;q=0.7",
    referer: safeReferer,
    "user-agent":
      "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"
  };
}

async function fetchDcdappJson(url: string, referer: string) {
  const response = await fetch(url, {
    redirect: "follow",
    headers: dcdappHeaders(referer),
    signal: AbortSignal.timeout(18_000)
  });

  return {
    status: response.status,
    json: await response.json()
  };
}

async function fetchDcdappBrandCatalog(sourceUrl: string) {
  const cityName = cityFromDcdappUrl(sourceUrl);
  const params = new URLSearchParams({
    __method: "window.fetch",
    sh_city_name: cityName,
    need_nationwide_count: "1"
  });
  const result = await fetchDcdappJson(`https://m.dcdapp.com/motor/sh_go/api/buy_car/brand_filter_list?${params.toString()}`, sourceUrl);
  const data = isRecord(result.json) && isRecord(result.json.data) ? result.json.data : {};
  const brandItems = Array.isArray(data.brand_list) ? data.brand_list : [];
  const seriesItems = Array.isArray(data.top_series_list) ? data.top_series_list : [];

  return {
    status: result.status,
    brandItems,
    seriesItems
  };
}

function itemInfo(item: unknown) {
  if (!isRecord(item)) return {};
  return isRecord(item.info) ? item.info : item;
}

function brandMatches(info: Record<string, unknown>, query: string) {
  const brandName = asString(info.brand_name);
  const translated = brandRu[brandName] || "";
  const aliases = brandAliases[brandName] || [];
  const haystack = `${brandName} ${translated} ${asString(info.pinyin)} ${aliases.join(" ")}`;
  const normalizedQuery = normalizeSearchText(query);
  const normalizedHaystack = normalizeSearchText(haystack);

  return normalizedHaystack.includes(normalizedQuery) || aliases.some((alias) => normalizedQuery.includes(normalizeSearchText(alias)));
}

function seriesMatchScore(info: Record<string, unknown>, query: string) {
  const seriesName = asString(info.series_name) || asString(info.label);
  const aliases = [seriesName, seriesRu[seriesName] || "", ...(seriesAliases[seriesName] || [])].filter(Boolean);
  const normalizedQuery = normalizeSearchText(query);
  let score = 0;

  for (const alias of aliases) {
    const normalizedAlias = normalizeSearchText(alias);
    if (!normalizedAlias) continue;
    if (normalizedAlias === normalizedQuery) score = Math.max(score, 1000 + normalizedAlias.length);
    if (normalizedQuery.endsWith(normalizedAlias)) score = Math.max(score, 800 + normalizedAlias.length);
    if (normalizedQuery.includes(normalizedAlias)) score = Math.max(score, 600 + normalizedAlias.length);
    if (normalizedAlias.includes(normalizedQuery)) score = Math.max(score, 400 + normalizedQuery.length);
  }

  return score;
}

function bestSeriesMatch(items: unknown[], query: string, brandId?: number) {
  return items
    .filter((item) => !brandId || asNumber(itemInfo(item).brand_id) === brandId)
    .map(itemInfo)
    .map((info) => ({ info, score: seriesMatchScore(info, query) }))
    .filter((item) => asNumber(item.info.series_id) && item.score > 0)
    .sort((a, b) => b.score - a.score)[0]?.info;
}

function seriesMatches(info: Record<string, unknown>, query: string) {
  return seriesMatchScore(info, query) > 0;
}

function canonicalSeriesNameFromQuery(query: string) {
  return Object.keys(seriesAliases)
    .map((seriesName) => ({ seriesName, score: seriesMatchScore({ series_name: seriesName }, query) }))
    .filter((item) => item.score > 0)
    .sort((a, b) => b.score - a.score)[0]?.seriesName;
}

function modelQueryFromInput(brandQuery: string, modelQuery: string) {
  if (modelQuery) return modelQuery;
  return canonicalSeriesNameFromQuery(brandQuery) ? brandQuery : "";
}

function carItemsFromSearchPayload(json: unknown) {
  const pageItems = isRecord(json) && Array.isArray(json.data) ? json.data : [];
  return pageItems.filter((item) => isRecord(item) && asNumber(item.type) === 10001);
}

function dcdappCardInfoFromItem(item: unknown) {
  if (!isRecord(item)) return {};
  const info = isRecord(item.info) ? item.info : {};
  const nestedInfo = isRecord(info.info) ? info.info : {};
  return isRecord(nestedInfo.card_info) ? nestedInfo.card_info : isRecord(info.card_info) ? info.card_info : {};
}

function dcdappBaseInfoFromItem(item: unknown) {
  if (!isRecord(item)) return {};
  const info = isRecord(item.info) ? item.info : {};
  const nestedInfo = isRecord(info.info) ? info.info : {};
  return isRecord(nestedInfo.base_info) ? nestedInfo.base_info : {};
}

function dcdappSkuIdFromItem(item: unknown) {
  const baseInfo = dcdappBaseInfoFromItem(item);
  const cardInfo = dcdappCardInfoFromItem(item);
  const sourceUrl = decodeDcdappWebviewUrl(asString(cardInfo.open_url)) || "";
  return asNumber(baseInfo.sku_id) || asNumber(cardInfo.product_id) || numberParamFromUrl(sourceUrl, "sku_id");
}

function seriesItemsFromSearchPayload(json: unknown) {
  const pageItems = isRecord(json) && Array.isArray(json.data) ? json.data : [];
  return pageItems
    .filter((item) => isRecord(item) && asNumber(item.type) === 10010 && Array.isArray(item.info))
    .flatMap((item) => (isRecord(item) && Array.isArray(item.info) ? item.info : []));
}

async function resolveDcdappSeriesFromSearch(sourceUrl: string, selection: { brandId?: number; brandName?: string }, modelQuery: string) {
  if (!selection.brandId || !modelQuery) return {};
  const url = buildDcdappSearchUrl(sourceUrl, { ...selection, catalogStatus: 0 }, 0, 15);
  const result = await fetchDcdappJson(url, sourceUrl);
  const series = bestSeriesMatch(seriesItemsFromSearchPayload(result.json), modelQuery);

  return {
    seriesId: asNumber(series?.series_id) || undefined,
    seriesName: asString(series?.series_name),
    status: result.status
  };
}

async function resolveDcdappSelection(sourceUrl: string, filters: ImportListFilters) {
  const brandIdFromUrl = numberParamFromUrl(sourceUrl, "brand_id");
  const seriesIdFromUrl = numberParamFromUrl(sourceUrl, "series_id");
  const brandNameFromUrl = textParamFromUrl(sourceUrl, "brand_name");
  const seriesNameFromUrl = textParamFromUrl(sourceUrl, "series_name");
  const queryFromUrl = textParamFromUrl(sourceUrl, "query");
  const brandQuery = (filters.brand || "").trim();
  const modelQuery = modelQueryFromInput(brandQuery, (filters.model || "").trim());
  const canonicalModelSeriesName = canonicalSeriesNameFromQuery(modelQuery);

  let brandId = filters.brandId || brandIdFromUrl;
  let seriesId = filters.seriesId || seriesIdFromUrl;
  let brandName = brandNameFromUrl;
  let seriesName = seriesNameFromUrl;
  let searchQuery = queryFromUrl;
  let catalogStatus = 0;

  if (!brandId || !seriesId || !brandName || !seriesName) {
    const catalog = await fetchDcdappBrandCatalog(sourceUrl);
    catalogStatus = catalog.status;

    if (!brandId && brandQuery) {
      const brand = catalog.brandItems
        .map(itemInfo)
        .find((info) => asNumber(info.brand_id) && brandMatches(info, brandQuery));
      brandId = asNumber(brand?.brand_id) || undefined;
      brandName = asString(brand?.brand_name) || brandName;
    }

    if (brandId && !brandName) {
      const brand = catalog.brandItems.map(itemInfo).find((info) => asNumber(info.brand_id) === brandId);
      brandName = asString(brand?.brand_name) || brandName;
    }

    if (!seriesId && modelQuery) {
      const series = bestSeriesMatch(catalog.seriesItems, modelQuery, brandId);
      const matchedSeriesName = asString(series?.series_name);
      if (!canonicalModelSeriesName || matchedSeriesName === canonicalModelSeriesName) {
        seriesId = asNumber(series?.series_id) || undefined;
        seriesName = matchedSeriesName || seriesName;
      } else {
        searchQuery = canonicalModelSeriesName;
      }
    }

    if (seriesId && !seriesName) {
      const series = catalog.seriesItems.map(itemInfo).find((info) => asNumber(info.series_id) === seriesId);
      seriesName = asString(series?.series_name) || seriesName;
    }

    if (!seriesId && brandId && modelQuery) {
      const series = await resolveDcdappSeriesFromSearch(sourceUrl, { brandId, brandName }, modelQuery);
      if (!canonicalModelSeriesName || series.seriesName === canonicalModelSeriesName) {
        seriesId = series.seriesId || seriesId;
        seriesName = series.seriesName || seriesName;
      } else {
        searchQuery = canonicalModelSeriesName;
      }
      catalogStatus = series.status || catalogStatus;
    }
  }

  return {
    brandId,
    brandName,
    seriesId,
    seriesName,
    searchQuery,
    catalogStatus
  };
}

function buildDcdappSearchUrl(sourceUrl: string, selection: DcdappSelection, offset: number, limit: number) {
  const cityName = cityFromDcdappUrl(sourceUrl);
  const params = new URLSearchParams({
    __method: "window.fetch",
    from: "search_list",
    cur_tab: "1001",
    city_name: cityName,
    page_type: "search_result",
    pack_version: "1",
    offset: String(offset),
    limit: String(limit),
    use_backup: "0",
    dynamic_filter_extension: "1",
    sh_city_name: cityName,
    sort: "0",
    preference: "0"
  });

  if (selection.brandId) params.set("brand_id", String(selection.brandId));
  if (selection.brandName) params.set("brand_name", selection.brandName);
  if (selection.seriesId) params.set("series_id", String(selection.seriesId));
  if (selection.seriesName) params.set("series_name", selection.seriesName);
  if (selection.searchQuery) params.set("query", selection.searchQuery);

  return `https://m.dcdapp.com/motor/searchapi/searchv2/?${params.toString()}`;
}

function buildDcdappDetailUrl(sourceUrl: string, skuId: number | string) {
  const cityName = cityFromDcdappUrl(sourceUrl);
  const params = new URLSearchParams({
    sku_id: String(skuId),
    city_name: cityName,
    sh_city_name: cityName,
    device_id: "7666070120140031512"
  });

  return `https://m.dcdapp.com/motor/sh_information/api/h5/sku_detail/full?${params.toString()}`;
}

async function fetchDcdappDetail(sourceUrl: string, skuId: number | string) {
  const result = await fetchDcdappJson(buildDcdappDetailUrl(sourceUrl, skuId), sourceUrl);
  const data = isRecord(result.json) && isRecord(result.json.data) ? result.json.data : {};
  return {
    status: result.status,
    data
  };
}

function dcdappParamMap(detailData: Record<string, unknown>) {
  const params = new Map<string, string>();
  const components = Array.isArray(detailData.components) ? detailData.components : [];

  for (const component of components) {
    if (!isRecord(component) || !isRecord(component.vo) || !isRecord(component.vo.display)) continue;
    const display = component.vo.display;
    const groups = [display.important_param, display.other_param, display.highlight];

    for (const group of groups) {
      if (!isRecord(group) || !Array.isArray(group.param_infos)) continue;
      for (const param of group.param_infos) {
        if (!isRecord(param)) continue;
        const name = asString(param.name);
        const value = asString(param.value);
        if (name && value) params.set(name, value);
      }
    }
  }

  return params;
}

function dcdappDetailImages(detailData: Record<string, unknown>) {
  const components = Array.isArray(detailData.components) ? detailData.components : [];
  const urls: string[] = [];

  for (const component of components) {
    if (!isRecord(component) || !isRecord(component.vo) || !isRecord(component.vo.display)) continue;
    const headImages = Array.isArray(component.vo.display.head_images) ? component.vo.display.head_images : [];
    for (const image of headImages) {
      if (!isRecord(image)) continue;
      const url =
        asString(image.high_resolution_url) ||
        asString(image.pic_url) ||
        (isRecord(image.pic) && isRecord(image.pic.high) ? asString(image.pic.high.image) : "");
      if (url && !urls.includes(url)) urls.push(url);
    }
  }

  return urls;
}

function translateDcdappFuel(fuelForm: number | null, fallback = "не указан") {
  if (fuelForm === 1) return "Бензин";
  if (fuelForm === 2) return "Дизель";
  if (fuelForm === 3) return "Гибрид";
  if (fuelForm === 4) return "Электро";
  return fallback;
}

function translateDcdappGearbox(value: string) {
  if (!value) return undefined;
  if (/自动|手自一体/.test(value)) return "Автомат";
  if (/手动/.test(value)) return "Механика";
  if (/双离合|DCT/i.test(value)) return "Робот";
  if (/无级|CVT/i.test(value)) return "Вариатор";
  return stripChineseText(value, value);
}

function translateDcdappDrive(value: string) {
  if (!value) return undefined;
  if (/前驱/.test(value)) return "Передний";
  if (/后驱/.test(value)) return "Задний";
  if (/四驱|全驱|4WD|AWD/i.test(value)) return "Полный";
  return stripChineseText(value, value);
}

function mileageKmFromDcdappValue(value: string) {
  const wanKm = Number(value.match(/(\d+(?:\.\d+)?)\s*万公里/)?.[1] || "");
  if (Number.isFinite(wanKm) && wanKm > 0) return Math.round(wanKm * 10_000);
  const km = Number(value.match(/(\d+(?:\.\d+)?)\s*公里/)?.[1] || "");
  return Number.isFinite(km) && km > 0 ? Math.round(km) : null;
}

function dcdappParam(params: Map<string, string>, names: string[]) {
  for (const name of names) {
    const value = params.get(name);
    if (value) return value;
  }
  return "";
}

function priceCnyFromWanValue(value: unknown, unit = "") {
  const text = typeof value === "string" ? value.trim() : "";
  const numberValue = asNumber(value);
  const textNumber = Number(text.match(/(\d+(?:\.\d+)?)/)?.[1] || "");
  const amount = numberValue ?? (Number.isFinite(textNumber) ? textNumber : null);

  if (!amount || amount <= 0) return null;
  if (/万/.test(text) || /万/.test(unit) || amount < 1000) return Math.round(amount * 10_000);
  return Math.round(amount);
}

function dcdappDetailPriceCny(detailData: Record<string, unknown>) {
  const components = Array.isArray(detailData.components) ? detailData.components : [];

  for (const component of components) {
    if (!isRecord(component) || !isRecord(component.vo) || !isRecord(component.vo.display)) continue;
    const display = component.vo.display;
    const priceInfo = isRecord(display.price_info) ? display.price_info : {};
    const unit = asString(priceInfo.unit);
    const price = priceCnyFromWanValue(priceInfo.price, unit);
    if (price) return price;

    const fixedPrice = isRecord(display.fixed_price_detail_info) ? display.fixed_price_detail_info : {};
    const carPrice = priceCnyFromWanValue(fixedPrice.car_price || fixedPrice.fix_price, "万");
    if (carPrice) return carPrice;
  }

  const commonInfo = isRecord(detailData.common_info) ? detailData.common_info : {};
  return priceCnyFromWanValue(commonInfo.price, "万");
}

function publicCity(value: string | null | undefined) {
  const cleaned = stripChineseText(value, "");
  return cleaned && cleaned !== "Китай" ? cleaned : "Китай";
}

function buildCarDescription(input: { title: string; year: number; mileageKm?: number; city?: string; engineType?: string }) {
  const mileage = input.mileageKm ? `Пробег ${input.mileageKm.toLocaleString("ru-RU")} км.` : "";
  const city = publicCity(input.city);
  const cityText = city !== "Китай" ? `Автомобиль находится в городе ${city}.` : "Автомобиль доступен к заказу из Китая.";
  const engine = input.engineType && input.engineType !== "не указан" ? `Двигатель: ${input.engineType}.` : "";

  return [input.title, `${input.year} год.`, mileage, cityText, engine, "Цена рассчитана под ключ с учетом логистики, таможенных расходов и комиссии сервиса."]
    .filter(Boolean)
    .join(" ");
}

function mergeDcdappDetail(
  normalized: NonNullable<ReturnType<typeof normalizeDcdappItem>>,
  detailData: Record<string, unknown>,
  settings: SettingsData
) {
  const commonInfo = isRecord(detailData.common_info) ? detailData.common_info : {};
  const params = dcdappParamMap(detailData);
  const fuelForm = asNumber(commonInfo.fuel_form);
  const engine = dcdappParam(params, ["发动机", "动力类型"]);
  const gearbox = translateDcdappGearbox(dcdappParam(params, ["变速箱"]));
  const drive = translateDcdappDrive(dcdappParam(params, ["驱动方式", "动力类型"]));
  const mileageFromParams = mileageKmFromDcdappValue(dcdappParam(params, ["表显里程"]));
  const detailImages = dcdappDetailImages(detailData);
  const detailPriceCny = normalized.priceCny;
  const costs = calculateCarCosts(detailPriceCny, settings);
  const cityCn = asString(commonInfo.car_source_city_name);
  const carName = asString(commonInfo.car_name);
  const normalizedData = normalized.normalized;

  return {
    ...normalized,
    imageUrls: detailImages.length ? detailImages : normalized.imageUrls,
    rawPayload: {
      ...normalized.rawPayload,
      detail: {
        commonInfo,
        params: Object.fromEntries(params)
      }
    },
    normalized: {
      ...normalizedData,
      trim: stripChineseText(carName || normalizedData.trim, normalizedData.trim),
      year: asNumber(commonInfo.year) || normalizedData.year,
      mileageKm: mileageFromParams || normalizedData.mileageKm,
      city: publicCity(cityCn ? cityRu[cityCn] || cityCn : normalizedData.city),
      engineType: translateDcdappFuel(fuelForm, normalizedData.engineType),
      gearbox: gearbox || normalizedData.gearbox,
      drive: drive || normalizedData.drive,
      power: engine && /kw|квт|л\.?с|马力|功率/i.test(engine) ? stripChineseText(engine, engine) : normalizedData.power,
      deliveryRub: costs.deliveryRub,
      customsRub: costs.customsRub,
      commissionRub: costs.commissionRub,
      priceRub: costs.priceRub || normalizedData.priceRub,
      descriptionRu: buildCarDescription({
        title: `${normalizedData.brand} ${normalizedData.model}${carName ? ` ${stripChineseText(carName, "")}` : ""}`.trim(),
        year: asNumber(commonInfo.year) || normalizedData.year,
        mileageKm: mileageFromParams || normalizedData.mileageKm,
        city: publicCity(cityCn ? cityRu[cityCn] || cityCn : normalizedData.city),
        engineType: translateDcdappFuel(fuelForm, normalizedData.engineType)
      })
    }
  };
}

async function fetchDcdappSearchItems(sourceUrl: string, filters: ImportListFilters, safeLimit: number) {
  const selection = await resolveDcdappSelection(sourceUrl, filters);
  const pageSize = DCDAPP_PAGE_SIZE;
  const maxOffset = Math.min(DCDAPP_MAX_SCAN_ITEMS, Math.max(300, safeLimit * 5));
  const items: unknown[] = [];
  const seenSkuIds = new Set<string>();
  let offset = 0;
  let status = selection.catalogStatus || 0;
  let hasMore = true;
  let scanned = 0;

  while (items.length < safeLimit && hasMore && offset < maxOffset) {
    const url = buildDcdappSearchUrl(sourceUrl, selection, offset, pageSize);
    const result = await fetchDcdappJson(url, sourceUrl);
    status = result.status;
    const carItems = carItemsFromSearchPayload(result.json)
      .map((item) => (isRecord(item) ? { ...item, importSelection: selection } : item));
    scanned += carItems.length;
    for (const item of carItems) {
      const skuId = dcdappSkuIdFromItem(item);
      if (!skuId || seenSkuIds.has(String(skuId))) continue;
      seenSkuIds.add(String(skuId));
      items.push(item);
      if (items.length >= safeLimit) break;
    }
    hasMore = isRecord(result.json) ? Boolean(result.json.has_more) : false;
    offset = isRecord(result.json) ? asNumber(result.json.offset) || offset + pageSize : offset + pageSize;
  }

  return {
    status,
    items: items.slice(0, safeLimit),
    uniqueFound: items.length,
    scanned,
    selection
  };
}

function normalizeDcdappItem(item: unknown, settings: SettingsData) {
  if (!isRecord(item)) return null;
  const info = isRecord(item.info) ? item.info : {};
  const nestedInfo = isRecord(info.info) ? info.info : {};
  const baseInfo = dcdappBaseInfoFromItem(item);
  const cardInfo = dcdappCardInfoFromItem(item);
  const importSelection = isRecord(item.importSelection) ? item.importSelection : {};
  const sourceUrl = decodeDcdappWebviewUrl(asString(cardInfo.open_url)) || "";
  const skuId = dcdappSkuIdFromItem(item);

  if (!skuId) return null;

  const rawTitle =
    asString(cardInfo.title) ||
    [asString(baseInfo.brand_name), asString(baseInfo.series_name), asString(baseInfo.car_name)].filter(Boolean).join(" ") ||
    `Dongchedi ${skuId}`;
  const rawBrandCn = asString(baseInfo.brand_name) || asString(importSelection.brandName) || textParamFromUrl(sourceUrl, "brand_name");
  const brandCn = rawBrandCn || rawTitle.split(/\s+/)[0] || "";
  const brand = stripChineseText(brandRu[brandCn] || brandCn, "Dongchedi");
  const titleYear = rawTitle.match(/(20\d{2})款/)?.[1];
  const titleBeforeYear = rawTitle.split(/\s+20\d{2}款\s*/)[0]?.trim() || rawTitle.split(/\s+/)[0] || "";
  const titleAfterYear = rawTitle.match(/20\d{2}款\s*(.+)$/)?.[1]?.trim() || "";
  const seriesCn = asString(baseInfo.series_name) || asString(importSelection.seriesName) || titleBeforeYear;
  const model = stripChineseText(seriesRu[seriesCn] || seriesCn, stripChineseText(rawTitle, "объявление"));
  const trim = stripChineseText(asString(baseInfo.car_name) || titleAfterYear, stripChineseText(rawTitle, model));
  const cityCn = asString(baseInfo.car_source_city_name) || asString(baseInfo.brand_source_city_name);
  const subTitle = asString(cardInfo.sub_title);
  const cityFromSubTitle = subTitle.split("/").map((part) => part.trim()).at(2) || "";
  const city = publicCity(cityCn ? cityRu[cityCn] || cityCn : cityFromSubTitle ? cityRu[cityFromSubTitle] || cityFromSubTitle : "Китай");
  const year = asNumber(baseInfo.year) || Number(titleYear) || Number(subTitle.match(/(20\d{2})年/)?.[1]) || new Date().getFullYear();
  const mileageWanKm = asNumber(baseInfo.mileage) || Number(subTitle.match(/(\d+(?:\.\d+)?)万公里/)?.[1] || 0);
  const mileageKm = mileageWanKm ? Math.round(mileageWanKm * 10_000) : 0;
  const priceWanCny = asNumber(cardInfo.price) || asNumber(cardInfo.origin_price);
  const priceCny = priceWanCny ? Math.round(priceWanCny * 10_000) : null;
  const costs = calculateCarCosts(priceCny, settings);
  const image = asString(cardInfo.image) || (isRecord(cardInfo.image_info) ? asString(cardInfo.image_info.image_url) : "");
  const finalSourceUrl = sourceUrl || `https://m.dcdapp.com/motor/feoffline/usedcar_detail/detail.html?sku_id=${skuId}`;
  const translatedTitle = stripChineseText(`${brand} ${model.replace(brandCn, "").trim() || model} ${year} ${trim}`, `${brand} ${model}`);
  const dealer = asString(baseInfo.short_name) || asString(baseInfo.full_name);
  const fuelForm = asNumber(baseInfo.fuel_form);
  const engineType = fuelForm === 1 ? "Бензин" : fuelForm === 3 ? "Гибрид" : fuelForm === 4 ? "Электро" : "не указан";

  return {
    source: "DONGCHEDI",
    sourceUrl: finalSourceUrl,
    externalId: String(skuId),
    rawTitle,
    translatedTitle,
    priceCny,
    imageUrls: image ? [image] : [],
    rawPayload: {
      baseInfo,
      cardInfo,
      itemId: info.item_id ?? item.unique_id ?? null
    },
    normalized: {
      brand,
      model,
      trim,
      year,
      mileageKm,
      city,
      engineType,
      gearbox: undefined as string | undefined,
      drive: undefined as string | undefined,
      power: undefined as string | undefined,
      deliveryRub: costs.deliveryRub,
      customsRub: costs.customsRub,
      commissionRub: costs.commissionRub,
      priceRub: costs.priceRub || undefined,
      descriptionRu: buildCarDescription({
        title: translatedTitle,
        year,
        mileageKm,
        city,
        engineType
      })
    }
  };
}

function normalizeSearchText(value: string) {
  return value.toLowerCase().replace(/ё/g, "е").replace(/\s+/g, "");
}

function matchesTextFilter(haystack: string, needle?: string) {
  const query = normalizeSearchText((needle || "").trim());
  if (!query) return true;
  return normalizeSearchText(haystack).includes(query);
}

function matchesEngineFilter(engineType: string, filter?: string) {
  if (!filter || filter === "ANY") return true;
  const normalized = normalizeSearchText(engineType);
  if (filter === "ELECTRIC") return normalized.includes("электро");
  if (filter === "HYBRID") return normalized.includes("гибрид") || normalized.includes("hybrid");
  if (filter === "GAS") return normalized.includes("бензин");
  return true;
}

function matchesSelectFilter(value: string | undefined, filter?: string) {
  if (!filter || filter === "ANY") return true;
  return normalizeSearchText(value || "").includes(normalizeSearchText(filter));
}

function matchesRangeFilter(value: number | null | undefined, from?: number, to?: number) {
  if (from === undefined && to === undefined) return true;
  if (value === null || value === undefined || !Number.isFinite(value)) return false;
  if (from !== undefined && value < from) return false;
  if (to !== undefined && value > to) return false;
  return true;
}

function hasExtendedFilters(filters?: ImportListFilters) {
  if (!filters) return false;
  return Boolean(
    filters.city ||
      filters.yearFrom ||
      filters.yearTo ||
      filters.mileageMax ||
      filters.priceCnyFrom ||
      filters.priceCnyTo ||
      (filters.gearbox && filters.gearbox !== "ANY") ||
      (filters.drive && filters.drive !== "ANY") ||
      (filters.engineType && filters.engineType !== "ANY")
  );
}

function matchesNormalizedDcdappFilters(normalized: NonNullable<ReturnType<typeof normalizeDcdappItem>>, filters?: ImportListFilters) {
  if (!filters) return true;
  const data = normalized.normalized;
  const sourceText = [normalized.rawTitle, normalized.translatedTitle, data.brand, data.model, data.trim].join(" ");

  return (
    matchesTextFilter(sourceText, filters.brand) &&
    matchesTextFilter(sourceText, filters.model) &&
    matchesTextFilter(data.city || "", filters.city) &&
    matchesEngineFilter(data.engineType, filters.engineType) &&
    matchesSelectFilter(data.gearbox, filters.gearbox) &&
    matchesSelectFilter(data.drive, filters.drive) &&
    matchesRangeFilter(data.year, filters.yearFrom, filters.yearTo) &&
    matchesRangeFilter(data.mileageKm, undefined, filters.mileageMax) &&
    matchesRangeFilter(normalized.priceCny, filters.priceCnyFrom, filters.priceCnyTo)
  );
}

function matchesDcdappFilters(item: unknown, settings: SettingsData, filters?: ImportListFilters) {
  if (
    !filters?.brand &&
    !filters?.model &&
    !filters?.city &&
    (!filters?.engineType || filters.engineType === "ANY") &&
    !hasExtendedFilters(filters)
  ) {
    return true;
  }
  if (!filters) return true;

  const normalized = normalizeDcdappItem(item, settings);
  if (!normalized) return false;
  const sourceText = [
    normalized.rawTitle,
    normalized.translatedTitle,
    normalized.normalized.brand,
    normalized.normalized.model,
    normalized.normalized.trim
  ].join(" ");

  return (
    matchesTextFilter(sourceText, filters.brand) &&
    matchesTextFilter(sourceText, filters.model) &&
    matchesTextFilter(normalized.normalized.city || "", filters.city) &&
    matchesRangeFilter(normalized.normalized.year, filters.yearFrom, filters.yearTo) &&
    matchesRangeFilter(normalized.normalized.mileageKm, undefined, filters.mileageMax) &&
    matchesRangeFilter(normalized.priceCny, filters.priceCnyFrom, filters.priceCnyTo)
  );
}

function matchesChe168GlobalFilters(item: Che168GlobalCar, filters?: ImportListFilters) {
  if (!filters) return true;
  const data = item.normalized;
  const sourceText = [item.rawTitle, item.translatedTitle, data.brand, data.model, data.trim].join(" ");

  return (
    matchesTextFilter(sourceText, filters.brand) &&
    matchesTextFilter(sourceText, filters.model) &&
    matchesTextFilter(data.city || "", filters.city) &&
    matchesEngineFilter(data.engineType, filters.engineType) &&
    matchesSelectFilter(data.gearbox, filters.gearbox) &&
    matchesSelectFilter(data.drive, filters.drive) &&
    matchesRangeFilter(data.year, filters.yearFrom, filters.yearTo) &&
    matchesRangeFilter(data.mileageKm, undefined, filters.mileageMax) &&
    matchesRangeFilter(item.priceCny, filters.priceCnyFrom, filters.priceCnyTo)
  );
}

async function saveChe168GlobalDraft(item: Che168GlobalCar, settings: SettingsData) {
  const costs = calculateCarCosts(item.priceCny, settings);
  const normalized = {
    ...item.normalized,
    deliveryRub: costs.deliveryRub,
    customsRub: costs.customsRub,
    commissionRub: costs.commissionRub,
    priceRub: costs.priceRub || undefined
  };
  const cachedImages = await cacheExternalImages(item.imageUrls, "che168-global");
  const existing = await prisma.car.findFirst({
    where: { source: "CHE168", externalId: item.externalId }
  });

  if (existing) {
    const updatedCar = await prisma.car.update({
      where: { id: existing.id },
      data: {
        sourceUrl: item.sourceUrl,
        brand: normalized.brand || existing.brand,
        model: normalized.model || existing.model,
        trim: normalized.trim || existing.trim,
        year: normalized.year || existing.year,
        mileageKm: normalized.mileageKm,
        city: normalized.city || existing.city,
        body: normalized.body || existing.body,
        engineType: normalized.engineType || existing.engineType,
        gearbox: normalized.gearbox || existing.gearbox,
        drive: normalized.drive || existing.drive,
        power: normalized.power || existing.power,
        color: normalized.color || existing.color,
        priceCny: item.priceCny ?? existing.priceCny,
        priceRub: normalized.priceRub || existing.priceRub,
        deliveryRub: normalized.deliveryRub,
        customsRub: normalized.customsRub,
        commissionRub: normalized.commissionRub,
        descriptionRu: normalized.descriptionRu || existing.descriptionRu,
        specificationsJson: normalized.specifications ? JSON.stringify(normalized.specifications) : existing.specificationsJson,
        imageUrls: cachedImages.length ? JSON.stringify(cachedImages) : existing.imageUrls,
        sourceLastSeenAt: new Date(),
        sourceMissingSince: null,
        sourceMissingCount: 0
      }
    });
    return { updatedCar, externalId: item.externalId };
  }

  await prisma.importDraft.deleteMany({
    where: { source: "CHE168", externalId: item.externalId }
  });
  const draft = await prisma.importDraft.create({
    data: {
      source: "CHE168",
      sourceUrl: item.sourceUrl,
      externalId: item.externalId,
      rawTitle: item.rawTitle,
      rawPayload: JSON.stringify(item.rawPayload),
      translatedTitle: item.translatedTitle,
      normalizedJson: JSON.stringify(normalized),
      imageUrls: JSON.stringify(cachedImages),
      priceCny: item.priceCny,
      reviewNote: "CHE168 Global: данные и характеристики импортированы из русской версии. Проверьте цену и состояние перед публикацией."
    }
  });
  return { draft, externalId: item.externalId };
}

async function updateExistingDcdappCar(normalized: NonNullable<ReturnType<typeof normalizeDcdappItem>>) {
  const existing = await prisma.car.findFirst({
    where: {
      source: normalized.source,
      externalId: normalized.externalId
    }
  });

  if (!existing) return null;

  const data = normalized.normalized;

  return prisma.car.update({
    where: { id: existing.id },
    data: {
      sourceUrl: normalized.sourceUrl,
      trim: data.trim || existing.trim,
      year: data.year || existing.year,
      mileageKm: data.mileageKm || existing.mileageKm,
      city: data.city || existing.city,
      engineType: data.engineType || existing.engineType,
      gearbox: data.gearbox || existing.gearbox,
      drive: data.drive || existing.drive,
      power: data.power || existing.power,
      priceCny: normalized.priceCny ?? existing.priceCny,
      priceRub: data.priceRub || existing.priceRub,
      deliveryRub: data.deliveryRub,
      customsRub: data.customsRub,
      commissionRub: data.commissionRub,
      imageUrls: normalized.imageUrls.length ? JSON.stringify(await cacheExternalImages(normalized.imageUrls)) : existing.imageUrls,
      sourceLastSeenAt: new Date(),
      sourceMissingSince: null,
      sourceMissingCount: 0
    }
  });
}

function translatedBrandFilter(filters: ImportListFilters, selection?: DcdappSelection) {
  const raw = filters.brand || selection?.brandName || "";
  return brandRu[raw] || stripChineseText(raw, "");
}

function translatedModelFilter(filters: ImportListFilters, selection?: DcdappSelection) {
  const raw = filters.model || selection?.seriesName || "";
  return seriesRu[raw] || stripChineseText(raw, "");
}

async function markMissingDcdappCars(input: {
  filters: ImportListFilters;
  selection?: DcdappSelection;
  seenExternalIds: string[];
  enableMissingCheck: boolean;
}) {
  if (!input.enableMissingCheck || !input.seenExternalIds.length) {
    return { checked: false, count: 0 };
  }

  const brand = translatedBrandFilter(input.filters, input.selection);
  const model = translatedModelFilter(input.filters, input.selection);
  if (!brand && !model) return { checked: false, count: 0 };

  const cars = await prisma.car.findMany({
    where: {
      source: "DONGCHEDI",
      externalId: { not: null, notIn: input.seenExternalIds },
      status: { not: "ARCHIVED" },
      ...(brand ? { brand: { contains: brand } } : {}),
      ...(model ? { model: { contains: model } } : {})
    },
    select: {
      id: true,
      sourceMissingSince: true
    }
  });

  const now = new Date();
  await Promise.all(
    cars.map((car) =>
      prisma.car.update({
        where: { id: car.id },
        data: {
          sourceMissingSince: car.sourceMissingSince || now,
          sourceMissingCount: { increment: 1 }
        }
      })
    )
  );

  return { checked: true, count: cars.length };
}

async function createDcdappDraftFromItem(item: unknown, settings: SettingsData, filters?: ImportListFilters) {
  let normalized = normalizeDcdappItem(item, settings);
  if (!normalized) return null;

  try {
    const detail = await fetchDcdappDetail(normalized.sourceUrl, normalized.externalId);
    normalized = mergeDcdappDetail(normalized, detail.data, settings);
  } catch {
    // The list payload is enough to create a draft; detail enrichment is best-effort.
  }

  if (!matchesNormalizedDcdappFilters(normalized, filters)) return null;

  const updatedCar = await updateExistingDcdappCar(normalized);
  if (updatedCar) return { updatedCar, externalId: normalized.externalId };

  await prisma.importDraft.deleteMany({
    where: {
      source: normalized.source,
      externalId: normalized.externalId
    }
  });

  const draft = await prisma.importDraft.create({
    data: {
      source: normalized.source,
      sourceUrl: normalized.sourceUrl,
      externalId: normalized.externalId,
      rawTitle: normalized.rawTitle,
      rawPayload: JSON.stringify(normalized.rawPayload),
      translatedTitle: normalized.translatedTitle,
      normalizedJson: JSON.stringify(normalized.normalized),
      imageUrls: JSON.stringify(await cacheExternalImages(normalized.imageUrls)),
      priceCny: normalized.priceCny,
      reviewNote: "Dongchedi/DCDApp: импорт из внутренней JSON-ленты, обязательно проверить оригинал и фото."
    }
  });

  return { draft, externalId: normalized.externalId };
}

async function createDcdappDraftFromDetailUrl(sourceUrl: string, settings: SettingsData) {
  const skuId = skuIdFromDcdappUrl(sourceUrl);
  if (!skuId) return null;

  const detail = await fetchDcdappDetail(sourceUrl, skuId);
  const detailData = detail.data;
  const commonInfo = isRecord(detailData.common_info) ? detailData.common_info : {};
  const params = dcdappParamMap(detailData);
  const brandCn = asString(commonInfo.brand_name);
  const seriesCn = asString(commonInfo.series_name);
  const carName = asString(commonInfo.car_name);
  const year = asNumber(commonInfo.year) || new Date().getFullYear();
  const priceCny = dcdappDetailPriceCny(detailData);
  const costs = calculateCarCosts(priceCny, settings);
  const brand = stripChineseText(brandRu[brandCn] || brandCn, "Dongchedi");
  const modelFallback = stripChineseText(seriesCn || carName, "объявление");
  const model = stripChineseText(seriesRu[seriesCn] || seriesCn, modelFallback);
  const trim = stripChineseText(carName, model);
  const cityCn = asString(commonInfo.car_source_city_name);
  const city = publicCity(cityCn ? cityRu[cityCn] || cityCn : cityFromDcdappUrl(sourceUrl));
  const mileageFromParams = mileageKmFromDcdappValue(dcdappParam(params, ["表显里程"]));
  const mileageWanKm = asNumber(commonInfo.mileage);
  const mileageKm = mileageFromParams || (mileageWanKm ? Math.round(mileageWanKm * 10_000) : 0);
  const fuelForm = asNumber(commonInfo.fuel_form);
  const engineType = translateDcdappFuel(fuelForm, "не указан");
  const gearbox = translateDcdappGearbox(dcdappParam(params, ["变速箱"]));
  const drive = translateDcdappDrive(dcdappParam(params, ["驱动方式", "动力类型"]));
  const engine = dcdappParam(params, ["发动机", "动力类型"]);
  const power = engine && /kw|квт|л\.?с|马力|功率/i.test(engine) ? stripChineseText(engine, engine) : undefined;
  const rawTitle = [seriesCn, year ? `${year}款` : "", carName].filter(Boolean).join(" ") || `Dongchedi ${skuId}`;
  const translatedTitle = stripChineseText(`${brand} ${model} ${year} ${trim}`, `${brand} ${model}`).replace(/\s+/g, " ").trim();
  const imageUrls = dcdappDetailImages(detailData);
  const normalized = {
    brand,
    model,
    trim,
    year,
    mileageKm,
    city,
    engineType,
    gearbox,
    drive,
    power,
    deliveryRub: costs.deliveryRub,
    customsRub: costs.customsRub,
    commissionRub: costs.commissionRub,
    priceRub: costs.priceRub || undefined,
    descriptionRu: buildCarDescription({
      title: translatedTitle,
      year,
      mileageKm,
      city,
      engineType
    })
  };

  await prisma.importDraft.deleteMany({
    where: {
      source: "DONGCHEDI",
      externalId: String(skuId)
    }
  });

  return prisma.importDraft.create({
    data: {
      source: "DONGCHEDI",
      sourceUrl,
      externalId: String(skuId),
      rawTitle,
      rawPayload: JSON.stringify({
        sourceUrl,
        httpStatus: detail.status,
        detail: {
          commonInfo,
          params: Object.fromEntries(params)
        }
      }),
      translatedTitle,
      normalizedJson: JSON.stringify(normalized),
      imageUrls: JSON.stringify(await cacheExternalImages(imageUrls)),
      priceCny,
      reviewNote: "Китайская площадка: данные импортированы по прямой ссылке. Проверьте цену, фото и комплектацию перед публикацией."
    }
  });
}

export function isAntiBotHtml(html: string) {
  return /EO-Bot-Js-Token|solveChallenge|TencentEdgeOne|__tst_status|EO_Bot_Ssid|location\.href=location\.href\.replace/i.test(html);
}

export function extractListingUrlsFromHtml(html: string, baseUrl: string) {
  const normalizedHtml = html.replace(/\\\//g, "/").replace(/&amp;/g, "&");
  const urlsByExternalId = new Map<string, string>();
  const patterns = [
    /https?:\/\/(?:www\.)?che168\.com\/dealer\/\d+\/\d+\.html(?:\?[^"'<>\s]*)?/gi,
    /\/\/(?:www\.)?che168\.com\/dealer\/\d+\/\d+\.html(?:\?[^"'<>\s]*)?/gi,
    /\/dealer\/\d+\/\d+\.html(?:\?[^"'<>\s]*)?/gi
  ];

  for (const pattern of patterns) {
    for (const match of normalizedHtml.matchAll(pattern)) {
      const rawUrl = match[0].startsWith("//") ? `https:${match[0]}` : match[0];
      const absoluteUrl = new URL(rawUrl, baseUrl).toString();
      urlsByExternalId.set(externalIdFromUrl(absoluteUrl), absoluteUrl);
    }
  }

  if (/\/dealer\/\d+\/\d+\.html/i.test(new URL(baseUrl).pathname)) {
    urlsByExternalId.set(externalIdFromUrl(baseUrl), baseUrl);
  }

  return [...urlsByExternalId.values()];
}

export async function createImportDraftFromUrl(sourceUrl: string) {
  const settings = await getSettings();
  const source = sourceFromUrl(sourceUrl);
  const externalId = externalIdFromUrl(sourceUrl);
  const fallbackTitle = `${source === "CHE168" ? "che168" : source === "DONGCHEDI" ? "Dongchedi" : "Китайское"} объявление ${externalId}`;

  if (isChe168GlobalDetailUrl(sourceUrl)) {
    const item = await scrapeChe168GlobalDetail(sourceUrl);
    const result = await saveChe168GlobalDraft(item, settings);
    if (result.draft) return result.draft;
    return result.updatedCar;
  }

  if (isChe168GlobalUrl(sourceUrl)) {
    throw new Error("Для ссылки на каталог используйте форму «Загрузить подборку»");
  }

  if (source === "DONGCHEDI") {
    const dcdappDraft = await createDcdappDraftFromDetailUrl(sourceUrl, settings);
    if (dcdappDraft) return dcdappDraft;
  }

  let status = 0;
  let html = "";
  let fetchError = "";

  try {
    const result = await fetchSourceHtml(sourceUrl);
    status = result.status;
    html = result.html;
  } catch (error) {
    fetchError = error instanceof Error ? error.message : String(error);
  }

  const blocked = isAntiBotHtml(html);
  const rawTitle = blocked || !html ? fallbackTitle : extractTitle(html, fallbackTitle);
  const parsedChe168 = source === "CHE168" && !blocked && html ? parseChe168Title(rawTitle) : null;
  const priceCny = blocked || !html ? null : parsedChe168?.priceCny || extractPriceCny(html, rawTitle);
  const imageUrls = blocked || !html ? [] : extractImages(html);
  const normalized = buildNormalized({ title: rawTitle, source, priceCny, blocked: blocked || !html, settings });
  const translatedTitle = stripChineseText(parsedChe168 ? translatedChe168Title(parsedChe168) : rawTitle, fallbackTitle);

  await prisma.importDraft.deleteMany({
    where: {
      source,
      externalId
    }
  });

  return prisma.importDraft.create({
    data: {
      source,
      sourceUrl,
      externalId,
      rawTitle,
      rawPayload: JSON.stringify({
        sourceUrl,
        httpStatus: status,
        blocked,
        fetchError: fetchError || null
      }),
      translatedTitle,
      normalizedJson: JSON.stringify(normalized),
      imageUrls: JSON.stringify(imageUrls),
      priceCny,
      reviewNote: blocked || fetchError ? "Источник не отдал HTML без антибота. Проверить оригинал вручную." : "Импорт по URL: проверить поля перед публикацией."
    }
  });
}

export async function createImportDraftsFromList(sourceUrl: string, limit: number, filters: ImportListFilters = {}) {
  const safeLimit = Math.max(1, Math.min(limit || 10, MAX_IMPORT_LIST_LIMIT));
  const source = sourceFromUrl(sourceUrl);

  if (isChe168GlobalUrl(sourceUrl)) {
    const settings = await getSettings();
    const hasFilters = Boolean(
      filters.brand || filters.model || filters.city || filters.yearFrom || filters.yearTo || filters.mileageMax || filters.priceCnyFrom || filters.priceCnyTo ||
        (filters.engineType && filters.engineType !== "ANY") ||
        (filters.gearbox && filters.gearbox !== "ANY") ||
        (filters.drive && filters.drive !== "ANY")
    );
    const searchLimit = hasFilters ? Math.min(MAX_IMPORT_LIST_LIMIT, safeLimit * 3) : safeLimit;
    const scraped = await scrapeChe168GlobalList(sourceUrl, searchLimit, {
      brand: filters.brand,
      model: filters.model
    });
    const imported: ImportDraft[] = [];
    const updatedCars: Car[] = [];
    const seenExternalIds: string[] = [];
    const errors = [...scraped.errors];

    const matchingItems = scraped.items.filter((item) => matchesChe168GlobalFilters(item, filters)).slice(0, safeLimit);
    for (let index = 0; index < matchingItems.length; index += 3) {
      const batch = matchingItems.slice(index, index + 3);
      await Promise.all(
        batch.map(async (item) => {
          try {
            const result = await saveChe168GlobalDraft(item, settings);
            seenExternalIds.push(result.externalId);
            if (result.draft) imported.push(result.draft);
            if (result.updatedCar) updatedCars.push(result.updatedCar);
          } catch (error) {
            errors.push({ sourceUrl: item.sourceUrl, error: error instanceof Error ? error.message : String(error) });
          }
        })
      );
    }

    return {
      sourceUrl,
      httpStatus: 200,
      blocked: false,
      requestedLimit: safeLimit,
      uniqueFound: scraped.uniqueFound,
      sourceTotal: scraped.sourceTotal,
      found: imported.length + updatedCars.length,
      scanned: scraped.scanned,
      imported,
      updatedCars,
      seenExternalIds,
      missing: { checked: false, count: 0 },
      errors
    };
  }

  if (source === "DONGCHEDI") {
    const settings = await getSettings();
    const shouldUseSearch = Boolean(
      filters.brand ||
        filters.model ||
        filters.brandId ||
        filters.seriesId ||
        numberParamFromUrl(sourceUrl, "brand_id") ||
        numberParamFromUrl(sourceUrl, "series_id")
    );

    if (shouldUseSearch) {
      const searchLimit = filters.model || hasExtendedFilters(filters) ? Math.min(DCDAPP_MAX_SCAN_ITEMS, safeLimit * 3) : safeLimit;
      const result = await fetchDcdappSearchItems(sourceUrl, filters, searchLimit);
      const residualFilters = {
        ...filters,
        brand: result.selection.brandId ? undefined : filters.brand,
        model: result.selection.seriesId ? undefined : filters.model
      };
      const data = result.items.filter((item) => matchesDcdappFilters(item, settings, residualFilters));
      const imported = [];
      const updatedCars = [];
      const seenExternalIds: string[] = [];
      let changedCount = 0;
      const errors: Array<{ sourceUrl: string; error: string }> = [];

      for (const item of data) {
        if (changedCount >= safeLimit) break;
        try {
          const result = await createDcdappDraftFromItem(item, settings, residualFilters);
          if (result?.externalId) seenExternalIds.push(result.externalId);
          if (result?.draft) {
            imported.push(result.draft);
            changedCount += 1;
          }
          if (result?.updatedCar) {
            updatedCars.push(result.updatedCar);
            changedCount += 1;
          }
        } catch (error) {
          errors.push({ sourceUrl, error: error instanceof Error ? error.message : String(error) });
        }
      }
      const missing = await markMissingDcdappCars({
        filters,
        selection: result.selection,
        seenExternalIds,
        enableMissingCheck: Boolean(filters.model) || safeLimit >= 50
      });

      return {
        sourceUrl,
        httpStatus: result.status,
        blocked: false,
        requestedLimit: safeLimit,
        uniqueFound: result.uniqueFound,
        found: imported.length + updatedCars.length,
        scanned: result.scanned,
        selection: result.selection,
        imported,
        updatedCars,
        seenExternalIds,
        missing,
        errors
      };
    }

    const result = await fetchDcdappFeed(sourceUrl);
    const feedItems = isRecord(result.json) && Array.isArray(result.json.data) ? result.json.data : [];
    const data = feedItems.filter((item) => matchesDcdappFilters(item, settings, filters));
    const imported = [];
    const updatedCars = [];
    const seenExternalIds: string[] = [];
    let changedCount = 0;
    const errors: Array<{ sourceUrl: string; error: string }> = [];

    for (const item of data) {
      if (changedCount >= safeLimit) break;
      try {
        const result = await createDcdappDraftFromItem(item, settings, filters);
        if (result?.externalId) seenExternalIds.push(result.externalId);
        if (result?.draft) {
          imported.push(result.draft);
          changedCount += 1;
        }
        if (result?.updatedCar) {
          updatedCars.push(result.updatedCar);
          changedCount += 1;
        }
      } catch (error) {
        errors.push({ sourceUrl, error: error instanceof Error ? error.message : String(error) });
      }
    }
    const missing = await markMissingDcdappCars({
      filters,
      seenExternalIds,
      enableMissingCheck: Boolean(filters.model) || safeLimit >= 50
    });

    return {
      sourceUrl,
      httpStatus: result.status,
      blocked: false,
      requestedLimit: safeLimit,
      uniqueFound: data.length,
      found: imported.length + updatedCars.length,
      scanned: feedItems.length,
      imported,
      updatedCars,
      seenExternalIds,
      missing,
      errors
    };
  }

  const result = await fetchSourceHtml(sourceUrl);
  const blocked = isAntiBotHtml(result.html);
  const urls = blocked ? [] : extractListingUrlsFromHtml(result.html, result.finalUrl || sourceUrl).slice(0, safeLimit);
  const imported = [];
  const errors: Array<{ sourceUrl: string; error: string }> = [];

  for (const url of urls) {
    try {
      imported.push(await createImportDraftFromUrl(url));
    } catch (error) {
      errors.push({ sourceUrl: url, error: error instanceof Error ? error.message : String(error) });
    }
  }

  return {
    sourceUrl,
    httpStatus: result.status,
    blocked,
    found: urls.length,
    imported,
    errors
  };
}
