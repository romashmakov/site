const CHINESE_TEXT_RE = /[\p{Script=Han}\u3000-\u303f\uff00-\uffef]+/gu;

export function stripChineseText(value: string | null | undefined, fallback = "") {
  const cleaned = String(value ?? "")
    .replace(CHINESE_TEXT_RE, " ")
    .replace(/\s+/g, " ")
    .trim();

  return cleaned || fallback;
}
