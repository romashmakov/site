export const catalogYears = Array.from({ length: 27 }, (_, index) => 2026 - index);

export type CatalogFilterValues = {
  sort: string;
  brand: string;
  model: string;
  engine: string;
  yearFrom: string;
  yearTo: string;
  minPrice: string;
  maxPrice: string;
};

export function nonNegativeInteger(value: string | undefined) {
  if (!value?.trim()) return undefined;
  const number = Number(value);
  return Number.isSafeInteger(number) && number >= 0 && number <= 1_000_000_000 ? number : undefined;
}

export function catalogYear(value: string | undefined) {
  const number = nonNegativeInteger(value);
  return number !== undefined && number >= 2000 && number <= 2026 ? number : undefined;
}

// Match whole-dollar prices as shown in the catalog, including both bounds.
export function rubPriceBounds(min: number | undefined, max: number | undefined, usdRate: number) {
  return {
    ...(min !== undefined ? { gte: Math.max(0, Math.ceil((min - 0.5) * usdRate)) } : {}),
    ...(max !== undefined ? { lte: Math.ceil((max + 0.5) * usdRate) - 1 } : {})
  };
}
