import { randomUUID } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";

const supportedTypes: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "image/gif": "gif",
  "image/avif": "avif"
};

function extensionFromUrl(url: string) {
  const pathname = new URL(url).pathname.toLowerCase();
  if (pathname.includes(".png")) return "png";
  if (pathname.includes(".webp")) return "webp";
  if (pathname.includes(".gif")) return "gif";
  if (pathname.includes(".avif")) return "avif";
  return "jpg";
}

function isLocalImage(url: string) {
  return url.startsWith("/uploads/") || url.startsWith("/cars/");
}

export async function cacheExternalImages(imageUrls: string[], folder = "imports") {
  const uploadDir = path.join(process.cwd(), "public", "uploads", folder);
  await mkdir(uploadDir, { recursive: true });

  const cached: string[] = [];
  const validUrls = imageUrls.filter(Boolean);
  for (let index = 0; index < validUrls.length; index += 6) {
    const batch = validUrls.slice(index, index + 6);
    const batchResults = await Promise.all(
      batch.map(async (imageUrl) => {
        if (isLocalImage(imageUrl)) return imageUrl;

        try {
          const response = await fetch(imageUrl, {
            headers: {
              "user-agent":
                "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"
            },
            signal: AbortSignal.timeout(15_000)
          });
          if (!response.ok) throw new Error(`Image fetch failed: ${response.status}`);

          const contentType = response.headers.get("content-type")?.split(";")[0]?.trim().toLowerCase() || "";
          const extension = supportedTypes[contentType] || extensionFromUrl(imageUrl);
          const bytes = Buffer.from(await response.arrayBuffer());
          if (!bytes.length || bytes.length > 12 * 1024 * 1024) throw new Error("Invalid image size");

          const filename = `${Date.now()}-${randomUUID()}.${extension}`;
          await writeFile(path.join(uploadDir, filename), bytes);
          return `/uploads/${folder}/${filename}`;
        } catch {
          return imageUrl;
        }
      })
    );
    cached.push(...batchResults);
  }

  return cached;
}
