import { existsSync } from "node:fs";
import { chromium, type Browser, type BrowserContext, type Page } from "playwright-core";

const CHE168_GLOBAL_HOST = "global.che168.com";
const CHE168_GLOBAL_API = "https://globalapi.che168.com/api/v1";
const DEFAULT_USD_CNY_RATE = 7.2;
const MAX_IMAGES_PER_CAR = 20;
const LISTING_SORTS = ["", "4", "1", "2", "3"];
const PRIORITY_BRANDS = [
  "Geely",
  "BYD",
  "Volkswagen",
  "Toyota",
  "BMW",
  "Audi",
  "Mercedes-Benz",
  "Changan",
  "Chery",
  "Honda",
  "Tesla",
  "Li Auto",
  "ZEEKR",
  "XPeng",
  "Haval",
  "Lynk & Co"
];

type Che168GlobalListHints = {
  brand?: string;
  model?: string;
};

type Che168Brand = {
  bid: number;
  name: string;
  py: string;
};

type Che168Series = {
  sid: number;
  sname: string;
  py: string;
};

export type Che168GlobalCar = {
  externalId: string;
  sourceUrl: string;
  rawTitle: string;
  translatedTitle: string;
  priceUsd: number | null;
  priceCny: number | null;
  imageUrls: string[];
  rawPayload: Record<string, unknown>;
  normalized: {
    brand: string;
    model: string;
    trim?: string;
    year: number;
    mileageKm: number;
    city: string;
    body?: string;
    engineType: string;
    gearbox?: string;
    drive?: string;
    power?: string;
    color?: string;
    specifications?: Record<string, string>;
    descriptionRu: string;
  };
};

export function isChe168GlobalUrl(sourceUrl: string) {
  try {
    return new URL(sourceUrl).hostname.toLowerCase() === CHE168_GLOBAL_HOST;
  } catch {
    return false;
  }
}

export function isChe168GlobalDetailUrl(sourceUrl: string) {
  if (!isChe168GlobalUrl(sourceUrl)) return false;
  return /\/ru\/detail\/\d+/i.test(new URL(sourceUrl).pathname);
}

function chromeExecutablePath() {
  const configured = process.env.CHE168_CHROME_PATH?.trim();
  if (configured) return configured;

  const candidates = [
    "/usr/bin/chromium",
    "/usr/bin/chromium-browser",
    "/usr/bin/google-chrome",
    "/usr/bin/google-chrome-stable",
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
  ];
  const systemBrowser = candidates.find((candidate) => existsSync(candidate));
  if (systemBrowser) return systemBrowser;

  const bundledBrowser = chromium.executablePath();
  return existsSync(bundledBrowser) ? bundledBrowser : "";
}

function usdCnyRate() {
  const configured = Number(process.env.CHE168_USD_CNY_RATE || DEFAULT_USD_CNY_RATE);
  return Number.isFinite(configured) && configured > 0 ? configured : DEFAULT_USD_CNY_RATE;
}

async function launchChe168Browser() {
  const executablePath = chromeExecutablePath();
  if (!executablePath) {
    throw new Error("Для импорта CHE168 Global на сервере необходимо установить Chromium");
  }

  const browser = await chromium.launch({
    executablePath,
    headless: true,
    args: ["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu"]
  });
  const context = await browser.newContext({
    locale: "ru-RU",
    timezoneId: "Europe/Moscow",
    viewport: { width: 1440, height: 1000 },
    userAgent:
      "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36"
  });
  // tsx/esbuild names inline browser functions through this harmless helper.
  await context.addInitScript({ content: "globalThis.__name = (target) => target;" });
  return { browser, context };
}

async function closeBrowser(browser: Browser, context: BrowserContext) {
  await context.close().catch(() => undefined);
  await browser.close().catch(() => undefined);
}

async function openChe168Page(page: Page, sourceUrl: string, selector: string, selectorTimeout = 35_000) {
  try {
    await page.goto(sourceUrl, { waitUntil: "domcontentloaded", timeout: 45_000 });
  } catch (error) {
    if (!/ERR_SOCKET_NOT_CONNECTED|ERR_CONNECTION_RESET|ERR_NETWORK_CHANGED/i.test(String(error))) throw error;
    await page.waitForTimeout(1_000);
    await page.goto(sourceUrl, { waitUntil: "domcontentloaded", timeout: 45_000 });
  }
  try {
    await page.waitForSelector(selector, { timeout: selectorTimeout });
  } catch {
    const html = await page.content().catch(() => "");
    if (/EO-Bot-Js-Token|solveChallenge|TencentEdgeOne/i.test(html)) {
      throw new Error("CHE168 Global не пропустил автоматическую проверку браузера. Повторите импорт позднее.");
    }
    throw new Error("CHE168 Global не отдал данные страницы");
  }
}

function externalIdFromDetailUrl(sourceUrl: string) {
  return new URL(sourceUrl).pathname.match(/\/detail\/(\d+)/i)?.[1] || "";
}

function normalizeGearbox(value: string) {
  if (!value || value === "-") return undefined;
  if (/двойн|DCT|робот/i.test(value)) return "Робот";
  if (/CVT|вариатор|бесступен/i.test(value)) return "Вариатор";
  if (/автомат/i.test(value)) return "Автомат";
  if (/механ/i.test(value)) return "Механика";
  return value;
}

function normalizeDrive(value: string) {
  if (!value || value === "-") return undefined;
  if (/полн|4WD|AWD/i.test(value)) return "Полный";
  if (/задн/i.test(value)) return "Задний";
  if (/передн/i.test(value)) return "Передний";
  return value;
}

function parseMileage(value: string) {
  const parsed = Number(value.replace(/[^\d]/g, ""));
  return Number.isFinite(parsed) ? parsed : 0;
}

function parseYear(title: string, modelYear: string, firstRegistration: string) {
  const fromTitle = Number(title.match(/\b(19|20)\d{2}\b/)?.[0] || "");
  if (fromTitle >= 1990 && fromTitle <= 2035) return fromTitle;
  const fromModel = Number(modelYear.match(/\b(19|20)\d{2}\b/)?.[0] || "");
  if (fromModel >= 1990 && fromModel <= 2035) return fromModel;
  const fromRegistration = Number(firstRegistration.match(/\b(19|20)\d{2}\b/)?.[0] || "");
  return fromRegistration >= 1990 && fromRegistration <= 2035 ? fromRegistration : new Date().getFullYear();
}

function cleanImageUrl(value: string) {
  try {
    const url = new URL(value);
    url.search = "";
    return url.toString();
  } catch {
    return value;
  }
}

async function scrapeChe168GlobalDetailPage(page: Page, sourceUrl: string): Promise<Che168GlobalCar> {
  await openChe168Page(page, sourceUrl, "h1", 12_000);

  const extracted = await page.evaluate(() => {
    const clean = (value: string | null | undefined) => (value || "").replace(/\s+/g, " ").trim();
    const exactElements = Array.from(document.querySelectorAll("div, span, p, dt"));
    const valueAfterLabel = (label: string) => {
      const labelElement = exactElements.find((element) => clean(element.textContent) === label);
      if (!labelElement) return "";

      const sibling = labelElement.nextElementSibling;
      const siblingText = clean(sibling?.textContent);
      if (siblingText && siblingText !== label) return siblingText;

      const parent = labelElement.parentElement;
      if (!parent) return "";
      const children = Array.from(parent.children);
      const index = children.indexOf(labelElement);
      for (const child of children.slice(index + 1)) {
        const value = clean(child.textContent);
        if (value && value !== label) return value;
      }
      return "";
    };

    const title = clean(document.querySelector("h1")?.textContent);
    const brand = clean(document.querySelector('a[href*="/ru/used-cars?brandid="]')?.textContent);
    const model = clean(document.querySelector('a[href*="seriesid="]')?.textContent);
    const pageText = clean(document.body.textContent);
    const priceUsd = Number(pageText.match(/\$([\d,]+)/)?.[1]?.replace(/,/g, "") || "") || null;
    const images = Array.from(document.querySelectorAll<HTMLImageElement>('img[src*="autoimg.cn/escimg/auto/"]'))
      .map((image) => image.currentSrc || image.src)
      .filter(Boolean);

    const labels = [
      "Дата производства",
      "Дата первой рег.",
      "Модельный год",
      "Пробег (km)",
      "Тип топлива",
      "Двигатель (сc)",
      "КПП",
      "Руль",
      "Местоположение",
      "Привод",
      "Тип кузова",
      "Мест",
      "Дверей",
      "Цвет кузова",
      "Снаряженная масса (кg)",
      "Габариты (mm)"
    ];
    const specs = Object.fromEntries(labels.map((label) => [label, valueAfterLabel(label)]));

    return { title, brand, model, priceUsd, images, specs };
  });

  const externalId = externalIdFromDetailUrl(sourceUrl);
  if (!externalId) throw new Error("В ссылке CHE168 Global не найден ID объявления");
  if (!extracted.title) throw new Error("В карточке CHE168 Global не найдено название автомобиля");
  if (/автомобиль продан|объявление (?:снято|недоступно)/i.test(extracted.title)) {
    throw new Error("Объявление уже снято с продажи");
  }

  const brand = extracted.brand || extracted.title.split(/\s+/)[0] || "Автомобиль";
  const model = extracted.model || extracted.title.replace(brand, "").trim().split(/\b(19|20)\d{2}\b/)[0]?.trim() || "Модель";
  const firstRegistration = extracted.specs["Дата первой рег."] || "";
  const modelYear = extracted.specs["Модельный год"] || "";
  const year = parseYear(extracted.title, modelYear, firstRegistration);
  const trim = extracted.title
    .replace(new RegExp(`^${brand.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\s*`, "i"), "")
    .replace(new RegExp(`^${model.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\s*`, "i"), "")
    .replace(new RegExp(`^${year}\\s*`), "")
    .trim();
  const engine = extracted.specs["Двигатель (сc)"] || "";
  const power = engine.match(/\d+(?:[.,]\d+)?\s*л\.?\s*с\.?/i)?.[0];
  const priceCny = extracted.priceUsd ? Math.round(extracted.priceUsd * usdCnyRate()) : null;
  const imageUrls = [...new Set(extracted.images.map(cleanImageUrl))].slice(0, MAX_IMAGES_PER_CAR);
  const normalized = {
    brand,
    model,
    trim: trim || undefined,
    year,
    mileageKm: parseMileage(extracted.specs["Пробег (km)"] || ""),
    city: extracted.specs["Местоположение"] || "Китай",
    body: extracted.specs["Тип кузова"] || undefined,
    engineType: extracted.specs["Тип топлива"] || "не указан",
    gearbox: normalizeGearbox(extracted.specs.КПП || ""),
    drive: normalizeDrive(extracted.specs.Привод || ""),
    power,
    color: extracted.specs["Цвет кузова"] || undefined,
    specifications: extracted.specs,
    descriptionRu: extracted.title
  };

  return {
    externalId,
    sourceUrl: `https://${CHE168_GLOBAL_HOST}/ru/detail/${externalId}`,
    rawTitle: extracted.title,
    translatedTitle: extracted.title,
    priceUsd: extracted.priceUsd,
    priceCny,
    imageUrls,
    rawPayload: {
      priceUsd: extracted.priceUsd,
      usdCnyRate: usdCnyRate(),
      specifications: extracted.specs
    },
    normalized
  };
}

async function listingUrlsFromPage(page: Page, sourceUrl: string) {
  await openChe168Page(page, sourceUrl, 'a[href*="/ru/detail/"]');
  return page.evaluate(() => {
    const urls = Array.from(document.querySelectorAll<HTMLAnchorElement>('a[href*="/ru/detail/"]'))
      .map((link) => link.href)
      .filter((href) => /\/ru\/detail\/\d+/i.test(href));
    const pageText = (document.body.textContent || "").replace(/\s+/g, " ");
    const total = Number(pageText.match(/Результаты поиска\s*\((\d+)\)/i)?.[1] || "") || null;
    return { urls, total };
  });
}

function normalizedLookupValue(value: string) {
  return value.toLocaleLowerCase("ru-RU").replace(/[^a-zа-яё0-9]/gi, "");
}

async function fetchChe168GlobalJson(path: string, params: Record<string, string>) {
  const url = new URL(`${CHE168_GLOBAL_API}/${path}`);
  url.searchParams.set("_appid", "global.pc");
  url.searchParams.set("language", "ru");
  url.searchParams.set("fromsource", "0");
  for (const [key, value] of Object.entries(params)) url.searchParams.set(key, value);

  const response = await fetch(url, { signal: AbortSignal.timeout(15_000) });
  if (!response.ok) throw new Error(`CHE168 Global API вернул ${response.status}`);
  return response.json() as Promise<unknown>;
}

async function getChe168Brands() {
  const payload = (await fetchChe168GlobalJson("brand", {})) as {
    result?: { brands?: Array<{ brand?: Che168Brand[] }> };
  };
  const brands = (payload.result?.brands || []).flatMap((group) => group.brand || []);
  const priority = new Map(PRIORITY_BRANDS.map((name, index) => [normalizedLookupValue(name), index]));
  return brands.sort((a, b) => {
    const aPriority = priority.get(normalizedLookupValue(a.name)) ?? PRIORITY_BRANDS.length;
    const bPriority = priority.get(normalizedLookupValue(b.name)) ?? PRIORITY_BRANDS.length;
    return aPriority - bPriority || a.name.localeCompare(b.name);
  });
}

async function getChe168Series(brandId: string) {
  const payload = (await fetchChe168GlobalJson("series", { brandid: brandId })) as {
    result?: { list?: Array<{ item?: Che168Series[] }> };
  };
  return (payload.result?.list || []).flatMap((group) => group.item || []);
}

function findByHint<T extends { name: string; py: string }>(items: T[], hint?: string) {
  const query = normalizedLookupValue(hint || "");
  if (!query) return [];
  const exact = items.filter((item) => [item.name, item.py].some((value) => normalizedLookupValue(value) === query));
  if (exact.length) return exact;
  return items.filter((item) => [item.name, item.py].some((value) => normalizedLookupValue(value).includes(query)));
}

function listingVariantUrl(
  sourceUrl: string,
  options: { brandId?: number; seriesId?: number; sort?: string | null }
) {
  const url = new URL(sourceUrl);
  url.searchParams.delete("page");
  url.searchParams.set("vehicle_list", "1");
  if (options.brandId) url.searchParams.set("brandid", String(options.brandId));
  if (options.seriesId) url.searchParams.set("seriesid", String(options.seriesId));
  else if (options.brandId) url.searchParams.delete("seriesid");
  if (options.sort) url.searchParams.set("sort", options.sort);
  else if (options.sort === null) url.searchParams.delete("sort");
  return url.toString();
}

export async function scrapeChe168GlobalDetail(sourceUrl: string) {
  const { browser, context } = await launchChe168Browser();
  try {
    const page = await context.newPage();
    return await scrapeChe168GlobalDetailPage(page, sourceUrl);
  } finally {
    await closeBrowser(browser, context);
  }
}

export async function scrapeChe168GlobalList(sourceUrl: string, limit: number, hints: Che168GlobalListHints = {}) {
  const safeLimit = Math.max(1, Math.min(300, Math.floor(limit)));
  const candidateLimit = Math.min(600, safeLimit * 2);
  const { browser, context } = await launchChe168Browser();
  try {
    const page = await context.newPage();
    const urlsById = new Map<string, string>();
    let scanned = 0;
    let totalFound: number | null = null;
    const visitedVariants = new Set<string>();
    const collectVariant = async (variantUrl: string, required = false) => {
      if (visitedVariants.has(variantUrl) || urlsById.size >= candidateLimit) return;
      visitedVariants.add(variantUrl);
      try {
        const listing = await listingUrlsFromPage(page, variantUrl);
        totalFound ||= listing.total;
        scanned += listing.urls.length;
        for (const url of listing.urls) {
          const externalId = externalIdFromDetailUrl(url);
          if (externalId && !urlsById.has(externalId)) urlsById.set(externalId, url);
        }
      } catch (error) {
        if (required) throw error;
      }
    };

    await collectVariant(listingVariantUrl(sourceUrl, {}), true);

    const source = new URL(sourceUrl);
    const sourceBrandId = source.searchParams.get("brandid") || "";
    const sourceSeriesId = source.searchParams.get("seriesid") || "";
    let brands: Che168Brand[] = [];
    try {
      brands = await getChe168Brands();
    } catch {
      // The original listing can still be imported if the optional directory API is unavailable.
    }

    const hintedBrands = findByHint(brands, hints.brand);
    const selectedBrand = hintedBrands[0] || brands.find((brand) => String(brand.bid) === sourceBrandId);
    const effectiveBrandId = selectedBrand ? String(selectedBrand.bid) : sourceBrandId;

    if (effectiveBrandId && !sourceSeriesId && urlsById.size < candidateLimit) {
      let series: Che168Series[] = [];
      try {
        series = await getChe168Series(effectiveBrandId);
      } catch {
        // Sorting variants below remain a useful fallback for a brand-only URL.
      }
      const hintedSeries = findByHint(
        series.map((item) => ({ ...item, name: item.sname })),
        hints.model
      );
      const seriesToVisit = hintedSeries.length ? hintedSeries : series;
      for (const item of seriesToVisit) {
        if (urlsById.size >= candidateLimit) break;
        for (const sort of LISTING_SORTS) {
          await collectVariant(
            listingVariantUrl(sourceUrl, { brandId: Number(effectiveBrandId), seriesId: item.sid, sort: sort || null })
          );
        }
      }
    } else if (!effectiveBrandId && urlsById.size < candidateLimit) {
      for (const brand of brands) {
        if (urlsById.size >= candidateLimit) break;
        await collectVariant(listingVariantUrl(sourceUrl, { brandId: brand.bid }));
        for (const sort of LISTING_SORTS.slice(1)) {
          if (urlsById.size >= candidateLimit) break;
          await collectVariant(listingVariantUrl(sourceUrl, { brandId: brand.bid, sort: sort || null }));
        }
      }
    }

    if (urlsById.size < candidateLimit) {
      for (const sort of LISTING_SORTS.slice(1)) {
        await collectVariant(listingVariantUrl(sourceUrl, { sort: sort || null }));
      }
    }

    const selectedUrls = [...urlsById.values()].slice(0, candidateLimit);
    const itemsByUrl = new Map<string, Che168GlobalCar>();
    const errors: Array<{ sourceUrl: string; error: string }> = [];
    for (let index = 0; index < selectedUrls.length && itemsByUrl.size < safeLimit; index += 3) {
      const batchUrls = selectedUrls.slice(index, index + 3);
      await Promise.all(
        batchUrls.map(async (url) => {
          let lastError: unknown;
          for (let attempt = 0; attempt < 2; attempt += 1) {
            const detailPage = await context.newPage();
            try {
              itemsByUrl.set(url, await scrapeChe168GlobalDetailPage(detailPage, url));
              return;
            } catch (error) {
              lastError = error;
              if (/снято с продажи/i.test(String(error))) break;
              if (attempt === 0) await detailPage.waitForTimeout(750);
            } finally {
              await detailPage.close().catch(() => undefined);
            }
          }
          errors.push({ sourceUrl: url, error: lastError instanceof Error ? lastError.message : String(lastError) });
        })
      );
    }

    const items = selectedUrls
      .map((url) => itemsByUrl.get(url))
      .filter((item): item is Che168GlobalCar => Boolean(item))
      .slice(0, safeLimit);
    return { items, errors, uniqueFound: urlsById.size, sourceTotal: totalFound, scanned };
  } finally {
    await closeBrowser(browser, context);
  }
}
