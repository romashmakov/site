export const company = {
  name: "БелАвтоЭксперт",
  legalName: 'ООО «БелАвтоЭксперт»',
  phone: "+375 (44) 52-52-703",
  phoneDigits: "375445252703",
  unp: "691996500",
  postalAddress: "220062, г. Минск",
  address: "ул. Тимирязева 119, корпус 1",
  email: "belavtoex@yandex.ru",
  instagram: "https://www.instagram.com/belavtoexpert/",
  hours: "Ежедневно 9:00–20:00"
} as const;

// Bank of Russia, 19 September 2026. This is an initial calculation rate,
// not an automatic live quote. It can be changed in /admin/settings.
// https://www.cbr.ru/currency_base/daily/?UniDbQuery.Posted=True&UniDbQuery.To=19.09.2026
export const initialUsdRate = 84.1975;
