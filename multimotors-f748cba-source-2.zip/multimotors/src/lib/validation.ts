import { z } from "zod";
import { listingStatuses, listingTypes, sourceKinds } from "@/lib/format";

const imageUrlSchema = z.string().refine((value) => {
  if (value.startsWith("/uploads/") || value.startsWith("/cars/")) return true;
  return z.string().url().safeParse(value).success;
}, "Укажите корректный URL фото или загрузите файл");

export const carInputSchema = z.object({
  type: z.enum(listingTypes),
  status: z.enum(listingStatuses).default("PUBLISHED"),
  source: z.enum(sourceKinds).default("MANUAL"),
  sourceUrl: z.string().url().optional().or(z.literal("")),
  externalId: z.string().optional().or(z.literal("")),
  brand: z.string().min(1, "Укажите марку"),
  model: z.string().min(1, "Укажите модель"),
  trim: z.string().optional().or(z.literal("")),
  year: z.coerce.number().int().min(1990).max(2035),
  mileageKm: z.coerce.number().int().min(0).default(0),
  city: z.string().optional().or(z.literal("")),
  body: z.string().optional().or(z.literal("")),
  engineType: z.string().min(1, "Укажите тип двигателя"),
  gearbox: z.string().optional().or(z.literal("")),
  drive: z.string().optional().or(z.literal("")),
  power: z.string().optional().or(z.literal("")),
  battery: z.string().optional().or(z.literal("")),
  rangeKm: z.coerce.number().int().min(0).optional().or(z.literal("")),
  color: z.string().optional().or(z.literal("")),
  vin: z.string().optional().or(z.literal("")),
  priceCny: z.coerce.number().int().min(0).optional().or(z.literal("")),
  priceRub: z.coerce.number().int().min(1, "Укажите цену"),
  deliveryRub: z.coerce.number().int().min(0).default(0),
  customsRub: z.coerce.number().int().min(0).default(0),
  commissionRub: z.coerce.number().int().min(0).default(0),
  descriptionRu: z.string().min(10, "Добавьте описание"),
  descriptionOrig: z.string().optional().or(z.literal("")),
  aiSummary: z.string().optional().or(z.literal("")),
  imageUrls: z.array(imageUrlSchema).default([])
});

export const leadInputSchema = z.object({
  carId: z.string().optional(),
  name: z.string().min(2, "Укажите имя"),
  phone: z.string().min(7, "Укажите телефон"),
  preferredContact: z.enum(["PHONE", "WHATSAPP", "TELEGRAM"]).default("PHONE"),
  comment: z.string().optional().or(z.literal(""))
});

export const carUpdateSchema = carInputSchema
  .partial()
  .extend({
    imageUrls: z.array(z.string().url()).optional()
  })
  .refine((value) => Object.keys(value).length > 0, "Нет данных для обновления");

export const leadUpdateSchema = z.object({
  status: z.enum(["NEW", "IN_PROGRESS", "CLOSED"])
});
