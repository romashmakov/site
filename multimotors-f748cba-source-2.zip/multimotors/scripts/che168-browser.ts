import { mkdirSync, writeFileSync } from "node:fs";
import { chromium, type Browser, type BrowserContext, type Response } from "playwright-core";

export type Che168BrowserProbeResult = {
  ok: boolean;
  url: string | null;
  title: string | null;
  cookieHeader: string;
  html: string;
  text: string;
  screenshotPath: string;
  storageStatePath: string;
  networkPath: string;
  requests: Array<{ method: string; url: string; resourceType: string }>;
  responses: Array<{ status: number; url: string; contentType?: string }>;
  error?: string;
};

function option(name: string, fallback?: string) {
  const value = process.argv.find((item) => item.startsWith(`--${name}=`));
  return value ? value.split("=").slice(1).join("=") : fallback;
}

function flag(name: string) {
  return process.argv.includes(`--${name}`);
}

function chromePath() {
  return (
    option("chrome-path") ||
    process.env.CHE168_CHROME_PATH ||
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
  );
}

function profileDir() {
  return option("profile") || process.env.CHE168_PROFILE_DIR;
}

function cookieHeaderFromContext(context: BrowserContext) {
  return context
    .cookies()
    .then((cookies) => cookies.map((cookie) => `${cookie.name}=${cookie.value}`).join("; "));
}

function isInterestingUrl(url: string) {
  return /che168|autohome|2sc|ershou|used|car|api|ajax|list|search|series/i.test(url);
}

function responseToLog(response: Response) {
  return {
    status: response.status(),
    url: response.url(),
    contentType: response.headers()["content-type"]
  };
}

async function withTimeout<T>(promise: Promise<T>, timeoutMs: number, fallback: T): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      promise,
      new Promise<T>((resolve) => {
        timer = setTimeout(() => resolve(fallback), timeoutMs);
      })
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export async function probeChe168Browser(options?: {
  timeoutMs?: number;
  headless?: boolean;
  artifactsDir?: string;
  profileDir?: string;
}): Promise<Che168BrowserProbeResult> {
  const timeoutMs = options?.timeoutMs ?? 45_000;
  const artifactsDir = options?.artifactsDir ?? ".tmp";
  const persistentProfileDir = options?.profileDir;
  mkdirSync(artifactsDir, { recursive: true });
  if (persistentProfileDir) mkdirSync(persistentProfileDir, { recursive: true });

  const stamp = Date.now();
  const screenshotPath = `${artifactsDir}/che168-browser-${stamp}.png`;
  const storageStatePath = `${artifactsDir}/che168-storage-${stamp}.json`;
  const networkPath = `${artifactsDir}/che168-network-${stamp}.json`;
  const htmlPath = `${artifactsDir}/che168-browser-${stamp}.html`;

  const requests: Che168BrowserProbeResult["requests"] = [];
  const responses: Che168BrowserProbeResult["responses"] = [];
  let browser: Browser | undefined;
  const contextOptions = {
    viewport: { width: 390, height: 844 },
    isMobile: true,
    hasTouch: true,
    locale: "zh-CN",
    timezoneId: "Asia/Shanghai",
    userAgent:
      "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"
  };

  const context = persistentProfileDir
    ? await chromium.launchPersistentContext(persistentProfileDir, {
        ...contextOptions,
        headless: options?.headless ?? true,
        executablePath: chromePath()
      })
    : await (async () => {
        browser = await chromium.launch({
          headless: options?.headless ?? true,
          executablePath: chromePath()
        });
        return browser.newContext(contextOptions);
      })();
  const page = context.pages()[0] ?? (await context.newPage());

  page.on("request", (request) => {
    if (isInterestingUrl(request.url())) {
      requests.push({
        method: request.method(),
        url: request.url(),
        resourceType: request.resourceType()
      });
    }
  });

  page.on("response", (response) => {
    if (isInterestingUrl(response.url())) {
      responses.push(responseToLog(response));
    }
  });

  let error: string | undefined;
  try {
    await page.goto("https://m.che168.com/", {
      waitUntil: "commit",
      timeout: Math.min(timeoutMs, 12_000)
    });
    await page.waitForTimeout(Math.min(8_000, Math.max(2_000, timeoutMs - 12_000)));
  } catch (caught) {
    error = caught instanceof Error ? caught.message : String(caught);
  }

  const navigated = page.url() !== "about:blank";
  const html = navigated ? await withTimeout(page.content(), 3_000, "") : "";
  const text = navigated ? await page.locator("body").innerText({ timeout: 3_000 }).catch(() => "") : "";
  const title = navigated ? await page.title().catch(() => null) : null;
  const url = page.url() || null;
  const cookieHeader = await cookieHeaderFromContext(context);

  if (navigated) await page.screenshot({ path: screenshotPath, fullPage: true }).catch(() => undefined);
  await context.storageState({ path: storageStatePath }).catch(() => undefined);
  writeFileSync(networkPath, JSON.stringify({ requests, responses }, null, 2));
  writeFileSync(htmlPath, html);

  await context.close();
  await browser?.close();

  return {
    ok: Boolean(cookieHeader) && !/EO-Bot-Js-Token|solveChallenge|TencentEdgeOne/i.test(html),
    url,
    title,
    cookieHeader,
    html,
    text,
    screenshotPath,
    storageStatePath,
    networkPath,
    requests,
    responses,
    error
  };
}

async function main() {
  const result = await probeChe168Browser({
    timeoutMs: Number(option("timeout", "45000")),
    headless: !flag("headed"),
    profileDir: profileDir()
  });

  console.log(
    JSON.stringify(
      {
        ok: result.ok,
        url: result.url,
        title: result.title,
        hasCookie: Boolean(result.cookieHeader),
        cookieNames: result.cookieHeader
          .split(";")
          .map((item) => item.trim().split("=")[0])
          .filter(Boolean),
        htmlLength: result.html.length,
        textSample: result.text.slice(0, 500),
        requestCount: result.requests.length,
        responseCount: result.responses.length,
        screenshotPath: result.screenshotPath,
        storageStatePath: result.storageStatePath,
        networkPath: result.networkPath,
        profileDir: profileDir(),
        error: result.error
      },
      null,
      2
    )
  );
}

if (process.argv[1]?.endsWith("che168-browser.ts")) {
  main().catch((error) => {
    console.error(error);
    process.exit(1);
  });
}
