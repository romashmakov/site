import { PrismaClient } from "@prisma/client";
import { company, initialUsdRate } from "../src/lib/company";

const prisma = new PrismaClient();

async function main() {
  await prisma.$transaction([
    prisma.appSettings.upsert({
      where: { id: "default" },
      create: { id: "default", companyName: company.name, phone: company.phone, usdRate: initialUsdRate },
      update: {}
    }),
    prisma.appSettings.updateMany({ where: { companyName: "Мультимоторс" }, data: { companyName: company.name } }),
    prisma.appSettings.updateMany({ where: { phone: "+7 (000) 000-00-00" }, data: { phone: company.phone } }),
    prisma.appSettings.updateMany({ where: { id: "default", whatsapp: null }, data: { whatsapp: company.phoneDigits } }),
    prisma.appSettings.updateMany({ where: { id: "default", telegram: null }, data: { telegram: `+${company.phoneDigits}` } })
  ]);
  console.log("Настройки обновлены. Объявления, фотографии и заявки сохранены.");
}

main().catch((error) => { console.error(error); process.exitCode = 1; }).finally(() => prisma.$disconnect());
