import { PrismaClient } from "@prisma/client";
import { spawnSync } from "node:child_process";
import { mkdirSync, writeFileSync } from "node:fs";
import { probeChe168Browser } from "./che168-browser";

const prisma = new PrismaClient();

type Che168Candidate = {
  externalId: string;
  sourceUrl: string;
  rawTitle: string;
  translatedTitle: string;
  priceCny: number;
  imageUrls: string[];
  rawPayload: Record<string, unknown>;
  normalized: {
    brand: string;
    model: string;
    trim?: string;
    year: number;
    mileageKm: number;
    city: string;
    body?: string;
    engineType: string;
    gearbox?: string;
    drive?: string;
    power?: string;
    battery?: string;
    rangeKm?: number;
    color?: string;
    deliveryRub?: number;
    customsRub?: number;
    commissionRub?: number;
    descriptionRu: string;
  };
};

const CNY_RATE = 11.8;

function arg(name: string, fallback?: string) {
  const value = process.argv.find((item) => item.startsWith(`--${name}=`));
  return value ? value.split("=").slice(1).join("=") : fallback;
}

function hasFlag(name: string) {
  return process.argv.includes(`--${name}`);
}

function cookieOverride() {
  return arg("cookie-header") || process.env.CHE168_COOKIE_HEADER || "";
}

function browserProfileDir() {
  return arg("profile") || process.env.CHE168_PROFILE_DIR;
}

async function fetchChe168Home(cookieHeader?: string) {
  const result = spawnSync(
    "curl",
    [
      "-L",
      "--silent",
      "--show-error",
      "--max-time",
      "25",
      "--connect-timeout",
      "8",
      "-A",
      "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
      "-H",
      "accept-language: zh-CN,zh;q=0.9,ru;q=0.8,en;q=0.7",
      ...(cookieHeader ? ["-H", `cookie: ${cookieHeader}`] : []),
      "-w",
      "\\n__HTTP_STATUS__:%{http_code}",
      "https://m.che168.com/"
    ],
    {
      encoding: "utf8",
      maxBuffer: 5 * 1024 * 1024
    }
  );

  if (result.error) throw result.error;
  if (result.status !== 0) {
    throw new Error(`curl failed (${result.status}): ${result.stderr || result.stdout.slice(0, 300)}`);
  }

  const marker = "\n__HTTP_STATUS__:";
  const markerIndex = result.stdout.lastIndexOf(marker);
  const html = markerIndex >= 0 ? result.stdout.slice(0, markerIndex) : result.stdout;
  const status = markerIndex >= 0 ? Number(result.stdout.slice(markerIndex + marker.length).trim()) : 0;

  return { status, html };
}

function saveDebugHtml(html: string, reason: string) {
  if (!hasFlag("debug-html")) return;
  mkdirSync(".tmp", { recursive: true });
  const path = `.tmp/che168-${Date.now()}.html`;
  writeFileSync(path, html);
  console.log(`Saved che168 debug HTML: ${path} (${reason})`);
}

function detectLiveCandidates(html: string): Che168Candidate[] {
  if (/EO-Bot-Js-Token|solveChallenge|TencentEdgeOne/i.test(html)) {
    throw new Error("che168 вернул JS challenge Tencent EdgeOne, нужен browser/cookie режим");
  }

  // If che168 exposes embedded JSON in the future, this is where we normalize it.
  const jsonLike = html.match(/<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/i)?.[1];
  if (!jsonLike) return [];

  try {
    const parsed = JSON.parse(jsonLike);
    const items = Array.isArray(parsed?.itemListElement) ? parsed.itemListElement : [];
    return items.slice(0, 10).map((item: any, index: number) => {
      const name = String(item?.name || `che168 listing ${index + 1}`);
      return makeCandidate({
        externalId: `che168-live-${index + 1}`,
        rawTitle: name,
        translatedTitle: name,
        brand: name.split(" ")[0] || "China",
        model: name.split(" ").slice(1).join(" ") || name,
        priceCny: 0,
        sourceUrl: String(item?.url || "https://m.che168.com/"),
        reviewNote: "Live HTML import: требуется проверка полей."
      });
    });
  } catch {
    return [];
  }
}

function makeCandidate(input: {
  externalId: string;
  rawTitle: string;
  translatedTitle: string;
  brand: string;
  model: string;
  priceCny: number;
  sourceUrl: string;
  reviewNote?: string;
  city?: string;
  year?: number;
  mileageKm?: number;
  body?: string;
  engineType?: string;
  gearbox?: string;
  drive?: string;
  power?: string;
  battery?: string;
  rangeKm?: number;
  color?: string;
  imageUrls?: string[];
}): Che168Candidate {
  const year = input.year ?? 2024;
  const city = input.city ?? "Китай";
  const mileageKm = input.mileageKm ?? 0;
  const engineType = input.engineType ?? "не указан";
  const deliveryRub = 280_000;
  const customsRub = Math.max(Math.round(input.priceCny * CNY_RATE * 0.16), 420_000);
  const commissionRub = 200_000;

  return {
    externalId: input.externalId,
    sourceUrl: input.sourceUrl,
    rawTitle: input.rawTitle,
    translatedTitle: input.translatedTitle,
    priceCny: input.priceCny,
    imageUrls: input.imageUrls ?? ["/cars/zeekr.jpg"],
    rawPayload: {
      title: input.rawTitle,
      city,
      year,
      mileageKm,
      engineType,
      note: input.reviewNote
    },
    normalized: {
      brand: input.brand,
      model: input.model,
      trim: input.translatedTitle,
      year,
      mileageKm,
      city,
      body: input.body,
      engineType,
      gearbox: input.gearbox,
      drive: input.drive,
      power: input.power,
      battery: input.battery,
      rangeKm: input.rangeKm,
      color: input.color,
      deliveryRub,
      customsRub,
      commissionRub,
      descriptionRu: `${input.translatedTitle} из ${city}. Черновик импортирован из che168, данные переведены и нормализованы автоматически. Перед публикацией менеджер должен проверить комплектацию, состояние, экспортную доступность и итоговую цену.`
    }
  };
}

function fallbackCandidates(): Che168Candidate[] {
  return [
    makeCandidate({
      externalId: "che168-fallback-zeekr-007-2024",
      rawTitle: "极氪 007 2024款 后驱智驾版",
      translatedTitle: "Zeekr 007 2024 RWD Smart",
      brand: "Zeekr",
      model: "007",
      priceCny: 209_900,
      sourceUrl: "https://m.che168.com/",
      reviewNote: "Dev fallback: che168 live-доступ заблокирован JS challenge.",
      city: "Ханчжоу",
      year: 2024,
      mileageKm: 6800,
      body: "Седан",
      engineType: "Электро",
      gearbox: "Редуктор",
      drive: "Задний",
      power: "421 л.с.",
      battery: "75 кВт⋅ч",
      rangeKm: 688,
      color: "Белый",
      imageUrls: ["/cars/zeekr.jpg"]
    }),
    makeCandidate({
      externalId: "che168-fallback-byd-song-plus-2024",
      rawTitle: "比亚迪 宋PLUS DM-i 2024款",
      translatedTitle: "BYD Song Plus DM-i 2024",
      brand: "BYD",
      model: "Song Plus DM-i",
      priceCny: 156_800,
      sourceUrl: "https://m.che168.com/",
      reviewNote: "Dev fallback: che168 live-доступ заблокирован JS challenge.",
      city: "Шэньчжэнь",
      year: 2024,
      mileageKm: 12000,
      body: "Кроссовер",
      engineType: "Гибрид",
      gearbox: "E-CVT",
      drive: "Передний",
      power: "197 л.с.",
      battery: "26.6 кВт⋅ч",
      rangeKm: 110,
      color: "Серый",
      imageUrls: ["/cars/byd.jpg"]
    }),
    makeCandidate({
      externalId: "che168-fallback-li-l7-2024",
      rawTitle: "理想 L7 2024款 Max",
      translatedTitle: "Li Auto L7 Max 2024",
      brand: "Li Auto",
      model: "L7 Max",
      priceCny: 301_800,
      sourceUrl: "https://m.che168.com/",
      reviewNote: "Dev fallback: che168 live-доступ заблокирован JS challenge.",
      city: "Шанхай",
      year: 2024,
      mileageKm: 9300,
      body: "Кроссовер",
      engineType: "Гибрид",
      gearbox: "Автомат",
      drive: "Полный",
      power: "449 л.с.",
      battery: "42.8 кВт⋅ч",
      rangeKm: 1315,
      color: "Черный",
      imageUrls: ["/cars/li.jpg"]
    })
  ];
}

async function saveDraft(candidate: Che168Candidate, reviewPrefix: string) {
  await prisma.importDraft.deleteMany({
    where: {
      source: "CHE168",
      externalId: candidate.externalId
    }
  });

  return prisma.importDraft.create({
    data: {
      source: "CHE168",
      sourceUrl: candidate.sourceUrl,
      externalId: candidate.externalId,
      rawTitle: candidate.rawTitle,
      rawPayload: JSON.stringify(candidate.rawPayload),
      translatedTitle: candidate.translatedTitle,
      normalizedJson: JSON.stringify(candidate.normalized),
      imageUrls: JSON.stringify(candidate.imageUrls),
      priceCny: candidate.priceCny,
      reviewNote: `${reviewPrefix} Проверить оригинал, комплектацию, состояние, экспорт и итоговую цену.`
    }
  });
}

async function main() {
  const limit = Number(arg("limit", "10"));
  const allowFallback = !hasFlag("no-fallback") && !hasFlag("live-only");
  let candidates: Che168Candidate[] = [];
  let reviewPrefix = "Live che168 import.";

  try {
    let cookieHeader = cookieOverride();
    const profileDir = browserProfileDir();
    if (!cookieHeader && (hasFlag("browser") || profileDir)) {
      const probe = await probeChe168Browser({
        timeoutMs: Number(arg("browser-timeout", "45000")),
        headless: !hasFlag("headed"),
        profileDir
      });
      cookieHeader = probe.cookieHeader;
      console.log(
        JSON.stringify(
          {
            browserProbe: {
              ok: probe.ok,
              hasCookie: Boolean(probe.cookieHeader),
              profileDir,
              cookieNames: probe.cookieHeader
                .split(";")
                .map((item) => item.trim().split("=")[0])
                .filter(Boolean),
              requestCount: probe.requests.length,
              responseCount: probe.responses.length,
              screenshotPath: probe.screenshotPath,
              networkPath: probe.networkPath,
              error: probe.error
            }
          },
          null,
          2
        )
      );
    } else if (cookieHeader) {
      console.log(
        JSON.stringify(
          {
            cookieOverride: {
              hasCookie: true,
              cookieNames: cookieHeader
                .split(";")
                .map((item) => item.trim().split("=")[0])
                .filter(Boolean)
            }
          },
          null,
          2
        )
      );
    }

    const { status, html } = await fetchChe168Home(cookieHeader || undefined);
    saveDebugHtml(html, `http ${status}`);
    candidates = detectLiveCandidates(html);
    if (!candidates.length) {
      throw new Error(`che168 HTML получен (${status}), но список авто в HTML не найден`);
    }
  } catch (error) {
    if (!allowFallback) throw error;
    reviewPrefix = `Fallback import (${error instanceof Error ? error.message : String(error)}).`;
    candidates = fallbackCandidates();
  }

  const selected = candidates.slice(0, Number.isFinite(limit) ? limit : 10);
  const saved = [];
  for (const candidate of selected) {
    saved.push(await saveDraft(candidate, reviewPrefix));
  }

  console.log(
    JSON.stringify(
      {
        source: "CHE168",
        mode: reviewPrefix.startsWith("Fallback") ? "fallback" : "live",
        imported: saved.length,
        draftIds: saved.map((draft) => draft.id)
      },
      null,
      2
    )
  );
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (error) => {
    console.error(error);
    await prisma.$disconnect();
    process.exit(1);
  });
