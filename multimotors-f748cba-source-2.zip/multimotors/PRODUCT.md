# Product

## Register

product

## Users
Managers of a car-import business who need to publish vehicles, review imported Chinese listings, handle requests, and maintain a public catalog without developer help.

## Product Purpose
Multimotors is a working catalog and operations panel for cars from China, cars in stock, new cars, and custom-order offers. Success means a manager can create a vehicle card, add photos, publish it, receive a lead, and track that lead from one admin interface.

## Brand Personality
Practical, confident, direct. The product should feel like a reliable sales tool for expensive purchases: clear numbers, clear status, no decorative uncertainty.

## Anti-references
Avoid generic marketplace clutter, over-decorated SaaS dashboards, hidden controls, weak empty states, and interfaces that require a developer to complete ordinary manager tasks.

## Design Principles
- Make manager actions obvious: create, edit, publish, archive, and follow up should be visible where the work happens.
- Keep expensive decisions legible: price, source, status, photos, and lead context must be easy to verify.
- Prefer safe defaults: imported or incomplete data stays in review until a manager publishes it.
- Support manual work first: import is useful, but the product must remain usable when sources block automation.
- Use restrained product UI: consistency, readable tables, and clear forms beat visual novelty.

## Accessibility & Inclusion
Target WCAG AA contrast, keyboard-focusable controls, readable Russian labels, resilient empty states, and reduced-motion-safe interactions.
