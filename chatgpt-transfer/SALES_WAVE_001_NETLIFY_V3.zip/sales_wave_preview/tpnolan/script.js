document.querySelector('.job-note')?.addEventListener('submit', (event) => {
  event.preventDefault();
  const message = document.querySelector('.prototype-msg');
  if (message) message.textContent = 'Concept only — no details have been sent.';
});
