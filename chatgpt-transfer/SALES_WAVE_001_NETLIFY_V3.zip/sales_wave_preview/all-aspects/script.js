const menuButton = document.querySelector('.menu-toggle');
const navigation = document.querySelector('#main-nav');

function setNavigation(open) {
  if (!menuButton || !navigation) return;
  menuButton.setAttribute('aria-expanded', String(open));
  menuButton.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
  navigation.classList.toggle('is-open', open);
}

menuButton?.addEventListener('click', () => {
  setNavigation(menuButton.getAttribute('aria-expanded') !== 'true');
});

navigation?.querySelectorAll('a').forEach((link) => {
  link.addEventListener('click', () => setNavigation(false));
});

document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && menuButton?.getAttribute('aria-expanded') === 'true') {
    setNavigation(false);
    menuButton.focus();
  }
});

window.addEventListener('resize', () => {
  if (window.innerWidth > 760) setNavigation(false);
});

document.querySelector('.quote-form')?.addEventListener('submit', (event) => {
  event.preventDefault();
  const message = document.querySelector('.prototype-msg');
  if (message) message.textContent = 'Concept only — no details have been sent.';
});
