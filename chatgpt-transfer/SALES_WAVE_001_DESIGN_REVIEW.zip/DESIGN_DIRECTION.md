# Bespoke Mobile Concepts — Design Direction

## All Aspects Heating

**Product type:** Local heating and plumbing service site concept.  
**Primary user/task:** Birmingham-area homeowner who needs to understand whether the company handles their job and request a free quote or call.  
**Existing visual constraints:** Red square house mark and red “All Aspects” wordmark; pale green-white page surface; dark navigation; actual engineer photograph with blue workwear and yellow hard hat. Published copy names Birmingham, family-run service, Gas Safe registration, 7-day availability, free first-year service and stated installation/repair guarantees. Those are source claims, not independently endorsed facts.

**What stays:** Logo treatment, red as the action color, pale green-white canvas, dark navigation, original engineer photo, local and family-run wording, actual service names and existing phone number.

**What changes and why:** The desktop-width navigation is replaced by a compact mobile menu. The photo becomes a deliberate editorial image panel with complete readable title, followed by one quote action that anchors to a short enquiry form. The phone remains a separate direct tap target. A slim proof line preserves the company’s own published guarantees and service promise without turning every claim into a feature card.

**Composition plan:** Brand/phone masthead → full-width worker photograph with “Heating engineers / Family-run service / Covering Birmingham” → one clear “Get your free quote” action → service index → short trust/proof line → compact quote form. On larger screens, the photograph and quote statement become a split composition; the service list remains text-led.

**Distinct from TPNOLAN:** Warm photographic and practical; a clear service-company page with a direct quotation path. Color and image lead, with a compact square logo and simple mobile menu.

## TPNOLAN

**Product type:** Local plumbing and heating service site concept.  
**Primary user/task:** Manchester-area visitor who wants to identify the right service and contact the company without navigating a desktop-width page.  
**Existing visual constraints:** Warm cream surface; oversized dark geometric TPNOLAN wordmark; black circular TP monogram with the Nolan name and italic “Plumbing and heating” signature; source phrase “Keeping you cozy one room at a time!”; original service categories and listed prices. The source page also publishes a phone number, email, fixed-price items and “Get a free quote.”

**What stays:** Cream-and-ink identity, original wordmark/monogram vocabulary, serif italic secondary signature, service language, published fixed-price facts, the cozy phrase, and the company’s own phone/email.

**What changes and why:** Rather than shrinking the wide page, the concept uses the logo as a compact masthead and builds a print-like service index: numbered service entries, hairline rules, carefully paced typography, and a single integrated contact line. The service index is the navigation, so visitors can jump directly to Gas, Heating, Plumbing or Bathrooms. Quote contact is a distinct closing line, not a generic pair of hero buttons.

**Composition plan:** Wordmark masthead with expandable service index → asymmetrical monogram/phrase introduction → numbered service directory → small fixed-price ledger using only published figures → contact/quote line and form. Desktop opens into a two-column editorial index with a large roundel; mobile becomes a one-column reading sequence with persistent contact access.

**Distinct from All Aspects:** Typographic, quiet and editorial with no hero photograph, colored conversion button, benefit cards or conventional marketing hero. The navigation and content hierarchy are built from the company’s own wordmark, monogram and list-like service information.

## Reference research and synthesis

Reviewed 2026-10-08. References inform principles only; no source layout or content is copied.

- **PRIMARY — All Aspects Heating, official site** (`https://www.allaspectsheating.co.uk/`). It supplies the actual brand mark, engineer photo, local service information, telephone and published trust statements. Keep its recognizable identity; re-sequence the mobile page around the real photograph and quote path.
- **PRIMARY — TPNOLAN, official site** (`https://www.tpnolan.co.uk/`). Search-indexed official page text and the saved 390×844 browser capture show the wordmark, monogram, palette, service catalogue and prices. The live page timed out in the web reader during this review, so current visual details are grounded in the saved browser capture, with page copy cross-checked against its indexed official content.
- **INSPIRATIONAL_ONLY — TeamHeat** (`https://teamheat.uk/`). Its service-specific paths and immediate phone/booking access demonstrate that urgent and planned work can coexist with direct routes. Its dense sales system, mascots, pricing hierarchy and branding do not fit either client and are not copied.
- **INSPIRATIONAL_ONLY — Peregrine Plumbing branding case study** (`https://www.since81.co.uk/design-work/peregrine-plumbing`). Its documented pairing of a classic serif signature with a plumbing mark supports keeping TPNOLAN’s italic serif secondary wordmark distinct from its geometric name. No layout, logo or palette is copied.

**Reference synthesis:** All Aspects should be photographic, warm and direct, anchored by the actual engineer image and existing red house mark. TPNOLAN should feel like an identity-led service index, making its wordmark, black roundel and italic signature do structural work. Do not normalize both into a standard trade landing-page template.

**Reference diversity risk:** LOW — the two primary brands are visibly different; supporting references are used only for narrow usability and typographic principles.

## Build and review constraints

- Two standalone HTML/CSS prototypes with small local scripts; no frameworks, new dependencies, external fonts or remote images.
- Real image assets are cropped from the saved official-site screenshots; no generated or stock photography.
- Interactions are local prototype navigation only. Forms do not send data.
- Review screenshots at 390×844 mobile, 768×1024 tablet and 1440×1000 desktop.
- Main visual risks: misrepresenting source claims; allowing the mobile menu or quote path to become hidden; making TPNOLAN’s identity generic; using screenshot-derived image crops as if they were original source files.

## Comparison with saved original mobile captures

- **All Aspects:** The saved 390×844 source capture shows the original red house/logo area and real engineer photo, but the desktop navigation and headline extend past the phone width; the visible headline is clipped. The concept keeps those brand assets and published information, while giving the mobile screen a complete title, a direct quote anchor, a tap-to-call number and a short service index. The quote form is only a visual prototype and sends nothing.
- **TPNOLAN:** The saved 390×844 capture shows the cream surface, oversized wordmark running beyond the right edge, and the TP/NOLAN black mark dominating the screen. The concept keeps the type and mark but puts service navigation into a compact numbered index; phone/email remain direct links and published prices are placed in a compact ledger. The job-note form is only a visual prototype and sends nothing.

## Verification status

The independent HTML/CSS prototypes and local source-image crops exist. Screenshot-driven visual QA is **UNVERIFIED**: Playwright's local Chromium launch stopped with a macOS MachPort permission error, and the Codex browser explicitly rejected opening the local `file://` prototype. Its policy forbids reaching the same local page through localhost, raw CDP, or another browser surface, so no workaround was attempted. No new prototype screenshots are present yet. The supplied original captures remain at `client-acquisition/outreach-batch-002/evidence/allaspects-contact-390x844.png` and `client-acquisition/outreach-batch-002/evidence/tpnolan-mobile-390x844.png`.

Before design approval, open each local `index.html` in a browser on an unlocked Mac and capture/review the mobile, tablet and desktop states, or attach browser screenshots here for review. Until then these files are implementation drafts, not visually approved concepts.
