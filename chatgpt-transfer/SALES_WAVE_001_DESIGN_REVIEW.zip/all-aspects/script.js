const toggle=document.querySelector('.menu-toggle');
const nav=document.querySelector('#main-nav');
toggle.addEventListener('click',()=>{const open=toggle.getAttribute('aria-expanded')==='true';toggle.setAttribute('aria-expanded',String(!open));nav.classList.toggle('is-open',!open);});
nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('is-open');toggle.setAttribute('aria-expanded','false')}));
document.querySelector('.quote-form').addEventListener('submit',e=>{e.preventDefault();document.querySelector('.prototype-msg').textContent='Concept only — no details have been sent.'});
