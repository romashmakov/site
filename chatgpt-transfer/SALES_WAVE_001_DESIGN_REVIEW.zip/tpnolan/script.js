document.querySelector('.job-note').addEventListener('submit',e=>{e.preventDefault();document.querySelector('.prototype-msg').textContent='Concept only — no details have been sent.'});
