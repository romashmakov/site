(() => {
  const form = document.querySelector('.job-note');
  const message = form?.querySelector('.prototype-msg');
  form?.addEventListener('submit', event => {
    event.preventDefault();
    if (message) message.textContent = 'This concept form is not connected. Please call 07758 653127 or email support@tpnolan.co.uk to contact the company.';
  });
})();
